

CREATE OR ALTER PROCEDURE [dbo].[AirTravelEmissionReport]
    @p_organization_id        VARCHAR(255),
    @p_reporting_year_periods VARCHAR(MAX),
    @p_page                   INT = NULL,
    @p_limit                  INT = NULL
AS
BEGIN
    CREATE TABLE #Results (
        reporting_year              VARCHAR(255),
        reporting_period            VARCHAR(255),
        [Travel Date]               VARCHAR(10),
        [From Location]             VARCHAR(255),
        [To Location]               VARCHAR(255),
        [Travel Class]              VARCHAR(50),
        [Airline]                   VARCHAR(255),
        [Total Trips]               INT,
        [Total Distance (mile)]       DECIMAL(18,2),
        [Total Net Amount]          DECIMAL(18,2),
        [Total Emissions (mt CO2e)] DECIMAL(18,4),
        sort_row_id                 VARCHAR(36) NULL
    );

    CREATE TABLE #MonthsToProcess (
        month_name VARCHAR(20),
        month_num  INT
    );

    INSERT INTO #MonthsToProcess (month_name, month_num) VALUES
        ('January', 1), ('February', 2), ('March', 3),
        ('April', 4), ('May', 5), ('June', 6),
        ('July', 7), ('August', 8), ('September', 9),
        ('October', 10), ('November', 11), ('December', 12);

    -- Multi-year support: expand ranges like 2022-2025 into 2022-2023, 2023-2024, 2024-2025
    DECLARE @year_token NVARCHAR(50) = LEFT(@p_reporting_year_periods, CHARINDEX(':', @p_reporting_year_periods) - 1);
    DECLARE @from_year INT;
    DECLARE @to_year   INT;

    IF CHARINDEX('-', @year_token) > 0
    BEGIN
        SET @from_year = CAST(LEFT(@year_token, CHARINDEX('-', @year_token) - 1) AS INT);
        SET @to_year   = CAST(SUBSTRING(@year_token, CHARINDEX('-', @year_token) + 1, LEN(@year_token)) AS INT);
    END
    ELSE
    BEGIN
        SET @from_year = CAST(@year_token AS INT);
        SET @to_year   = @from_year + 1;
    END;

    CREATE TABLE #YearRanges (
        reporting_year VARCHAR(9),
        start_year     INT,
        end_year       INT
    );

    ;WITH Years AS (
        SELECT @from_year AS y
        UNION ALL
        SELECT y + 1
        FROM Years
        WHERE y + 1 < @to_year
    )
    INSERT INTO #YearRanges (reporting_year, start_year, end_year)
    SELECT
        CAST(y AS VARCHAR(4)) + '-' + CAST(y + 1 AS VARCHAR(4)) AS reporting_year,
        y,
        y + 1
    FROM Years
    OPTION (MAXRECURSION 32767);

    DECLARE @months_part VARCHAR(MAX) =
        SUBSTRING(@p_reporting_year_periods, CHARINDEX(':', @p_reporting_year_periods) + 1, LEN(@p_reporting_year_periods));

    CREATE TABLE #RequestedMonths (month_name VARCHAR(20));

    ;WITH SplitMonths AS (
        SELECT value AS month_name
        FROM STRING_SPLIT(REPLACE(REPLACE(@months_part, '''', ''), ' ', ''), ',')
    )
    INSERT INTO #RequestedMonths
    SELECT month_name
    FROM SplitMonths;


    PRINT 'Year(s) to search: ' + @year_token;

    INSERT INTO #Results
    SELECT
        ic.reporting_year                                      AS reporting_year,
        DATENAME(MONTH, ic.execute_date)                       AS reporting_period,
        CONVERT(VARCHAR(10), t.etrv_end_travel_date, 105)      AS [Travel Date],
        t.etrv_from_place                                      AS [From Location],
        t.etrv_to_place                                        AS [To Location],
        t.travel_class                                         AS [Travel Class],
        t.air_line_name                                        AS [Airline],
        1                                                      AS [Total Trips],
        CAST(t.trip_distance AS DECIMAL(18,2))                 AS [Total Distance (mile)],
        CAST(t.net_total     AS DECIMAL(18,2))                 AS [Total Net Amount],
        CAST(t.total_emission AS DECIMAL(18,4)) / 1000       AS [Total Emissions (mt CO2e)],
        CONVERT(VARCHAR(36), t.target_air_travel_id)       AS sort_row_id
    FROM target_air_travel t
    INNER JOIN ingestion_calendar ic
        ON ic.ingestion_calendar_id = t.ingestion_calendar_id
    INNER JOIN #MonthsToProcess m
        ON DATENAME(MONTH, ic.execute_date) = m.month_name
    INNER JOIN #RequestedMonths rm
        ON m.month_name = rm.month_name
    INNER JOIN #YearRanges yr
        ON ic.reporting_year = yr.reporting_year
    WHERE t.deleted = 0
      AND CAST(t.total_emission AS DECIMAL(18,4)) > 0;

    ;WITH Ordered AS (
        SELECT *,
               ROW_NUMBER() OVER (
                   ORDER BY
                       CASE WHEN reporting_year IS NULL THEN 0 ELSE 1 END,
                       reporting_year,
                       CASE reporting_period
                           WHEN 'April' THEN 1
                           WHEN 'May' THEN 2
                           WHEN 'June' THEN 3
                           WHEN 'July' THEN 4
                           WHEN 'August' THEN 5
                           WHEN 'September' THEN 6
                           WHEN 'October' THEN 7
                           WHEN 'November' THEN 8
                           WHEN 'December' THEN 9
                           WHEN 'January' THEN 10
                           WHEN 'February' THEN 11
                           WHEN 'March' THEN 12
                       END,
                       [From Location],
                       [To Location],
                       [Airline],
                       sort_row_id
               ) AS rn
        FROM #Results
    )
    SELECT
        reporting_year,
        reporting_period,
        [Travel Date],
        [From Location],
        [To Location],
        [Travel Class],
        [Airline],
        [Total Trips],
        [Total Distance (mile)],
        [Total Net Amount],
        [Total Emissions (mt CO2e)]
    FROM Ordered
    WHERE (@p_page = 1 AND @p_limit = 1)
       OR (@p_page IS NULL OR @p_limit IS NULL OR @p_page <= 0 OR @p_limit <= 0)
       OR rn BETWEEN ((@p_page - 1) * @p_limit) + 1
                  AND (@p_page * @p_limit)
    ORDER BY rn;

    DROP TABLE #Results;
    DROP TABLE #MonthsToProcess;
    DROP TABLE #RequestedMonths;
    DROP TABLE #YearRanges;
END;
GO


CREATE OR ALTER PROCEDURE [dbo].[AirTravelInternationalEmissionReport]
    @p_organization_id        VARCHAR(255),
    @p_reporting_year_periods VARCHAR(MAX),
    @p_page                   INT = NULL,
    @p_limit                  INT = NULL
AS
BEGIN
    CREATE TABLE #Results (
        reporting_year              VARCHAR(255),
        reporting_period            VARCHAR(255),
        [Travel Date]               VARCHAR(10),
        [From Location]             VARCHAR(255),
        [To Location]               VARCHAR(255),
        [Travel Class]              VARCHAR(50),
        [Airline]                   VARCHAR(255),
        [Total Trips]               INT,
        [Total Distance (mile)]       DECIMAL(18,2),
        [Total Net Amount]          DECIMAL(18,2),
        [Total Emissions (mt CO2e)] DECIMAL(18,4),
        sort_row_id                 VARCHAR(36) NULL
    );

    CREATE TABLE #MonthsToProcess (
        month_name VARCHAR(20),
        month_num  INT
    );

    INSERT INTO #MonthsToProcess (month_name, month_num) VALUES
        ('January', 1), ('February', 2), ('March', 3),
        ('April', 4), ('May', 5), ('June', 6),
        ('July', 7), ('August', 8), ('September', 9),
        ('October', 10), ('November', 11), ('December', 12);

    -- Multi-year support: expand ranges like 2022-2025 into 2022-2023, 2023-2024, 2024-2025
    DECLARE @year_token NVARCHAR(50) = LEFT(@p_reporting_year_periods, CHARINDEX(':', @p_reporting_year_periods) - 1);
    DECLARE @from_year INT;
    DECLARE @to_year   INT;

    IF CHARINDEX('-', @year_token) > 0
    BEGIN
        SET @from_year = CAST(LEFT(@year_token, CHARINDEX('-', @year_token) - 1) AS INT);
        SET @to_year   = CAST(SUBSTRING(@year_token, CHARINDEX('-', @year_token) + 1, LEN(@year_token)) AS INT);
    END
    ELSE
    BEGIN
        SET @from_year = CAST(@year_token AS INT);
        SET @to_year   = @from_year + 1;
    END;

    CREATE TABLE #YearRanges (
        reporting_year VARCHAR(9),
        start_year     INT,
        end_year       INT
    );

    ;WITH Years AS (
        SELECT @from_year AS y
        UNION ALL
        SELECT y + 1
        FROM Years
        WHERE y + 1 < @to_year
    )
    INSERT INTO #YearRanges (reporting_year, start_year, end_year)
    SELECT
        CAST(y AS VARCHAR(4)) + '-' + CAST(y + 1 AS VARCHAR(4)) AS reporting_year,
        y,
        y + 1
    FROM Years
    OPTION (MAXRECURSION 32767);

    DECLARE @months_part VARCHAR(MAX) =
        SUBSTRING(@p_reporting_year_periods, CHARINDEX(':', @p_reporting_year_periods) + 1, LEN(@p_reporting_year_periods));

    CREATE TABLE #RequestedMonths (month_name VARCHAR(20));

    ;WITH SplitMonths AS (
        SELECT value AS month_name
        FROM STRING_SPLIT(REPLACE(REPLACE(@months_part, '''', ''), ' ', ''), ',')
    )
    INSERT INTO #RequestedMonths
    SELECT month_name
    FROM SplitMonths;

    PRINT 'Year(s) to search: ' + @year_token;

    INSERT INTO #Results
    SELECT
        ic.reporting_year                                      AS reporting_year,
        DATENAME(MONTH, ic.execute_date)                       AS reporting_period,
        CONVERT(VARCHAR(10), t.etrv_end_travel_date, 105)      AS [Travel Date],
        t.etrv_from_place                                      AS [From Location],
        t.etrv_to_place                                        AS [To Location],
        t.travel_class                                         AS [Travel Class],
        t.air_line_name                                        AS [Airline],
        1                                                      AS [Total Trips],
        CAST(t.trip_distance AS DECIMAL(18,2))                 AS [Total Distance (mile)],
        CAST(t.net_total     AS DECIMAL(18,2))                 AS [Total Net Amount],
        CAST(t.total_emission AS DECIMAL(18,4)) / 1000      AS [Total Emissions (mt CO2e)],
        CONVERT(VARCHAR(36), t.target_air_travel_id)       AS sort_row_id
    FROM target_air_travel_international t
    INNER JOIN ingestion_calendar ic
        ON ic.ingestion_calendar_id = t.ingestion_calendar_id
    INNER JOIN #MonthsToProcess m
        ON DATENAME(MONTH, ic.execute_date) = m.month_name
    INNER JOIN #RequestedMonths rm
        ON m.month_name = rm.month_name
    INNER JOIN #YearRanges yr
        ON ic.reporting_year = yr.reporting_year
    WHERE t.deleted = 0
      AND CAST(t.total_emission AS DECIMAL(18,4)) > 0;

    ;WITH Ordered AS (
        SELECT *,
               ROW_NUMBER() OVER (
                   ORDER BY
                       CASE WHEN reporting_year IS NULL THEN 0 ELSE 1 END,
                       reporting_year,
                       CASE reporting_period
                           WHEN 'April' THEN 1
                           WHEN 'May' THEN 2
                           WHEN 'June' THEN 3
                           WHEN 'July' THEN 4
                           WHEN 'August' THEN 5
                           WHEN 'September' THEN 6
                           WHEN 'October' THEN 7
                           WHEN 'November' THEN 8
                           WHEN 'December' THEN 9
                           WHEN 'January' THEN 10
                           WHEN 'February' THEN 11
                           WHEN 'March' THEN 12
                       END,
                       [From Location],
                       [To Location],
                       [Airline],
                       sort_row_id
               ) AS rn
        FROM #Results
    )
    SELECT
        reporting_year,
        reporting_period,
        [Travel Date],
        [From Location],
        [To Location],
        [Travel Class],
        [Airline],
        [Total Trips],
        [Total Distance (mile)],
        [Total Net Amount],
        [Total Emissions (mt CO2e)]
    FROM Ordered
    WHERE (@p_page = 1 AND @p_limit = 1)
       OR (@p_page IS NULL OR @p_limit IS NULL OR @p_page <= 0 OR @p_limit <= 0)
       OR rn BETWEEN ((@p_page - 1) * @p_limit) + 1
                  AND (@p_page * @p_limit)
    ORDER BY rn;

    DROP TABLE #Results;
    DROP TABLE #MonthsToProcess;
    DROP TABLE #RequestedMonths;
    DROP TABLE #YearRanges;
END;
GO


CREATE OR ALTER PROCEDURE [dbo].[CarTravelEmissionReport]
    @p_organization_id        VARCHAR(255),
    @p_reporting_year_periods VARCHAR(MAX),
    @p_page                   INT = NULL,
    @p_limit                  INT = NULL
AS
BEGIN
    SET NOCOUNT ON;

    CREATE TABLE #Results (
        reporting_year              VARCHAR(255),
        reporting_period            VARCHAR(255),
        [Pick Up Time]              DATETIME,
        [Vehicle Group]             VARCHAR(255),
        [Vehicle Type]              VARCHAR(255),
        [Total Trips]               INT,
        [Total Distance (in km)]    DECIMAL(18,4),
        [Total Amount]              DECIMAL(18,2),
        [Total Emissions (mt CO2e)] DECIMAL(18,4),
        sort_row_id                 VARCHAR(36) NULL
    );

    CREATE TABLE #MonthsToProcess (
        month_name VARCHAR(20),
        month_num  INT,
        PRIMARY KEY (month_name)
    );

    INSERT INTO #MonthsToProcess (month_name, month_num) VALUES
        ('January', 1), ('February', 2), ('March', 3),
        ('April', 4), ('May', 5), ('June', 6),
        ('July', 7), ('August', 8), ('September', 9),
        ('October', 10), ('November', 11), ('December', 12);

    -- Multi-year support
    DECLARE @year_token NVARCHAR(50) = LEFT(@p_reporting_year_periods, CHARINDEX(':', @p_reporting_year_periods) - 1);
    DECLARE @from_year INT;
    DECLARE @to_year   INT;

    IF CHARINDEX('-', @year_token) > 0
    BEGIN
        SET @from_year = CAST(LEFT(@year_token, CHARINDEX('-', @year_token) - 1) AS INT);
        SET @to_year   = CAST(SUBSTRING(@year_token, CHARINDEX('-', @year_token) + 1, LEN(@year_token)) AS INT);
    END
    ELSE
    BEGIN
        SET @from_year = CAST(@year_token AS INT);
        SET @to_year   = @from_year + 1;
    END;

    CREATE TABLE #YearRanges (
        reporting_year VARCHAR(9),
        start_year     INT,
        end_year       INT
    );

    ;WITH Years AS (
        SELECT @from_year AS y
        UNION ALL
        SELECT y + 1
        FROM Years
        WHERE y + 1 < @to_year
    )
    INSERT INTO #YearRanges (reporting_year, start_year, end_year)
    SELECT
        CAST(y AS VARCHAR(4)) + '-' + CAST(y + 1 AS VARCHAR(4)) AS reporting_year,
        y,
        y + 1
    FROM Years
    OPTION (MAXRECURSION 32767);

    DECLARE @months_part VARCHAR(MAX) =
        SUBSTRING(@p_reporting_year_periods, CHARINDEX(':', @p_reporting_year_periods) + 1, LEN(@p_reporting_year_periods));

    CREATE TABLE #RequestedMonths (month_name VARCHAR(20) PRIMARY KEY);

    INSERT INTO #RequestedMonths
    SELECT value AS month_name
    FROM STRING_SPLIT(
            REPLACE(
                REPLACE(
                    SUBSTRING(@p_reporting_year_periods, CHARINDEX(':', @p_reporting_year_periods) + 1, LEN(@p_reporting_year_periods)),
                    '''', ''
                ),
                ' ', ''
            ),
            ','
         );


    INSERT INTO #Results
    SELECT
        ic.reporting_year                                            AS reporting_year,
        DATENAME(MONTH, ic.execute_date)                             AS reporting_period,
        t.pick_up_time                                               AS [Pick Up Time],
        t.vehicle_group                                              AS [Vehicle Group],
        t.alloted_vehicle_type                                       AS [Vehicle Type],
        1                                                            AS [Total Trips],
        CAST(CAST(ISNULL(t.trip_distance, 0) AS DECIMAL(38,20)) AS DECIMAL(18,4))                       AS [Total Distance (in km)],
        CAST(CAST(ISNULL(t.sub_total, 0)      AS DECIMAL(38,20)) AS DECIMAL(18,2))                      AS [Total Amount],
        CAST(CAST(ISNULL(t.total_emission, 0) AS DECIMAL(38,20)) / 1000.0 AS DECIMAL(18,4))             AS [Total Emissions (mt CO2e)],
        CONVERT(VARCHAR(36), t.target_car_id)                                    AS sort_row_id
    FROM target_car t
    INNER JOIN ingestion_calendar ic
        ON ic.ingestion_calendar_id = t.ingestion_calendar_id
    INNER JOIN #MonthsToProcess m
        ON DATENAME(MONTH, ic.execute_date) = m.month_name
    INNER JOIN #RequestedMonths rm
        ON m.month_name = rm.month_name
    INNER JOIN #YearRanges yr
        ON ic.reporting_year = yr.reporting_year
    WHERE t.deleted = 0;

    ;WITH Ordered AS (
        SELECT *,
               ROW_NUMBER() OVER (
                   ORDER BY
                       CASE WHEN reporting_year IS NULL THEN 0 ELSE 1 END,
                       reporting_year,
                       CASE reporting_period
                           WHEN 'April' THEN 1
                           WHEN 'May' THEN 2
                           WHEN 'June' THEN 3
                           WHEN 'July' THEN 4
                           WHEN 'August' THEN 5
                           WHEN 'September' THEN 6
                           WHEN 'October' THEN 7
                           WHEN 'November' THEN 8
                           WHEN 'December' THEN 9
                           WHEN 'January' THEN 10
                           WHEN 'February' THEN 11
                           WHEN 'March' THEN 12
                       END,
                       [Vehicle Group],
                       [Vehicle Type],
                       [Pick Up Time],
                       sort_row_id
               ) AS rn
        FROM #Results
    )
    SELECT
        reporting_year,
        reporting_period,
        [Pick Up Time],
        [Vehicle Group],
        [Vehicle Type],
        [Total Trips],
        [Total Distance (in km)],
        [Total Amount],
        [Total Emissions (mt CO2e)]
    FROM Ordered
    WHERE (@p_page = 1 AND @p_limit = 1)
       OR (@p_page IS NULL OR @p_limit IS NULL OR @p_page <= 0 OR @p_limit <= 0)
       OR rn BETWEEN ((@p_page - 1) * @p_limit) + 1
                  AND (@p_page * @p_limit)
    ORDER BY rn;

    DROP TABLE #Results;
    DROP TABLE #MonthsToProcess;
    DROP TABLE #RequestedMonths;
    DROP TABLE #YearRanges;
END;
GO


-- Category 3 report: electricity T&D losses and well-to-tank purchased fuels.
-- Facilities T&D quantity is stored electricity_consumption minus green_tariff_units.
--   Renewable units are not subtracted. kg CO2e = that quantity * the facilities factor.
-- Owned Cars and DG Sets: total_quantity is litres.
--   well_to_tank_emission is stored in tonnes, so kg CO2e = well_to_tank_emission * 1000
--   EF is the well-to-tank factor effective on the ingestion calendar date.
CREATE OR ALTER PROCEDURE [dbo].[Cat3TDLossDataReport]
    @p_organization_id        VARCHAR(255),
    @p_reporting_year_periods VARCHAR(MAX),
    @p_page                   INT = NULL,
    @p_limit                  INT = NULL
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @year_token NVARCHAR(50) = LEFT(@p_reporting_year_periods, CHARINDEX(':', @p_reporting_year_periods) - 1);
    DECLARE @from_year INT;
    DECLARE @to_year   INT;

    IF CHARINDEX('-', @year_token) > 0
    BEGIN
        SET @from_year = CAST(LEFT(@year_token, CHARINDEX('-', @year_token) - 1) AS INT);
        SET @to_year   = CAST(SUBSTRING(@year_token, CHARINDEX('-', @year_token) + 1, LEN(@year_token)) AS INT);
    END
    ELSE
    BEGIN
        SET @from_year = CAST(@year_token AS INT);
        SET @to_year   = @from_year + 1;
    END;

    CREATE TABLE #YearRanges (
        reporting_year VARCHAR(9),
        start_year     INT,
        end_year       INT
    );

    ;WITH Years AS (
        SELECT @from_year AS y
        UNION ALL
        SELECT y + 1
        FROM Years
        WHERE y + 1 < @to_year
    )
    INSERT INTO #YearRanges (reporting_year, start_year, end_year)
    SELECT
        CAST(y AS VARCHAR(4)) + '-' + CAST(y + 1 AS VARCHAR(4)),
        y,
        y + 1
    FROM Years
    OPTION (MAXRECURSION 32767);

    CREATE TABLE #RequestedMonths (month_name VARCHAR(20) PRIMARY KEY);

    INSERT INTO #RequestedMonths (month_name)
    SELECT DISTINCT LTRIM(RTRIM(value))
    FROM STRING_SPLIT(
        REPLACE(
            REPLACE(
                SUBSTRING(@p_reporting_year_periods, CHARINDEX(':', @p_reporting_year_periods) + 1, LEN(@p_reporting_year_periods)),
                '''', ''
            ),
            ' ', ''
        ),
        ','
    )
    WHERE LTRIM(RTRIM(value)) <> '';

    CREATE TABLE #MonthMap (
        month_num  INT PRIMARY KEY,
        month_name VARCHAR(20)
    );

    INSERT INTO #MonthMap (month_num, month_name) VALUES
        (1, 'January'), (2, 'February'), (3, 'March'),
        (4, 'April'), (5, 'May'), (6, 'June'),
        (7, 'July'), (8, 'August'), (9, 'September'),
        (10, 'October'), (11, 'November'), (12, 'December');

    -- DG Set period is the fiscal month: 1 = April ... 9 = December, 10 = January ... 12 = March.
    CREATE TABLE #DgPeriodMap (
        period_num INT PRIMARY KEY,
        month_name VARCHAR(20),
        calendar_month_num INT
    );

    INSERT INTO #DgPeriodMap (period_num, month_name, calendar_month_num) VALUES
        (1, 'April', 4), (2, 'May', 5), (3, 'June', 6),
        (4, 'July', 7), (5, 'August', 8), (6, 'September', 9),
        (7, 'October', 10), (8, 'November', 11), (9, 'December', 12),
        (10, 'January', 1), (11, 'February', 2), (12, 'March', 3);

    ;WITH FactorLookup AS (
        SELECT
            m.reference_key,
            m.effective_start_date,
            m.effective_end_date,
            TRY_CAST(ef.co2e_total AS DECIMAL(18,6)) AS ef_value,
            ROW_NUMBER() OVER (
                PARTITION BY m.reference_key, m.effective_start_date, m.effective_end_date
                ORDER BY m.updatedAt DESC, m.ingestion_emission_factor_mapping_id
            ) AS factor_rank
        FROM ingestion_emission_factor_mapping m
        INNER JOIN emission_factor ef ON ef.emission_factor_id = m.emission_factor_id
        WHERE m.is_deleted = 0
          AND ef.is_deleted = 0
          AND m.reference_key IN (
              'Scope-2-Facilities-Data-Integration',
              'Scope-3-Owned-Car-Petrol-Well-to-Tank',
              'Scope-3-Owned-Car-Diesel-Well-to-Tank',
              'Scope-3-Dg-Set-Diesel-Well-to-Tank'
          )
    ),
    ActiveFactor AS (
        SELECT reference_key, effective_start_date, effective_end_date, ef_value
        FROM FactorLookup
        WHERE factor_rank = 1
          AND ef_value IS NOT NULL
    ),
    Facilities AS (
        SELECT
            TRY_CAST(tec.ifm_year AS INT) AS activity_year,
            mm.month_name,
            mm.month_num,
            'Electricity T&D Losses' AS emission_category,
            'Facilities' AS source_integration,
            'Electricity T&D Loss' AS activity_type,
            qty.quantity,
            'kWh' AS unit_name,
            af.ef_value,
            'kg CO2e/kWh' AS ef_unit,
            CASE
                WHEN qty.quantity IS NULL OR af.ef_value IS NULL THEN NULL
                ELSE qty.quantity * af.ef_value
            END AS emissions_kg
        FROM target_energy_consumption tec
        INNER JOIN ingestion_calendar ic ON ic.ingestion_calendar_id = tec.ingestion_calendar_id
        INNER JOIN #MonthMap mm ON TRY_CAST(tec.ifm_month AS INT) = mm.month_num
        INNER JOIN #RequestedMonths rm ON rm.month_name = mm.month_name
        INNER JOIN #YearRanges yr
            ON (
                mm.month_num BETWEEN 4 AND 12
                AND TRY_CAST(tec.ifm_year AS INT) = yr.start_year
            )
            OR (
                mm.month_num BETWEEN 1 AND 3
                AND TRY_CAST(tec.ifm_year AS INT) = yr.end_year
            )
        CROSS APPLY (
            SELECT
                TRY_CAST(tec.electricity_consumption AS DECIMAL(28,10))
                - ISNULL(TRY_CAST(tec.green_tariff_units AS DECIMAL(28,10)), 0) AS quantity
        ) qty
        OUTER APPLY (
            SELECT TOP 1 factor.ef_value
            FROM ActiveFactor factor
            WHERE factor.reference_key = 'Scope-2-Facilities-Data-Integration'
              AND ic.execute_date >= factor.effective_start_date
              AND ic.execute_date <= factor.effective_end_date
            ORDER BY factor.effective_start_date DESC
        ) af
        WHERE tec.deleted = 0
          AND TRY_CAST(tec.electricity_consumption AS DECIMAL(28,10)) IS NOT NULL
    ),
    OwnedCars AS (
        SELECT
            TRY_CAST(t.[year] AS INT) AS activity_year,
            t.[month] AS month_name,
            mm.month_num,
            'WTT - Purchased Fuels' AS emission_category,
            'Owned Cars' AS source_integration,
            t.fuel_type AS activity_type,
            TRY_CAST(t.total_quantity AS DECIMAL(28,10)) AS quantity,
            'Litre' AS unit_name,
            af.ef_value,
            'kg CO2e/Litre' AS ef_unit,
            TRY_CAST(t.well_to_tank_emission AS DECIMAL(28,10)) * 1000.0 AS emissions_kg
        FROM target_owned_car t
        INNER JOIN ingestion_calendar ic ON ic.ingestion_calendar_id = t.ingestion_calendar_id
        INNER JOIN #MonthMap mm ON mm.month_name = t.[month]
        INNER JOIN #RequestedMonths rm ON rm.month_name = t.[month]
        INNER JOIN #YearRanges yr
            ON (
                t.[month] IN ('April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December')
                AND TRY_CAST(t.[year] AS INT) = yr.start_year
            )
            OR (
                t.[month] IN ('January', 'February', 'March')
                AND TRY_CAST(t.[year] AS INT) = yr.end_year
            )
        OUTER APPLY (
            SELECT TOP 1 af.ef_value
            FROM ActiveFactor af
            WHERE af.reference_key = CASE
                    WHEN t.fuel_type = 'Petrol' THEN 'Scope-3-Owned-Car-Petrol-Well-to-Tank'
                    ELSE 'Scope-3-Owned-Car-Diesel-Well-to-Tank'
                END
              AND ic.execute_date >= af.effective_start_date
              AND ic.execute_date <= af.effective_end_date
            ORDER BY af.effective_start_date DESC
        ) af
        WHERE t.deleted = 0
          AND TRY_CAST(t.well_to_tank_emission AS DECIMAL(28,10)) IS NOT NULL
    ),
    DgSets AS (
        SELECT
            TRY_CAST(t.[year] AS INT) AS activity_year,
            pm.month_name,
            pm.calendar_month_num AS month_num,
            'WTT - Purchased Fuels' AS emission_category,
            'DG Sets' AS source_integration,
            'Diesel' AS activity_type,
            TRY_CAST(t.total_quantity AS DECIMAL(28,10)) AS quantity,
            'Litre' AS unit_name,
            af.ef_value,
            'kg CO2e/Litre' AS ef_unit,
            TRY_CAST(t.well_to_tank_emission AS DECIMAL(28,10)) * 1000.0 AS emissions_kg
        FROM target_dg_set t
        INNER JOIN ingestion_calendar ic ON ic.ingestion_calendar_id = t.ingestion_calendar_id
        INNER JOIN #DgPeriodMap pm ON TRY_CAST(t.[period] AS INT) = pm.period_num
        INNER JOIN #RequestedMonths rm ON rm.month_name = pm.month_name
        INNER JOIN #YearRanges yr
            ON (
                pm.period_num BETWEEN 1 AND 9
                AND TRY_CAST(t.[year] AS INT) = yr.start_year
            )
            OR (
                pm.period_num BETWEEN 10 AND 12
                AND TRY_CAST(t.[year] AS INT) = yr.end_year
            )
        OUTER APPLY (
            SELECT TOP 1 af.ef_value
            FROM ActiveFactor af
            WHERE af.reference_key = 'Scope-3-Dg-Set-Diesel-Well-to-Tank'
              AND ic.execute_date >= af.effective_start_date
              AND ic.execute_date <= af.effective_end_date
            ORDER BY af.effective_start_date DESC
        ) af
        WHERE t.deleted = 0
          AND TRY_CAST(t.well_to_tank_emission AS DECIMAL(28,10)) IS NOT NULL
    ),
    Combined AS (
        SELECT * FROM Facilities
        UNION ALL
        SELECT * FROM OwnedCars
        UNION ALL
        SELECT * FROM DgSets
    ),
    Aggregated AS (
        SELECT
            activity_year AS [Year],
            month_name AS [Period],
            month_num,
            emission_category AS [Emission Category],
            source_integration AS [Source Integration],
            activity_type AS [Activity Type],
            CAST(SUM(quantity) AS DECIMAL(18,4)) AS [Quantity],
            unit_name AS [Unit],
            CAST(ef_value AS DECIMAL(18,6)) AS [EF],
            ef_unit AS [EF Unit],
            CAST(SUM(emissions_kg) AS DECIMAL(18,4)) AS [Emissions (kg CO2e)]
        FROM Combined
        GROUP BY
            activity_year,
            month_name,
            month_num,
            emission_category,
            source_integration,
            activity_type,
            unit_name,
            ef_value,
            ef_unit
    ),
    Ordered AS (
        SELECT
            [Year],
            [Period],
            [Emission Category],
            [Source Integration],
            [Activity Type],
            [Quantity],
            [Unit],
            [EF],
            [EF Unit],
            [Emissions (kg CO2e)],
            ROW_NUMBER() OVER (
                ORDER BY
                    [Year],
                    CASE [Period]
                        WHEN 'April' THEN 1 WHEN 'May' THEN 2 WHEN 'June' THEN 3
                        WHEN 'July' THEN 4 WHEN 'August' THEN 5 WHEN 'September' THEN 6
                        WHEN 'October' THEN 7 WHEN 'November' THEN 8 WHEN 'December' THEN 9
                        WHEN 'January' THEN 10 WHEN 'February' THEN 11 WHEN 'March' THEN 12
                        ELSE 0
                    END,
                    [Emission Category],
                    [Source Integration],
                    [Activity Type],
                    [Unit],
                    [EF],
                    [EF Unit]
            ) AS rn
        FROM Aggregated
    )
    SELECT
        [Year],
        [Period],
        [Emission Category],
        [Source Integration],
        [Activity Type],
        [Quantity],
        [Unit],
        [EF],
        [EF Unit],
        [Emissions (kg CO2e)]
    FROM Ordered
    WHERE (@p_page = 1 AND @p_limit = 1)
       OR (@p_page IS NULL OR @p_limit IS NULL OR @p_page <= 0 OR @p_limit <= 0)
       OR rn BETWEEN ((@p_page - 1) * @p_limit) + 1 AND (@p_page * @p_limit)
    ORDER BY rn;

    DROP TABLE #YearRanges;
    DROP TABLE #RequestedMonths;
    DROP TABLE #MonthMap;
    DROP TABLE #DgPeriodMap;
END;
GO


CREATE OR ALTER PROCEDURE [dbo].[CoLocationEnergyEmissionReport]
    @p_organization_id        VARCHAR(255),
    @p_reporting_year_periods VARCHAR(MAX),
    @p_page                   INT = NULL,
    @p_limit                  INT = NULL
AS
BEGIN
    SET NOCOUNT ON;

    CREATE TABLE #Results (
        reporting_year                             VARCHAR(255),
        reporting_period                           VARCHAR(255),
        [Site]                                     VARCHAR(255),
        [IT Energy Consumption (in kWh)]           DECIMAL(18,4),
        [PUE]                                      DECIMAL(18,4),
        [Total Energy Consumption (in kWh)]        DECIMAL(18,4),
        [Emission Factor]                          DECIMAL(18,8),
        [Scope 3 Emissions (in MTCO2e)]           DECIMAL(18,4),
        sort_row_id                                VARCHAR(36) NULL
    );

    CREATE TABLE #MonthsToProcess (
        month_name VARCHAR(20),
        month_num  INT
    );

    INSERT INTO #MonthsToProcess (month_name, month_num) VALUES
        ('January', 1), ('February', 2), ('March', 3),
        ('April', 4), ('May', 5), ('June', 6),
        ('July', 7), ('August', 8), ('September', 9),
        ('October', 10), ('November', 11), ('December', 12);

    -- Multi-year support
    DECLARE @year_token_cl NVARCHAR(50) = LEFT(@p_reporting_year_periods, CHARINDEX(':', @p_reporting_year_periods) - 1);
    DECLARE @from_year_cl INT;
    DECLARE @to_year_cl   INT;

    IF CHARINDEX('-', @year_token_cl) > 0
    BEGIN
        SET @from_year_cl = CAST(LEFT(@year_token_cl, CHARINDEX('-', @year_token_cl) - 1) AS INT);
        SET @to_year_cl   = CAST(SUBSTRING(@year_token_cl, CHARINDEX('-', @year_token_cl) + 1, LEN(@year_token_cl)) AS INT);
    END
    ELSE
    BEGIN
        SET @from_year_cl = CAST(@year_token_cl AS INT);
        SET @to_year_cl   = @from_year_cl + 1;
    END;

    CREATE TABLE #YearRangesCL (
        reporting_year VARCHAR(9),
        start_year     INT,
        end_year       INT
    );

    ;WITH Years AS (
        SELECT @from_year_cl AS y
        UNION ALL
        SELECT y + 1
        FROM Years
        WHERE y + 1 < @to_year_cl
    )
    INSERT INTO #YearRangesCL (reporting_year, start_year, end_year)
    SELECT
        CAST(y AS VARCHAR(4)) + '-' + CAST(y + 1 AS VARCHAR(4)) AS reporting_year,
        y,
        y + 1
    FROM Years
    OPTION (MAXRECURSION 32767);

    DECLARE @months_part VARCHAR(MAX) =
        SUBSTRING(@p_reporting_year_periods, CHARINDEX(':', @p_reporting_year_periods) + 1, LEN(@p_reporting_year_periods));

    CREATE TABLE #RequestedMonths (month_name VARCHAR(20));

    ;WITH SplitMonths AS (
        SELECT value AS month_name
        FROM STRING_SPLIT(REPLACE(REPLACE(@months_part, '''', ''), ' ', ''), ',')
    )
    INSERT INTO #RequestedMonths (month_name)
    SELECT month_name
    FROM SplitMonths;

    INSERT INTO #Results
    SELECT
        NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL;

    INSERT INTO #Results
    SELECT
        yr.reporting_year                                  AS reporting_year,
        m.month_name                                 AS reporting_period,
        c.[site]                                     AS [Site],
        CAST(c.it_energy_consumption      AS DECIMAL(18,4)) AS [IT Energy Consumption (in kWh)],
        CAST(c.pue                      AS DECIMAL(18,4)) AS [PUE],
        CAST(c.total_energy_consumption  AS DECIMAL(18,4)) AS [Total Energy Consumption (in kWh)],
        CAST(c.emission_factor           AS DECIMAL(18,8)) AS [Emission Factor],
        CAST(c.total_emission            AS DECIMAL(18,4)) AS [Scope 3 Emissions (in MTCO2e)],
        CONVERT(VARCHAR(36), c.target_co_location_id) AS sort_row_id
    FROM target_co_location c
	INNER JOIN #MonthsToProcess m ON c.month = m.month_name
    INNER JOIN #RequestedMonths rm
        ON m.month_name = rm.month_name
    INNER JOIN #YearRangesCL yr
        ON  (m.month_num >= 4 AND c.[year] = yr.start_year)
         OR (m.month_num <= 3 AND c.[year] = yr.end_year)

    ;WITH Ordered AS (
        SELECT *,
               ROW_NUMBER() OVER (
                   ORDER BY
                       CASE WHEN reporting_year IS NULL THEN 0 ELSE 1 END,
                       reporting_year,
                       CASE reporting_period
                           WHEN 'April' THEN 1
                           WHEN 'May' THEN 2
                           WHEN 'June' THEN 3
                           WHEN 'July' THEN 4
                           WHEN 'August' THEN 5
                           WHEN 'September' THEN 6
                           WHEN 'October' THEN 7
                           WHEN 'November' THEN 8
                           WHEN 'December' THEN 9
                           WHEN 'January' THEN 10
                           WHEN 'February' THEN 11
                           WHEN 'March' THEN 12
                       END,
                       [Site],
                       sort_row_id
               ) AS rn
        FROM #Results
    )
    SELECT
        reporting_year,
        reporting_period,
        [Site],
        [IT Energy Consumption (in kWh)],
        [PUE],
        [Total Energy Consumption (in kWh)],
        [Emission Factor],
        [Scope 3 Emissions (in MTCO2e)]
    FROM Ordered
    WHERE (@p_page = 1 AND @p_limit = 1)
       OR (@p_page IS NULL OR @p_limit IS NULL OR @p_page <= 0 OR @p_limit <= 0)
       OR rn BETWEEN ((@p_page - 1) * @p_limit) + 1
                  AND (@p_page * @p_limit)
    ORDER BY rn;

    DROP TABLE #Results;
    DROP TABLE #MonthsToProcess;
    DROP TABLE #RequestedMonths;
    DROP TABLE #YearRangesCL;
END;
GO


CREATE OR ALTER PROCEDURE [dbo].[DGSetEmissionReport]
    @p_organization_id        VARCHAR(255),
    @p_reporting_year_periods VARCHAR(MAX),
    @p_page                   INT = NULL,
    @p_limit                  INT = NULL
AS
BEGIN
    SET NOCOUNT ON;

    -- NEW: multi-year parsing
    DECLARE @year_token NVARCHAR(50) = LEFT(@p_reporting_year_periods, CHARINDEX(':', @p_reporting_year_periods) - 1);
    DECLARE @from_year INT;
    DECLARE @to_year   INT;

    IF CHARINDEX('-', @year_token) > 0
    BEGIN
        SET @from_year = CAST(LEFT(@year_token, CHARINDEX('-', @year_token) - 1) AS INT);
        SET @to_year   = CAST(SUBSTRING(@year_token, CHARINDEX('-', @year_token) + 1, LEN(@year_token)) AS INT);
    END
    ELSE
    BEGIN
        SET @from_year = CAST(@year_token AS INT);
        SET @to_year   = @from_year + 1;
    END;

    CREATE TABLE #YearRanges (
        reporting_year VARCHAR(9),
        start_year     INT,
        end_year       INT
    );

    ;WITH Years AS (
        SELECT @from_year AS y
        UNION ALL
        SELECT y + 1
        FROM Years
        WHERE y + 1 < @to_year
    )
    INSERT INTO #YearRanges (reporting_year, start_year, end_year)
    SELECT
        CAST(y AS VARCHAR(4)) + '-' + CAST(y + 1 AS VARCHAR(4)) AS reporting_year,
        y,
        y + 1
    FROM Years
    OPTION (MAXRECURSION 32767);

    DECLARE @months_part VARCHAR(MAX) = RIGHT(@p_reporting_year_periods, LEN(@p_reporting_year_periods) - CHARINDEX(':', @p_reporting_year_periods));

    CREATE TABLE #MonthMap (MName VARCHAR(20), MNum INT);
    INSERT INTO #MonthMap VALUES
        ('January',10),('February',11),('March',12),
        ('April',1),('May',2),('June',3),
        ('July',4),('August',5),('September',6),
        ('October',7),('November',8),('December',9);

    ;WITH Base AS (
        SELECT
            ic.reporting_year AS [Reporting Year],
            mm.MName          AS [Reporting Period],
            t.account         AS [Account],
            t.offsetting_account_name AS [Offsetting Account Name],
            t.hsn_sac         AS [HSN SAC],
            t.user_name       AS [User Name],
            t.cost_ctr        AS [Cost Center],
            t.itm             AS [Item],
            t.inv_ref         AS [Invoice Reference],
            t.[year]          AS [Year],
            t.document_header_text AS [Document Header Text],
            ISNULL(TRY_CAST(t.amount_local_currency AS DECIMAL(18,2)), 0) AS [Amount Local Currency],
            t.local_currency  AS [Local Currency],
            ISNULL(TRY_CAST(t.unit_price AS DECIMAL(18,4)), 0)           AS [Unit Price],
            ISNULL(TRY_CAST(t.total_quantity AS DECIMAL(18,4)), 0)       AS [Total Quantity],
            ISNULL(TRY_CAST(t.emission_factor AS DECIMAL(18,6)), 0)      AS [Emission Factor],
            ISNULL(TRY_CAST(t.total_emission AS DECIMAL(18,4)) / 1000.0, 0) AS [Scope 1 Emissions (mtCO2e)],
            ISNULL(TRY_CAST(t.well_to_tank_emission AS DECIMAL(18,4)), 0) AS [Well to Tank Emission (mtCO2e)],
            ISNULL(TRY_CAST(t.non_renewable_fuel_energy AS DECIMAL(18,4)), 0) AS [Non Renewable Fuel Energy (GJ)],
            CONVERT(VARCHAR(36), t.target_dg_set_id) AS sort_row_id
        FROM target_dg_set t
        INNER JOIN ingestion_calendar ic ON ic.ingestion_calendar_id = t.ingestion_calendar_id
        INNER JOIN #MonthMap mm ON t.[period] = mm.MNum
        INNER JOIN #YearRanges yr
        ON ic.reporting_year = yr.reporting_year
        WHERE  t.deleted = 0
          AND CHARINDEX(mm.MName, @months_part) > 0
    ),
    Ordered AS (
        SELECT *,
               ROW_NUMBER() OVER (
                   ORDER BY TRY_CAST([Year] AS INT), MNum, sort_row_id
               ) AS rn
        FROM Base b
        INNER JOIN #MonthMap mm ON b.[Reporting Period] = mm.MName
    )
    SELECT
        [Reporting Year],
        [Reporting Period],
        [Account],
        [Offsetting Account Name],
        [HSN SAC],
        [User Name],
        [Cost Center],
        [Item],
        [Invoice Reference],
        [Year],
        [Document Header Text],
        [Amount Local Currency],
        [Local Currency],
        [Unit Price],
        [Total Quantity],
        [Emission Factor],
        [Scope 1 Emissions (mtCO2e)],
        [Well to Tank Emission (mtCO2e)],
        [Non Renewable Fuel Energy (GJ)]
    FROM Ordered
    WHERE (@p_page = 1 AND @p_limit = 1)
       OR (@p_page IS NULL OR @p_limit IS NULL OR @p_page <= 0 OR @p_limit <= 0)
       OR rn BETWEEN ((@p_page - 1) * @p_limit) + 1
                  AND (@p_page * @p_limit)
    ORDER BY rn;

    DROP TABLE #YearRanges;
    DROP TABLE #MonthMap;
END;
GO


CREATE OR ALTER PROCEDURE [dbo].[EmployeeCommuteReport]
    @p_organization_id        VARCHAR(255),
    @p_reporting_year_periods VARCHAR(MAX),
    @p_page                   INT = NULL,
    @p_limit                  INT = NULL
AS
BEGIN
    CREATE TABLE #Results (
        reporting_year                    VARCHAR(255),
        reporting_period                  VARCHAR(255),
        employee_grade                    VARCHAR(50),
        rbi_classification                VARCHAR(50),
        type_of_fuel                      VARCHAR(50),
        mode_of_travel                    VARCHAR(100),
        [Average Distance (km)]           DECIMAL(18,4),
        [Two Way Distance (km)]           DECIMAL(18,4),
        [Surveyed Employees]              INT,
        [Employee Ratio]                  DECIMAL(18,8),
        [Extrapolated Count]              DECIMAL(18,4),
        [Yearly Distance (km)]            DECIMAL(18,4),
        [Mode Wise Yearly Distance (km)]  DECIMAL(18,4),
        [Emission Factor]                 DECIMAL(18,5),
        [Total Emissions (mtCO2e)]        DECIMAL(18,4),
        sort_row_id                       VARCHAR(36) NULL
    );

    CREATE TABLE #MonthsToProcess (
        month_name VARCHAR(20),
        month_num  INT
    );

    INSERT INTO #MonthsToProcess (month_name, month_num) VALUES
        ('January', 1), ('February', 2), ('March', 3),
        ('April', 4), ('May', 5), ('June', 6),
        ('July', 7), ('August', 8), ('September', 9),
        ('October', 10), ('November', 11), ('December', 12);

    -- Multi-year support
    DECLARE @year_token NVARCHAR(50) = LEFT(@p_reporting_year_periods, CHARINDEX(':', @p_reporting_year_periods) - 1);
    DECLARE @from_year INT;
    DECLARE @to_year   INT;

    IF CHARINDEX('-', @year_token) > 0
    BEGIN
        SET @from_year = CAST(LEFT(@year_token, CHARINDEX('-', @year_token) - 1) AS INT);
        SET @to_year   = CAST(SUBSTRING(@year_token, CHARINDEX('-', @year_token) + 1, LEN(@year_token)) AS INT);
    END
    ELSE
    BEGIN
        SET @from_year = CAST(@year_token AS INT);
        SET @to_year   = @from_year + 1;
    END;

    CREATE TABLE #YearRanges (
        reporting_year VARCHAR(9),
        start_year     INT,
        end_year       INT
    );

    ;WITH Years AS (
        SELECT @from_year AS y
        UNION ALL
        SELECT y + 1
        FROM Years
        WHERE y + 1 < @to_year
    )
    INSERT INTO #YearRanges (reporting_year, start_year, end_year)
    SELECT
        CAST(y AS VARCHAR(4)) + '-' + CAST(y + 1 AS VARCHAR(4)) AS reporting_year,
        y,
        y + 1
    FROM Years
    OPTION (MAXRECURSION 32767);

    DECLARE @months_part VARCHAR(MAX) =
        SUBSTRING(@p_reporting_year_periods, CHARINDEX(':', @p_reporting_year_periods) + 1, LEN(@p_reporting_year_periods));

    CREATE TABLE #RequestedMonths (month_name VARCHAR(20));

    ;WITH SplitMonths AS (
        SELECT value AS month_name
        FROM STRING_SPLIT(REPLACE(REPLACE(@months_part, '''', ''), ' ', ''), ',')
    )
    INSERT INTO #RequestedMonths
    SELECT month_name
    FROM SplitMonths;

    INSERT INTO #Results
    SELECT
        ic.reporting_year                                      AS reporting_year,
        DATENAME(MONTH, ic.execute_date)                       AS reporting_period,
        t.employee_grade,
        t.rbi_classification,
        t.type_of_fuel,
        t.mode_of_travel,
        CAST(NULLIF(t.avg_distance,'')                    AS DECIMAL(18,4)) AS [Average Distance (km)],
        CAST(NULLIF(t.two_way_distance,'')                AS DECIMAL(18,4)) AS [Two Way Distance (km)],
        CAST(NULLIF(t.count_of_surveyed_emp,'')           AS INT)           AS [Surveyed Employees],
        CAST(NULLIF(t.ratio,'')                           AS DECIMAL(18,8)) AS [Employee Ratio],
        CAST(NULLIF(t.extrapolated_count,'')              AS DECIMAL(18,4)) AS [Extrapolated Count],
        CAST(NULLIF(t.yearly_distance,'')                 AS DECIMAL(18,4)) AS [Yearly Distance (km)],
        CAST(NULLIF(t.mode_wise_yearly_distance_travel,'') AS DECIMAL(18,4)) AS [Mode Wise Yearly Distance (km)],
        CAST(NULLIF(t.emission_factor,'')                 AS DECIMAL(18,5)) AS [Emission Factor],
        CAST(CAST(NULLIF(t.mode_wise_yearly_total_emission,'') AS DECIMAL(38,20)) / 1000.0 AS DECIMAL(18,4)) AS [Total Emissions (mtCO2e)],
        CONVERT(VARCHAR(36), t.target_employee_commute_calculated_id) AS sort_row_id
    FROM target_employee_commute_calculated_data t
    INNER JOIN ingestion_calendar ic
        ON ic.ingestion_calendar_id = t.ingestion_calendar_id
    INNER JOIN #MonthsToProcess m
        ON DATENAME(MONTH, ic.execute_date) = m.month_name
    INNER JOIN #RequestedMonths rm
        ON m.month_name = rm.month_name
    INNER JOIN #YearRanges yr
        ON ic.reporting_year = yr.reporting_year;

    ;WITH Ordered AS (
        SELECT *,
               ROW_NUMBER() OVER (
                   ORDER BY
                       CASE WHEN reporting_year IS NULL THEN 0 ELSE 1 END,
                       reporting_year,
                       CASE reporting_period
                           WHEN 'April' THEN 1
                           WHEN 'May' THEN 2
                           WHEN 'June' THEN 3
                           WHEN 'July' THEN 4
                           WHEN 'August' THEN 5
                           WHEN 'September' THEN 6
                           WHEN 'October' THEN 7
                           WHEN 'November' THEN 8
                           WHEN 'December' THEN 9
                           WHEN 'January' THEN 10
                           WHEN 'February' THEN 11
                           WHEN 'March' THEN 12
                       END,
                       employee_grade,
                       rbi_classification,
                       mode_of_travel,
                       sort_row_id
               ) AS rn
        FROM #Results
    )
    SELECT
        reporting_year,
        reporting_period,
        employee_grade,
        rbi_classification,
        type_of_fuel,
        mode_of_travel,
        [Average Distance (km)],
        [Two Way Distance (km)],
        [Surveyed Employees],
        [Employee Ratio],
        [Extrapolated Count],
        [Yearly Distance (km)],
        [Mode Wise Yearly Distance (km)],
        [Emission Factor],
        [Total Emissions (mtCO2e)]
    FROM Ordered
    WHERE (@p_page = 1 AND @p_limit = 1)
       OR (@p_page IS NULL OR @p_limit IS NULL OR @p_page <= 0 OR @p_limit <= 0)
       OR rn BETWEEN ((@p_page - 1) * @p_limit) + 1
                  AND (@p_page * @p_limit)
    ORDER BY rn;

    DROP TABLE #Results;
    DROP TABLE #MonthsToProcess;
    DROP TABLE #RequestedMonths;
    DROP TABLE #YearRanges;
END;
GO


CREATE OR ALTER PROCEDURE [dbo].[EmployeeCommuteSurveyReport]
    @p_organization_id        VARCHAR(255),
    @p_reporting_year_periods VARCHAR(MAX),
    @p_page                   INT = NULL,
    @p_limit                  INT = NULL
AS
BEGIN
    CREATE TABLE #Results (
        reporting_year          VARCHAR(255),
        reporting_period        VARCHAR(255),
        type_of_fuel            VARCHAR(50),
        [One Way Distance (km)] DECIMAL(18,2),
        mode_of_travel          VARCHAR(100),
        city                    VARCHAR(100),
        state                   VARCHAR(100),
        rbi_classification      VARCHAR(50),
        employee_grade          VARCHAR(50),
        sort_row_id             VARCHAR(36) NULL
    );

    CREATE TABLE #MonthsToProcess (
        month_name VARCHAR(20),
        month_num  INT
    );

    INSERT INTO #MonthsToProcess (month_name, month_num) VALUES
        ('January', 1), ('February', 2), ('March', 3),
        ('April', 4), ('May', 5), ('June', 6),
        ('July', 7), ('August', 8), ('September', 9),
        ('October', 10), ('November', 11), ('December', 12);

    -- Multi-year support
    DECLARE @year_token NVARCHAR(50) = LEFT(@p_reporting_year_periods, CHARINDEX(':', @p_reporting_year_periods) - 1);
    DECLARE @from_year INT;
    DECLARE @to_year   INT;

    IF CHARINDEX('-', @year_token) > 0
    BEGIN
        SET @from_year = CAST(LEFT(@year_token, CHARINDEX('-', @year_token) - 1) AS INT);
        SET @to_year   = CAST(SUBSTRING(@year_token, CHARINDEX('-', @year_token) + 1, LEN(@year_token)) AS INT);
    END
    ELSE
    BEGIN
        SET @from_year = CAST(@year_token AS INT);
        SET @to_year   = @from_year + 1;
    END;

    CREATE TABLE #YearRanges (
        reporting_year VARCHAR(9),
        start_year     INT,
        end_year       INT
    );

    ;WITH Years AS (
        SELECT @from_year AS y
        UNION ALL
        SELECT y + 1
        FROM Years
        WHERE y + 1 < @to_year
    )
    INSERT INTO #YearRanges (reporting_year, start_year, end_year)
    SELECT
        CAST(y AS VARCHAR(4)) + '-' + CAST(y + 1 AS VARCHAR(4)) AS reporting_year,
        y,
        y + 1
    FROM Years
    OPTION (MAXRECURSION 32767);

    DECLARE @months_part VARCHAR(MAX) =
        SUBSTRING(@p_reporting_year_periods, CHARINDEX(':', @p_reporting_year_periods) + 1, LEN(@p_reporting_year_periods));

    CREATE TABLE #RequestedMonths (month_name VARCHAR(20));

    ;WITH SplitMonths AS (
        SELECT value AS month_name
        FROM STRING_SPLIT(REPLACE(REPLACE(@months_part, '''', ''), ' ', ''), ',')
    )
    INSERT INTO #RequestedMonths
    SELECT month_name
    FROM SplitMonths;

    INSERT INTO #Results
    SELECT
        ic.reporting_year                                AS reporting_year,
        DATENAME(MONTH, ic.execute_date)                 AS reporting_period,
        t.type_of_fuel,
        t.avg_one_way_distance                           AS [One Way Distance (km)],
        t.mode_of_travel,
        t.city,
        t.state,
        t.rbi_classification,
        t.employee_grade,
        CONVERT(VARCHAR(36), t.target_employee_commute_survey_id) AS sort_row_id
    FROM target_employee_commute_survey t
    INNER JOIN ingestion_calendar ic
        ON ic.ingestion_calendar_id = t.ingestion_calendar_id
    INNER JOIN #MonthsToProcess m
        ON DATENAME(MONTH, ic.execute_date) = m.month_name
    INNER JOIN #RequestedMonths rm
        ON m.month_name = rm.month_name
    INNER JOIN #YearRanges yr
        ON ic.reporting_year = yr.reporting_year;

    ;WITH Ordered AS (
        SELECT *,
               ROW_NUMBER() OVER (
                   ORDER BY
                       CASE WHEN reporting_year IS NULL THEN 0 ELSE 1 END,
                       reporting_year,
                       CASE reporting_period
                           WHEN 'April' THEN 1
                           WHEN 'May' THEN 2
                           WHEN 'June' THEN 3
                           WHEN 'July' THEN 4
                           WHEN 'August' THEN 5
                           WHEN 'September' THEN 6
                           WHEN 'October' THEN 7
                           WHEN 'November' THEN 8
                           WHEN 'December' THEN 9
                           WHEN 'January' THEN 10
                           WHEN 'February' THEN 11
                           WHEN 'March' THEN 12
                       END,
                       state,
                       city,
                       employee_grade,
                       mode_of_travel,
                       sort_row_id
               ) AS rn
        FROM #Results
    )
    SELECT
        reporting_year,
        reporting_period,
        type_of_fuel,
        [One Way Distance (km)],
        mode_of_travel,
        city,
        state,
        rbi_classification,
        employee_grade
    FROM Ordered
    WHERE (@p_page = 1 AND @p_limit = 1)
       OR (@p_page IS NULL OR @p_limit IS NULL OR @p_page <= 0 OR @p_limit <= 0)
       OR rn BETWEEN ((@p_page - 1) * @p_limit) + 1
                  AND (@p_page * @p_limit)
    ORDER BY rn;

    DROP TABLE #Results;
    DROP TABLE #MonthsToProcess;
    DROP TABLE #RequestedMonths;
    DROP TABLE #YearRanges;
END;
GO


CREATE OR ALTER PROCEDURE [dbo].[EnergyConsumptionReport]
    @p_organization_id        VARCHAR(255),
    @p_reporting_year_periods VARCHAR(MAX),
    @p_page                   INT = NULL,
    @p_limit                  INT = NULL
AS
BEGIN
    SET NOCOUNT ON;

    CREATE TABLE #MonthsToProcess (
        month_name  VARCHAR(20) NOT NULL PRIMARY KEY,
        month_num   INT NOT NULL,
        period_sort INT NOT NULL
    );

    INSERT INTO #MonthsToProcess (month_name, month_num, period_sort) VALUES
        ('January', 1, 1), ('February', 2, 2), ('March', 3, 3),
        ('April', 4, 4), ('May', 5, 7), ('June', 6, 6),
        ('July', 7, 9), ('August', 8, 8), ('September', 9, 11),
        ('October', 10, 10), ('November', 11, 11), ('December', 12, 12);

    -- Multi-year support
    DECLARE @year_token NVARCHAR(50) = LEFT(@p_reporting_year_periods, CHARINDEX(':', @p_reporting_year_periods) - 1);
    DECLARE @from_year INT;
    DECLARE @to_year   INT;

    IF CHARINDEX('-', @year_token) > 0
    BEGIN
        SET @from_year = CAST(LEFT(@year_token, CHARINDEX('-', @year_token) - 1) AS INT);
        SET @to_year   = CAST(SUBSTRING(@year_token, CHARINDEX('-', @year_token) + 1, LEN(@year_token)) AS INT);
    END
    ELSE
    BEGIN
        SET @from_year = CAST(@year_token AS INT);
        SET @to_year   = @from_year + 1;
    END;

    CREATE TABLE #YearRanges (
        reporting_year VARCHAR(9),
        start_year     INT,
        end_year       INT
    );

    ;WITH Years AS (
        SELECT @from_year AS y
        UNION ALL
        SELECT y + 1
        FROM Years
        WHERE y + 1 < @to_year
    )
    INSERT INTO #YearRanges (reporting_year, start_year, end_year)
    SELECT
        CAST(y AS VARCHAR(4)) + '-' + CAST(y + 1 AS VARCHAR(4)) AS reporting_year,
        y,
        y + 1
    FROM Years
    OPTION (MAXRECURSION 32767);

    DECLARE @months_part VARCHAR(MAX) =
        SUBSTRING(@p_reporting_year_periods, CHARINDEX(':', @p_reporting_year_periods) + 1, LEN(@p_reporting_year_periods));

    CREATE TABLE #RequestedMonths (
        month_name VARCHAR(20) NOT NULL PRIMARY KEY
    );

    INSERT INTO #RequestedMonths (month_name)
    SELECT DISTINCT LTRIM(RTRIM(value))
    FROM STRING_SPLIT(REPLACE(REPLACE(@months_part, '''', ''), ' ', ''), ',')
    WHERE LTRIM(RTRIM(value)) <> '';

    DECLARE @return_all BIT =
        CASE
            WHEN @p_page = 1 AND @p_limit = 1 THEN 1
            WHEN @p_page IS NULL OR @p_limit IS NULL OR @p_page <= 0 OR @p_limit <= 0 THEN 1
            ELSE 0
        END;

    CREATE TABLE #Page (
        reporting_year          VARCHAR(255) NULL,
        reporting_period        VARCHAR(255) NULL,
        sol_id                  VARCHAR(255) NULL,
        ifm_month               INT NULL,
        ifm_year                INT NULL,
        electricity_consumption VARCHAR(255) NULL,
        renewable_energy_units  VARCHAR(255) NULL,
        green_tariff_units      VARCHAR(255) NULL,
        groundwater_litres      VARCHAR(255) NULL,
        thirdpartywater_litres  VARCHAR(255) NULL,
        total_emissions         VARCHAR(255) NULL,
        sort_row_id             VARCHAR(36) NOT NULL,
        rn                      INT NOT NULL PRIMARY KEY
    );

    INSERT INTO #Page (
        reporting_year, reporting_period, sol_id, ifm_month, ifm_year,
        electricity_consumption, renewable_energy_units, green_tariff_units,
        groundwater_litres, thirdpartywater_litres, total_emissions,
        sort_row_id, rn
    )
    SELECT
        reporting_year, reporting_period, sol_id, ifm_month, ifm_year,
        electricity_consumption, renewable_energy_units, green_tariff_units,
        groundwater_litres, thirdpartywater_litres, total_emissions,
        sort_row_id, rn
    FROM (
        SELECT
            yr.reporting_year,
            m.month_name AS reporting_period,
            t.sol_id,
            CAST(t.ifm_month AS INT) AS ifm_month,
            CAST(t.ifm_year AS INT) AS ifm_year,
            t.electricity_consumption,
            t.renewable_energy_units,
            t.green_tariff_units,
            t.groundwater_litres,
            t.thirdpartywater_litres,
            t.total_emissions,
            CONVERT(VARCHAR(36), t.target_energy_consumption_id) AS sort_row_id,
            ROW_NUMBER() OVER (
                ORDER BY
                    CASE WHEN yr.reporting_year IS NULL THEN 0 ELSE 1 END,
                    yr.reporting_year,
                    m.period_sort,
                    t.sol_id,
                    CAST(t.ifm_year AS INT),
                    CAST(t.ifm_month AS INT),
                    CONVERT(VARCHAR(36), t.target_energy_consumption_id)
            ) AS rn
        FROM target_energy_consumption AS t
        INNER JOIN #MonthsToProcess m
            ON t.ifm_month = m.month_num
        INNER JOIN #RequestedMonths rm
            ON m.month_name = rm.month_name
        INNER JOIN #YearRanges yr
            ON (m.month_num >= 4 AND t.ifm_year = yr.start_year)
            OR (m.month_num <= 3 AND t.ifm_year = yr.end_year)
    ) numbered
    WHERE @return_all = 1
       OR rn BETWEEN ((@p_page - 1) * @p_limit) + 1 AND (@p_page * @p_limit);

    CREATE TABLE #NeedSol (
        sol_id VARCHAR(255) NOT NULL PRIMARY KEY
    );

    INSERT INTO #NeedSol (sol_id)
    SELECT DISTINCT sol_id
    FROM #Page
    WHERE sol_id IS NOT NULL;

    CREATE TABLE #SolLocation (
        primary_sol_id VARCHAR(255) NOT NULL PRIMARY KEY,
        location_name  VARCHAR(255) NULL,
        state_name     VARCHAR(255) NULL,
        city_name      VARCHAR(255) NULL
    );

    IF EXISTS (SELECT 1 FROM #NeedSol)
    BEGIN
        INSERT INTO #SolLocation (primary_sol_id, location_name, state_name, city_name)
        SELECT primary_sol_id, location_name, state_name, city_name
        FROM (
            SELECT
                ld.primary_sol_id,
                l.location_name,
                sm.state AS state_name,
                cm.city AS city_name,
                ROW_NUMBER() OVER (
                    PARTITION BY ld.primary_sol_id
                    ORDER BY ld.location_detail_id
                ) AS pick
            FROM location_details ld
            INNER HASH JOIN #NeedSol n
                ON n.sol_id = ld.primary_sol_id
            LEFT JOIN location l
                ON l.location_id = ld.location_id
            LEFT JOIN state_master sm
                ON sm.state_id = ld.state_id
            LEFT JOIN city_master cm
                ON cm.city_id = ld.city_id
        ) ranked
        WHERE pick = 1;
    END;

    SELECT
        p.reporting_year,
        p.reporting_period,
        p.sol_id AS [Sol_ID],
        COALESCE(loc.location_name, 'NA') AS [Location_Name],
        COALESCE(loc.state_name, 'NA') AS [State_Name],
        COALESCE(loc.city_name, 'NA') AS [City_Name],
        p.ifm_month AS [IFM_Month],
        p.ifm_year AS [IFM_Year],
        CAST(p.electricity_consumption AS DECIMAL(18,4)) AS [Electricity_Consumption (GJ)],
        CAST(p.renewable_energy_units AS DECIMAL(18,4)) AS [Renewable_Energy_Units (GJ)],
        CAST(p.green_tariff_units AS DECIMAL(18,4)) AS [Green_Tariff_Units (GJ)],
        CAST(p.groundwater_litres AS DECIMAL(18,4)) AS [Groundwater (KL)],
        CAST(p.thirdpartywater_litres AS DECIMAL(18,4)) AS [Third_Party_Water (KL)],
        CAST(p.total_emissions AS DECIMAL(18,4)) AS [Total_Emissions (mtCO2e)]
    FROM #Page p
    LEFT JOIN #SolLocation loc
        ON loc.primary_sol_id = p.sol_id
    ORDER BY p.rn;

    DROP TABLE #Page;
    DROP TABLE #NeedSol;
    DROP TABLE #SolLocation;
    DROP TABLE #MonthsToProcess;
    DROP TABLE #RequestedMonths;
    DROP TABLE #YearRanges;
END;
GO


CREATE OR ALTER PROCEDURE [dbo].[ESettlementReport]
    @p_organization_id        VARCHAR(255),
    @p_reporting_year_periods VARCHAR(MAX),
    @p_page                   INT = NULL,
    @p_limit                  INT = NULL
AS
BEGIN
    SET NOCOUNT ON;

    CREATE TABLE #Results (
        reporting_year              VARCHAR(255),
        reporting_period            VARCHAR(255),
        [Travel Mode]               VARCHAR(255),
        [Fuel Type]                 VARCHAR(255),
        [Total Amount]              DECIMAL(18,2),
        [Total Distance]            DECIMAL(18,2),
        [Total Emissions (mt CO2e)] DECIMAL(18,4),
        [Cost per Distance]         DECIMAL(18,2)
    );

    -- Multi-year support
    DECLARE @year_token NVARCHAR(50) = LEFT(@p_reporting_year_periods, CHARINDEX(':', @p_reporting_year_periods) - 1);
    DECLARE @from_year INT;
    DECLARE @to_year   INT;

    IF CHARINDEX('-', @year_token) > 0
    BEGIN
        SET @from_year = CAST(LEFT(@year_token, CHARINDEX('-', @year_token) - 1) AS INT);
        SET @to_year   = CAST(SUBSTRING(@year_token, CHARINDEX('-', @year_token) + 1, LEN(@year_token)) AS INT);
    END
    ELSE
    BEGIN
        SET @from_year = CAST(@year_token AS INT);
        SET @to_year   = @from_year + 1;
    END;

    CREATE TABLE #YearRanges (
        reporting_year VARCHAR(9),
        start_year     INT,
        end_year       INT
    );

    ;WITH Years AS (
        SELECT @from_year AS y
        UNION ALL
        SELECT y + 1
        FROM Years
        WHERE y + 1 < @to_year
    )
    INSERT INTO #YearRanges (reporting_year, start_year, end_year)
    SELECT
        CAST(y AS VARCHAR(4)) + '-' + CAST(y + 1 AS VARCHAR(4)) AS reporting_year,
        y,
        y + 1
    FROM Years
    OPTION (MAXRECURSION 32767);

    CREATE TABLE #RequestedMonths ( month_name VARCHAR(20) PRIMARY KEY );

    INSERT INTO #RequestedMonths
    SELECT value AS month_name
    FROM STRING_SPLIT(
        REPLACE(
            REPLACE(
                SUBSTRING(@p_reporting_year_periods, CHARINDEX(':', @p_reporting_year_periods) + 1, LEN(@p_reporting_year_periods)),
                '''', ''
            ),
            ' ', ''
        ),
        ','
    );

    INSERT INTO #Results
    SELECT
        yr.reporting_year                                                     AS reporting_year,
        DATENAME(month, t.claim_process_date)                                      AS reporting_period,
        t.travel_mode                                                        AS [Travel Mode],
        t.fuel_type                                                          AS [Fuel Type],
        CAST(SUM(CAST(ISNULL(t.amount,   0) AS DECIMAL(38,2))) AS DECIMAL(18,2)) AS [Total Amount],
        CAST(SUM(CAST(ISNULL(t.distance, 0) AS DECIMAL(38,2))) AS DECIMAL(18,2)) AS [Total Distance],
        CAST(SUM(CAST(ISNULL(t.total_emission, 0) AS DECIMAL(38,4))) AS DECIMAL(18,4)) / 1000 AS [Total Emissions (mt CO2e)],
        CASE
            WHEN SUM(CAST(ISNULL(t.distance, 0) AS DECIMAL(38,2))) > 0
                THEN CAST(
                        SUM(CAST(ISNULL(t.amount, 0)   AS DECIMAL(38,2)))
                        / SUM(CAST(ISNULL(t.distance, 0) AS DECIMAL(38,2)))
                     AS DECIMAL(18,2))
            ELSE 0
        END AS [Cost per Distance]
    FROM target_e_settlement t
    INNER JOIN #RequestedMonths rm
        ON DATENAME(month, t.claim_process_date) = rm.month_name
    INNER JOIN #YearRanges yr
        ON (
               DATENAME(month, t.claim_process_date) IN ('April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December')
               AND YEAR(t.claim_process_date) = yr.start_year
           )
        OR (
               DATENAME(month, t.claim_process_date) IN ('January', 'February', 'March')
               AND YEAR(t.claim_process_date) = yr.end_year
           )
    WHERE t.deleted = 0
    GROUP BY yr.reporting_year, DATENAME(month, t.claim_process_date), t.travel_mode, t.fuel_type
    HAVING SUM(CAST(ISNULL(t.total_emission, 0) AS DECIMAL(38,4))) >= 0;

    ;WITH Ordered AS (
        SELECT *,
               ROW_NUMBER() OVER (
                   ORDER BY
                       CASE WHEN reporting_year IS NULL THEN 0 ELSE 1 END,
                       reporting_year,
                       CASE reporting_period
                           WHEN 'April' THEN 1
                           WHEN 'May' THEN 2
                           WHEN 'June' THEN 3
                           WHEN 'July' THEN 4
                           WHEN 'August' THEN 5
                           WHEN 'September' THEN 6
                           WHEN 'October' THEN 7
                           WHEN 'November' THEN 8
                           WHEN 'December' THEN 9
                           WHEN 'January' THEN 10
                           WHEN 'February' THEN 11
                           WHEN 'March' THEN 12
                       END,
                       [Travel Mode],
                       [Fuel Type]
               ) AS rn
        FROM #Results
    )
    SELECT
        reporting_year,
        reporting_period,
        [Travel Mode],
        [Fuel Type],
        [Total Amount],
        [Total Distance],
        [Total Emissions (mt CO2e)],
        [Cost per Distance]
    FROM Ordered
    WHERE (@p_page = 1 AND @p_limit = 1)
       OR (@p_page IS NULL OR @p_limit IS NULL OR @p_page <= 0 OR @p_limit <= 0)
       OR rn BETWEEN ((@p_page - 1) * @p_limit) + 1
                  AND (@p_page * @p_limit)
    ORDER BY rn;

    DROP TABLE #Results;
    DROP TABLE #RequestedMonths;
    DROP TABLE #YearRanges;
END;
GO


CREATE OR ALTER PROCEDURE [dbo].[FacilityReport]
    @p_organization_id        VARCHAR(255),
    @p_reporting_year_periods VARCHAR(MAX),
    @p_page                   INT = NULL,
    @p_limit                  INT = NULL
AS
BEGIN
    CREATE TABLE #Results (
        reporting_year                            VARCHAR(255),
        reporting_period                          VARCHAR(255),
        [Renewable Energy Consumption (in GJ)]    DECIMAL(18,4),
        [Non Renewable Energy Consumption (in GJ)] DECIMAL(18,4),
        [Ground Water (in kL)]                    DECIMAL(18,4),
        [Third Party Water (in kL)]               DECIMAL(18,4),
        [Scope 2 Emission (in mtCO2e)]            DECIMAL(18,4)
    );

    CREATE TABLE #MonthsToProcess (
        month_name VARCHAR(20),
        month_num  INT
    );

    INSERT INTO #MonthsToProcess (month_name, month_num) VALUES
        ('January', 1), ('February', 2), ('March', 3),
        ('April', 4), ('May', 5), ('June', 6),
        ('July', 7), ('August', 8), ('September', 9),
        ('October', 10), ('November', 11), ('December', 12);

    -- Multi-year support
    DECLARE @year_token NVARCHAR(50) = LEFT(@p_reporting_year_periods, CHARINDEX(':', @p_reporting_year_periods) - 1);
    DECLARE @from_year INT;
    DECLARE @to_year   INT;

    IF CHARINDEX('-', @year_token) > 0
    BEGIN
        SET @from_year = CAST(LEFT(@year_token, CHARINDEX('-', @year_token) - 1) AS INT);
        SET @to_year   = CAST(SUBSTRING(@year_token, CHARINDEX('-', @year_token) + 1, LEN(@year_token)) AS INT);
    END
    ELSE
    BEGIN
        SET @from_year = CAST(@year_token AS INT);
        SET @to_year   = @from_year + 1;
    END;

    CREATE TABLE #YearRanges (
        reporting_year VARCHAR(9),
        start_year     INT,
        end_year       INT
    );

    ;WITH Years AS (
        SELECT @from_year AS y
        UNION ALL
        SELECT y + 1
        FROM Years
        WHERE y + 1 < @to_year
    )
    INSERT INTO #YearRanges (reporting_year, start_year, end_year)
    SELECT
        CAST(y AS VARCHAR(4)) + '-' + CAST(y + 1 AS VARCHAR(4)) AS reporting_year,
        y,
        y + 1
    FROM Years
    OPTION (MAXRECURSION 32767);

    DECLARE @months_part VARCHAR(MAX) =
        SUBSTRING(@p_reporting_year_periods, CHARINDEX(':', @p_reporting_year_periods) + 1, LEN(@p_reporting_year_periods));

    CREATE TABLE #RequestedMonths (month_name VARCHAR(20));

    ;WITH SplitMonths AS (
        SELECT value AS month_name
        FROM STRING_SPLIT(REPLACE(REPLACE(@months_part, '''', ''), ' ', ''), ',')
    )
    INSERT INTO #RequestedMonths
    SELECT month_name
    FROM SplitMonths;

    INSERT INTO #Results
SELECT
  yr.reporting_year AS reporting_year,
  m.month_name AS reporting_period,
  CAST(COALESCE(
          SUM(CAST(t.renewable_energy_units AS DECIMAL(38,20)))
        + SUM(CAST(t.green_tariff_units     AS DECIMAL(38,20))), 0
      ) AS DECIMAL(18,4)) AS [Renewable Energy Consumption (in GJ)],
  CAST(COALESCE(
          SUM(CAST(t.electricity_consumption AS DECIMAL(38,20)))
        - SUM(CAST(t.green_tariff_units      AS DECIMAL(38,20))), 0
      ) AS DECIMAL(18,4)) AS [Non Renewable Energy Consumption (in GJ)],
  CAST(COALESCE(SUM(CAST(t.groundwater_litres     AS DECIMAL(38,20))), 0) AS DECIMAL(18,4)) AS [Ground Water (in kL)],
  CAST(COALESCE(SUM(CAST(t.thirdpartywater_litres AS DECIMAL(38,20))), 0) AS DECIMAL(18,4)) AS [Third Party Water (in kL)],
  CAST(COALESCE(SUM(CAST(t.total_emissions        AS DECIMAL(38,20))), 0) AS DECIMAL(18,4)) AS [Scope 2 Emission (in mtCO2e)]
FROM target_energy_consumption AS t
INNER JOIN #MonthsToProcess m ON t.ifm_month = m.month_num
INNER JOIN #RequestedMonths rm ON m.month_name = rm.month_name
INNER JOIN #YearRanges yr
  ON (m.month_num >= 4 AND t.ifm_year = yr.start_year)
  OR (m.month_num <= 3 AND t.ifm_year = yr.end_year)
GROUP BY
  yr.reporting_year,
  m.month_name;
    --HAVING SUM(CAST(t.electricity_consumption AS DECIMAL(38,20))) > 0;

    ;WITH Ordered AS (
        SELECT *,
               ROW_NUMBER() OVER (
                   ORDER BY
                       CASE WHEN reporting_year IS NULL THEN 0 ELSE 1 END,
                       reporting_year,
                       CASE
                           WHEN reporting_period = 'January'  THEN 1
                           WHEN reporting_period = 'February' THEN 2
                           WHEN reporting_period = 'March'    THEN 3
                           WHEN reporting_period = 'April'    THEN 4
                           WHEN reporting_period = 'May'      THEN 5
                           WHEN reporting_period = 'June'     THEN 6
                           WHEN reporting_period = 'July'     THEN 7
                           WHEN reporting_period = 'August'   THEN 8
                           WHEN reporting_period = 'September' THEN 9
                           WHEN reporting_period = 'October'  THEN 10
                           WHEN reporting_period = 'November' THEN 11
                           WHEN reporting_period = 'December' THEN 12
                       END
               ) AS rn
        FROM #Results
    )
    SELECT
        reporting_year,
        reporting_period,
        [Renewable Energy Consumption (in GJ)],
        [Non Renewable Energy Consumption (in GJ)],
        [Ground Water (in kL)],
        [Third Party Water (in kL)],
        [Scope 2 Emission (in mtCO2e)]
    FROM Ordered
    WHERE (@p_page = 1 AND @p_limit = 1)
       OR (@p_page IS NULL OR @p_limit IS NULL OR @p_page <= 0 OR @p_limit <= 0)
       OR rn BETWEEN ((@p_page - 1) * @p_limit) + 1
                  AND (@p_page * @p_limit)
    ORDER BY rn;

    DROP TABLE #Results;
    DROP TABLE #MonthsToProcess;
    DROP TABLE #RequestedMonths;
    DROP TABLE #YearRanges;
END;
GO


CREATE OR ALTER PROCEDURE [dbo].[FireExtinguisherEmissionReport]
    @p_organization_id        VARCHAR(255),
    @p_reporting_year_periods VARCHAR(MAX),
    @p_page                   INT = NULL,
    @p_limit                  INT = NULL
AS
BEGIN
    CREATE TABLE #Results (
        reporting_year                                      VARCHAR(255),
        reporting_period                                    VARCHAR(255),
        [Sol Id]                                            VARCHAR(255),
        [Location Name]                                     VARCHAR(255),
        [State Name]                                        VARCHAR(255),
        [City Name]                                         VARCHAR(255),
        [Vendor]                                            VARCHAR(255),
        [Clean Agent FE 2kg Quantity]                       DECIMAL(18,4),
        [Clean Agent FE 5kg Quantity]                       DECIMAL(18,4),
        [Clean Agent FE 10kg Quantity]                      DECIMAL(18,4),
        [co2 fe 4kg 500g Quantity]                          DECIMAL(18,4),
        [co2 fe 2kg Quantity]                               DECIMAL(18,4),
        [co2 fe 3kg Quantity]                               DECIMAL(18,4),
        [Clean Agent FE 2kg Emissions (in MTCo2e)]          DECIMAL(18,4),
        [Clean Agent FE 5kg Emissions (in MTCo2e)]          DECIMAL(18,4),
        [Clean Agent FE 10kg Emissions (in MTCo2e)]         DECIMAL(18,4),
        [CO2 FE 4kg 500g Emissions (in MTCo2e)]             DECIMAL(18,4),
        [CO2 FE 2kg Emissions (in MTCo2e)]                  DECIMAL(18,4),
        [CO2 FE 3kg Emissions (in MTCo2e)]                  DECIMAL(18,4),
        sort_row_id                                         VARCHAR(36) NULL
    );

    CREATE TABLE #MonthsToProcess (
        month_name VARCHAR(20),
        month_num  INT
    );

    INSERT INTO #MonthsToProcess (month_name, month_num) VALUES
        ('January', 1), ('February', 2), ('March', 3),
        ('April', 4), ('May', 5), ('June', 6),
        ('July', 7), ('August', 8), ('September', 9),
        ('October', 10), ('November', 11), ('December', 12);

    -- Multi-year support
    DECLARE @year_token_fe2 NVARCHAR(50) = LEFT(@p_reporting_year_periods, CHARINDEX(':', @p_reporting_year_periods) - 1);
    DECLARE @from_year_fe2 INT;
    DECLARE @to_year_fe2   INT;

    IF CHARINDEX('-', @year_token_fe2) > 0
    BEGIN
        SET @from_year_fe2 = CAST(LEFT(@year_token_fe2, CHARINDEX('-', @year_token_fe2) - 1) AS INT);
        SET @to_year_fe2   = CAST(SUBSTRING(@year_token_fe2, CHARINDEX('-', @year_token_fe2) + 1, LEN(@year_token_fe2)) AS INT);
    END
    ELSE
    BEGIN
        SET @from_year_fe2 = CAST(@year_token_fe2 AS INT);
        SET @to_year_fe2   = @from_year_fe2 + 1;
    END;

    CREATE TABLE #YearRangesFE2 (
        reporting_year VARCHAR(9),
        start_year     INT,
        end_year       INT
    );

    ;WITH Years AS (
        SELECT @from_year_fe2 AS y
        UNION ALL
        SELECT y + 1
        FROM Years
        WHERE y + 1 < @to_year_fe2
    )
    INSERT INTO #YearRangesFE2 (reporting_year, start_year, end_year)
    SELECT
        CAST(y AS VARCHAR(4)) + '-' + CAST(y + 1 AS VARCHAR(4)) AS reporting_year,
        y,
        y + 1
    FROM Years
    OPTION (MAXRECURSION 32767);

    DECLARE @months_part VARCHAR(MAX) =
        SUBSTRING(@p_reporting_year_periods, CHARINDEX(':', @p_reporting_year_periods) + 1, LEN(@p_reporting_year_periods));

    CREATE TABLE #RequestedMonths (month_name VARCHAR(20));

    WITH SplitMonths AS (
        SELECT value AS month_name
        FROM STRING_SPLIT(REPLACE(REPLACE(@months_part, '''', ''), ' ', ''), ',')
    )
    INSERT INTO #RequestedMonths
    SELECT month_name
    FROM SplitMonths;

    INSERT INTO #Results
    SELECT
        yr.reporting_year AS reporting_year,
        m.month_name AS reporting_period,
        t.sol_id AS [Sol Id],
        COALESCE(loc.location_name, 'NA') AS [Location Name],
        COALESCE(loc.state, 'NA')        AS [State Name],
        COALESCE(loc.city, 'NA')         AS [City Name],
        t.vendor AS [Vendor],
        CAST(t.cafe2kg AS DECIMAL(18,4)) AS [Clean Agent FE 2kg Quantity],
        CAST(t.cafe5kg AS DECIMAL(18,4)) AS [Clean Agent FE 5kg Quantity],
        CAST(t.cafe10kg AS DECIMAL(18,4)) AS [Clean Agent FE 10kg Quantity],
        CAST(t.co2fe4point5kg AS DECIMAL(18,4)) AS [co2 fe 4kg 500g Quantity],
        CAST(t.co2fe2kg AS DECIMAL(18,4))       AS [co2 fe 2kg Quantity],
        CAST(t.co2fe3kg AS DECIMAL(18,4))       AS [co2 fe 3kg Quantity],
        CAST(CAST(t.calculated_cafe2kg      AS DECIMAL(38,20)) / 1000 AS DECIMAL(18,4)) AS [Clean Agent FE 2kg Emissions (in MTCo2e)],
        CAST(CAST(t.calculated_cafe5kg      AS DECIMAL(38,20)) / 1000 AS DECIMAL(18,4)) AS [Clean Agent FE 5kg Emissions (in MTCo2e)],
        CAST(CAST(t.calculated_cafe10kg     AS DECIMAL(38,20)) / 1000 AS DECIMAL(18,4)) AS [Clean Agent FE 10kg Emissions (in MTCo2e)],
        CAST(CAST(t.calculated_co2fe4point5kg AS DECIMAL(38,20)) / 1000 AS DECIMAL(18,4)) AS [CO2 FE 4kg 500g Emissions (in MTCo2e)],
        CAST(CAST(t.calculated_co2fe2kg    AS DECIMAL(38,20)) / 1000 AS DECIMAL(18,4)) AS [CO2 FE 2kg Emissions (in MTCo2e)],
        CAST(CAST(t.calculated_co2fe3kg    AS DECIMAL(38,20)) / 1000 AS DECIMAL(18,4)) AS [CO2 FE 3kg Emissions (in MTCo2e)],
        CONVERT(VARCHAR(36), t.target_fe_emission_id) AS sort_row_id
    FROM target_fe_emission t  -- <--- ADD YOUR ACTUAL TABLE NAME HERE
    INNER JOIN #MonthsToProcess m ON t.month = m.month_name -- <--- Ensure 't.month' exists
    INNER JOIN #RequestedMonths rm ON m.month_name = rm.month_name
    INNER JOIN #YearRangesFE2 yr
        ON  (m.month_num >= 4 AND t.year = yr.start_year)
         OR (m.month_num <= 3 AND t.year = yr.end_year)
    OUTER APPLY (
        SELECT TOP 1 l.location_name, sm.state, cm.city
        FROM location_details ld
        LEFT JOIN location l ON l.location_id = ld.location_id
        LEFT JOIN state_master sm ON sm.state_id = ld.state_id
        LEFT JOIN city_master cm ON cm.city_id = ld.city_id
        WHERE ld.primary_sol_id = t.sol_id
        ORDER BY ld.location_detail_id
    ) loc;

    ;WITH Ordered AS (
        SELECT *,
               ROW_NUMBER() OVER (
                   ORDER BY
                       CASE WHEN reporting_year IS NULL THEN 0 ELSE 1 END,
                       reporting_year,
                       CASE
                           WHEN reporting_period = 'April' THEN 1
                           WHEN reporting_period = 'May' THEN 2
                           WHEN reporting_period = 'June' THEN 3
                           WHEN reporting_period = 'July' THEN 4
                           WHEN reporting_period = 'August' THEN 5
                           WHEN reporting_period = 'September' THEN 6
                           WHEN reporting_period = 'October' THEN 7
                           WHEN reporting_period = 'November' THEN 8
                           WHEN reporting_period = 'December' THEN 9
                           WHEN reporting_period = 'January' THEN 10
                           WHEN reporting_period = 'February' THEN 11
                           WHEN reporting_period = 'March' THEN 12
                       END,
                       [Sol Id],
                       [Location Name],
                       [State Name],
                       [City Name],
                       [Vendor],
                       sort_row_id
               ) AS rn
        FROM #Results
    )
    SELECT
        reporting_year,
        reporting_period,
        [Sol Id],
        [Location Name],
        [State Name],
        [City Name],
        [Vendor],
        [Clean Agent FE 2kg Quantity],
        [Clean Agent FE 5kg Quantity],
        [Clean Agent FE 10kg Quantity],
        [co2 fe 4kg 500g Quantity],
        [co2 fe 2kg Quantity],
        [co2 fe 3kg Quantity],
        [Clean Agent FE 2kg Emissions (in MTCo2e)],
        [Clean Agent FE 5kg Emissions (in MTCo2e)],
        [Clean Agent FE 10kg Emissions (in MTCo2e)],
        [CO2 FE 4kg 500g Emissions (in MTCo2e)],
        [CO2 FE 2kg Emissions (in MTCo2e)],
        [CO2 FE 3kg Emissions (in MTCo2e)]
    FROM Ordered
    WHERE (@p_page = 1 AND @p_limit = 1)
       OR (@p_page IS NULL OR @p_limit IS NULL OR @p_page <= 0 OR @p_limit <= 0)
       OR rn BETWEEN ((@p_page - 1) * @p_limit) + 1
                  AND (@p_page * @p_limit)
    ORDER BY rn;

    DROP TABLE #Results;
    DROP TABLE #MonthsToProcess;
    DROP TABLE #RequestedMonths;
    DROP TABLE #YearRangesFE2;
END;
GO


CREATE OR ALTER PROCEDURE [dbo].[FireExtinguisherEmissionReportV2]
    @p_organization_id        VARCHAR(255),
    @p_reporting_year_periods VARCHAR(MAX),
    @p_page                   INT = NULL,
    @p_limit                  INT = NULL
AS
BEGIN
    SET NOCOUNT ON;

    CREATE TABLE #MonthsToProcess (
        month_name VARCHAR(20),
        month_num  INT
    );

    INSERT INTO #MonthsToProcess (month_name, month_num) VALUES
        ('January', 1), ('February', 2), ('March', 3),
        ('April', 4), ('May', 5), ('June', 6),
        ('July', 7), ('August', 8), ('September', 9),
        ('October', 10), ('November', 11), ('December', 12);

    DECLARE @year_token NVARCHAR(50) = LEFT(@p_reporting_year_periods, CHARINDEX(':', @p_reporting_year_periods) - 1);
    DECLARE @from_year INT;
    DECLARE @to_year   INT;

    IF CHARINDEX('-', @year_token) > 0
    BEGIN
        SET @from_year = CAST(LEFT(@year_token, CHARINDEX('-', @year_token) - 1) AS INT);
        SET @to_year   = CAST(SUBSTRING(@year_token, CHARINDEX('-', @year_token) + 1, LEN(@year_token)) AS INT);
    END
    ELSE
    BEGIN
        SET @from_year = CAST(@year_token AS INT);
        SET @to_year   = @from_year + 1;
    END;

    CREATE TABLE #YearRanges (
        reporting_year VARCHAR(9),
        start_year     INT,
        end_year       INT
    );

    ;WITH Years AS (
        SELECT @from_year AS y
        UNION ALL
        SELECT y + 1
        FROM Years
        WHERE y + 1 < @to_year
    )
    INSERT INTO #YearRanges (reporting_year, start_year, end_year)
    SELECT
        CAST(y AS VARCHAR(4)) + '-' + CAST(y + 1 AS VARCHAR(4)),
        y,
        y + 1
    FROM Years
    OPTION (MAXRECURSION 32767);

    DECLARE @months_part VARCHAR(MAX) =
        SUBSTRING(@p_reporting_year_periods, CHARINDEX(':', @p_reporting_year_periods) + 1, LEN(@p_reporting_year_periods));

    CREATE TABLE #RequestedMonths (
        month_name VARCHAR(20)
    );

    ;WITH SplitMonths AS (
        SELECT LTRIM(RTRIM(value)) AS month_name
        FROM STRING_SPLIT(REPLACE(@months_part, '''', ''), ',')
    )
    INSERT INTO #RequestedMonths (month_name)
    SELECT month_name
    FROM SplitMonths
    WHERE month_name <> '';

    CREATE TABLE #Base (
        target_fe_emission_id VARCHAR(36)   NOT NULL,
        reporting_year         VARCHAR(9)    NULL,
        reporting_period       VARCHAR(20)   NULL,
        sol_id                 NVARCHAR(255) NULL,
        location_name          NVARCHAR(255) NULL,
        state_name             NVARCHAR(255) NULL,
        city_name              NVARCHAR(255) NULL,
        vendor                 NVARCHAR(255) NULL
    );

    INSERT INTO #Base (
        target_fe_emission_id,
        reporting_year,
        reporting_period,
        sol_id,
        location_name,
        state_name,
        city_name,
        vendor
    )
    SELECT
        t.target_fe_emission_id,
        yr.reporting_year,
        m.month_name,
        t.sol_id,
        COALESCE(loc.location_name, 'NA'),
        COALESCE(loc.state, 'NA'),
        COALESCE(loc.city, 'NA'),
        t.vendor
    FROM dbo.target_fe_emission t
    INNER JOIN #MonthsToProcess m
        ON t.month = m.month_name
    INNER JOIN #RequestedMonths rm
        ON m.month_name = rm.month_name
    INNER JOIN #YearRanges yr
        ON  (m.month_num >= 4 AND TRY_CAST(t.year AS INT) = yr.start_year)
         OR (m.month_num <= 3 AND TRY_CAST(t.year AS INT) = yr.end_year)
    OUTER APPLY (
        SELECT TOP 1 l.location_name, sm.state, cm.city
        FROM dbo.location_details ld
        LEFT JOIN dbo.location l ON l.location_id = ld.location_id
        LEFT JOIN dbo.state_master sm ON sm.state_id = ld.state_id
        LEFT JOIN dbo.city_master cm ON cm.city_id = ld.city_id
        WHERE ld.primary_sol_id = t.sol_id
        ORDER BY ld.location_detail_id
    ) loc
    WHERE ISNULL(t.deleted, 0) = 0;

    CREATE TABLE #ColumnHeaders (
        sort_order    INT           NOT NULL,
        column_header NVARCHAR(255) NOT NULL
    );

    INSERT INTO #ColumnHeaders (sort_order, column_header)
    SELECT
        ROW_NUMBER() OVER (ORDER BY MIN(c.column_order), c.column_header),
        c.column_header
    FROM dbo.target_fe_emission_column c
    INNER JOIN #Base b
        ON b.target_fe_emission_id = c.target_fe_emission_id
    WHERE ISNULL(c.deleted, 0) = 0
      AND c.column_header IS NOT NULL
      AND LTRIM(RTRIM(c.column_header)) <> N''
    GROUP BY c.column_header;

    DECLARE @q CHAR(1) = CHAR(39);
    DECLARE @parseQty NVARCHAR(500) =
        N'TRY_PARSE(REPLACE(LTRIM(RTRIM(c.quantity)), N' + @q + N',' + @q + N', N' + @q + N'.' + @q
        + N') AS DECIMAL(38,10) USING ' + @q + N'en-US' + @q + N')';
    DECLARE @parseEm NVARCHAR(500) =
        N'TRY_PARSE(REPLACE(LTRIM(RTRIM(c.calculated_emission)), N' + @q + N',' + @q + N', N' + @q + N'.' + @q
        + N') AS DECIMAL(38,20) USING ' + @q + N'en-US' + @q + N')';

    DECLARE @pivotQty NVARCHAR(MAX) = N'';
    DECLARE @pivotEm  NVARCHAR(MAX) = N'';
    DECLARE @selectQty NVARCHAR(MAX) = N'';
    DECLARE @selectEm  NVARCHAR(MAX) = N'';
    DECLARE @outerQty NVARCHAR(MAX) = N'';
    DECLARE @outerEm  NVARCHAR(MAX) = N'';
    DECLARE @typeQty NVARCHAR(MAX) = N'';
    DECLARE @typeEm  NVARCHAR(MAX) = N'';
    DECLARE @castQty NVARCHAR(MAX) = N'';
    DECLARE @castEm  NVARCHAR(MAX) = N'';

    DECLARE @sort INT = 1;
    DECLARE @maxSort INT = (SELECT ISNULL(MAX(sort_order), 0) FROM #ColumnHeaders);
    DECLARE @header NVARCHAR(255);
    DECLARE @display NVARCHAR(255);
    DECLARE @quotedHeader NVARCHAR(600);
    DECLARE @qtySuffix NVARCHAR(20) = N' Quantity';
    DECLARE @emSuffix NVARCHAR(40) = N' Emissions (in MTCo2e)';
    DECLARE @qtyName NVARCHAR(128);
    DECLARE @emName NVARCHAR(128);
    DECLARE @qtyAlias NVARCHAR(300);
    DECLARE @emAlias NVARCHAR(300);
    DECLARE @qtyKey NVARCHAR(20);
    DECLARE @emKey NVARCHAR(20);
    DECLARE @pos INT;
    DECLARE @i INT;
    DECLARE @j INT;
    DECLARE @k INT;
    DECLARE @intPart NVARCHAR(20);
    DECLARE @fracPart NVARCHAR(20);
    DECLARE @grams INT;
    DECLARE @replacement NVARCHAR(50);

    WHILE @sort <= @maxSort
    BEGIN
        SELECT @header = column_header
        FROM #ColumnHeaders
        WHERE sort_order = @sort;

        -- 4.5 KG -> 4kg 500g. The fraction of a kilogram is converted to grams.
        SET @display = @header;
        WHILE CHARINDEX(N'.', @display) > 0
        BEGIN
            SET @pos = CHARINDEX(N'.', @display);
            SET @i = @pos - 1;
            WHILE @i > 0 AND SUBSTRING(@display, @i, 1) LIKE N'[0-9]'
                SET @i -= 1;

            SET @j = @pos + 1;
            WHILE @j <= LEN(@display) AND SUBSTRING(@display, @j, 1) LIKE N'[0-9]'
                SET @j += 1;

            IF @i = @pos - 1 OR @j = @pos + 1
            BEGIN
                SET @display = STUFF(@display, @pos, 1, NCHAR(1));
                CONTINUE;
            END

            SET @intPart = SUBSTRING(@display, @i + 1, @pos - @i - 1);
            SET @fracPart = SUBSTRING(@display, @pos + 1, @j - @pos - 1);
            SET @grams = CAST(ROUND(
                (CAST(@fracPart AS DECIMAL(18,6)) / POWER(CAST(10 AS DECIMAL(18,6)), LEN(@fracPart))) * 1000,
                0) AS INT);

            SET @k = @j;
            WHILE @k <= LEN(@display) AND SUBSTRING(@display, @k, 1) = N' '
                SET @k += 1;
            IF UPPER(SUBSTRING(@display, @k, 2)) = N'KG'
                SET @k += 2;

            SET @replacement = @intPart + N'kg ' + CAST(@grams AS NVARCHAR(10)) + N'g';
            SET @display = STUFF(@display, @i + 1, @k - (@i + 1), @replacement);
        END
        SET @display = REPLACE(@display, NCHAR(1), N'.');

        SET @quotedHeader = N'N' + @q + REPLACE(@header, @q, @q + @q) + @q;
        SET @qtyName = LEFT(@display, 128 - LEN(@qtySuffix)) + @qtySuffix;
        SET @emName  = LEFT(@display, 128 - LEN(@emSuffix)) + @emSuffix;
        SET @qtyAlias = N'[' + REPLACE(@qtyName, N']', N']]') + N']';
        SET @emAlias  = N'[' + REPLACE(@emName, N']', N']]') + N']';
        SET @qtyKey = N'qty_' + RIGHT(N'000' + CAST(@sort AS NVARCHAR(10)), 3);
        SET @emKey  = N'em_' + RIGHT(N'000' + CAST(@sort AS NVARCHAR(10)), 3);

        SET @pivotQty = @pivotQty + N',
            CAST(ISNULL(SUM(CASE WHEN c.column_header = ' + @quotedHeader + N' THEN ' + @parseQty + N' END), 0) AS DECIMAL(18,4)) AS ' + @qtyKey;

        SET @pivotEm = @pivotEm + N',
            CAST(ISNULL(SUM(CASE WHEN c.column_header = ' + @quotedHeader + N' THEN ' + @parseEm + N' END), 0) / 1000.0 AS DECIMAL(18,4)) AS ' + @emKey;

        SET @selectQty = @selectQty + N',
            ISNULL(piv.' + @qtyKey + N', 0) AS ' + @qtyAlias;

        SET @selectEm = @selectEm + N',
            ISNULL(piv.' + @emKey + N', 0) AS ' + @emAlias;

        SET @outerQty = @outerQty + N', ' + @qtyAlias;
        SET @outerEm  = @outerEm  + N', ' + @emAlias;
        SET @typeQty = @typeQty + N', CAST(N''NUMBER'' AS SQL_VARIANT) AS ' + @qtyAlias;
        SET @typeEm  = @typeEm  + N', CAST(N''NUMBER'' AS SQL_VARIANT) AS ' + @emAlias;
        SET @castQty = @castQty + N', CAST(' + @qtyAlias + N' AS SQL_VARIANT)';
        SET @castEm  = @castEm  + N', CAST(' + @emAlias + N' AS SQL_VARIANT)';

        SET @sort += 1;
    END;

    DECLARE @pivotJoin NVARCHAR(MAX) = N'';
    IF @maxSort > 0
    BEGIN
        SET @pivotJoin = N'
        LEFT JOIN (
            SELECT
                c.target_fe_emission_id' + @pivotQty + @pivotEm + N'
            FROM dbo.target_fe_emission_column c
            WHERE ISNULL(c.deleted, 0) = 0
              AND c.target_fe_emission_id IN (SELECT target_fe_emission_id FROM #Base)
            GROUP BY c.target_fe_emission_id
        ) piv
            ON piv.target_fe_emission_id = b.target_fe_emission_id';
    END;

    DECLARE @sql NVARCHAR(MAX) = N'
    ;WITH Ordered AS (
        SELECT
            b.reporting_year,
            b.reporting_period,
            b.sol_id AS [Sol Id],
            b.location_name AS [Location Name],
            b.state_name AS [State Name],
            b.city_name AS [City Name],
            b.vendor AS [Vendor]' + @selectQty + @selectEm + N',
            ROW_NUMBER() OVER (
                ORDER BY
                    b.reporting_year,
                    CASE b.reporting_period
                        WHEN ''April'' THEN 1
                        WHEN ''May'' THEN 2
                        WHEN ''June'' THEN 3
                        WHEN ''July'' THEN 4
                        WHEN ''August'' THEN 5
                        WHEN ''September'' THEN 6
                        WHEN ''October'' THEN 7
                        WHEN ''November'' THEN 8
                        WHEN ''December'' THEN 9
                        WHEN ''January'' THEN 10
                        WHEN ''February'' THEN 11
                        WHEN ''March'' THEN 12
                        ELSE 99
                    END,
                    b.sol_id,
                    b.location_name,
                    b.state_name,
                    b.city_name,
                    b.vendor,
                    b.target_fe_emission_id
            ) AS rn
        FROM #Base b' + @pivotJoin + N'
    ),
    Paged AS (
        SELECT
            rn,
            reporting_year,
            reporting_period,
            [Sol Id],
            [Location Name],
            [State Name],
            [City Name],
            [Vendor]' + @outerQty + @outerEm + N'
        FROM Ordered
        WHERE (@p_page = 1 AND @p_limit = 1)
           OR (@p_page IS NULL OR @p_limit IS NULL OR @p_page <= 0 OR @p_limit <= 0)
           OR rn BETWEEN ((@p_page - 1) * @p_limit) + 1 AND (@p_page * @p_limit)
    )
    SELECT
        reporting_year,
        reporting_period,
        [Sol Id],
        [Location Name],
        [State Name],
        [City Name],
        [Vendor]' + @outerQty + @outerEm + N'
    FROM (
        SELECT
            0 AS sort_key,
            0 AS rn,
            CAST(NULL AS SQL_VARIANT) AS reporting_year,
            CAST(N''TEXT'' AS SQL_VARIANT) AS reporting_period,
            CAST(N''TEXT'' AS SQL_VARIANT) AS [Sol Id],
            CAST(N''TEXT'' AS SQL_VARIANT) AS [Location Name],
            CAST(N''TEXT'' AS SQL_VARIANT) AS [State Name],
            CAST(N''TEXT'' AS SQL_VARIANT) AS [City Name],
            CAST(N''TEXT'' AS SQL_VARIANT) AS [Vendor]' + @typeQty + @typeEm + N'
        UNION ALL
        SELECT
            1,
            rn,
            CAST(reporting_year AS SQL_VARIANT),
            CAST(reporting_period AS SQL_VARIANT),
            CAST([Sol Id] AS SQL_VARIANT),
            CAST([Location Name] AS SQL_VARIANT),
            CAST([State Name] AS SQL_VARIANT),
            CAST([City Name] AS SQL_VARIANT),
            CAST([Vendor] AS SQL_VARIANT)' + @castQty + @castEm + N'
        FROM Paged
    ) typed
    ORDER BY sort_key, rn;';

    EXEC sp_executesql
        @sql,
        N'@p_page INT, @p_limit INT',
        @p_page = @p_page,
        @p_limit = @p_limit;

    DROP TABLE #Base;
    DROP TABLE #ColumnHeaders;
    DROP TABLE #RequestedMonths;
    DROP TABLE #YearRanges;
    DROP TABLE #MonthsToProcess;
END;
GO


CREATE OR ALTER PROCEDURE [dbo].[OwnedCarEmissionReport]
    @p_organization_id        VARCHAR(255),
    @p_reporting_year_periods VARCHAR(MAX),
    @p_page                   INT = NULL,
    @p_limit                  INT = NULL
AS
BEGIN
    SET NOCOUNT ON;

    CREATE TABLE #Results (
        [Reporting Year]              VARCHAR(255),
        [Reporting Period]            VARCHAR(255),
        [Fuel Type]                   VARCHAR(255),
        [Type of Vehicle]             VARCHAR(255),
        [Total Amount]                DECIMAL(18,2),
        [Total Quantity]              DECIMAL(18,4),
        [Unit Price]                  DECIMAL(18,2),
        [Scope 1 Emissions (mtCO2e)]  DECIMAL(18,4),
        [Well to Tank Emission (mtCO2e)]       DECIMAL(18,4),
        [Non Renewable Fuel Energy (GJ)]   DECIMAL(18,4),
        sort_row_id                        VARCHAR(36) NULL
    );

    -- Multi-year support
    DECLARE @year_token_oc NVARCHAR(50) = LEFT(@p_reporting_year_periods, CHARINDEX(':', @p_reporting_year_periods) - 1);
    DECLARE @from_year_oc INT;
    DECLARE @to_year_oc   INT;

    IF CHARINDEX('-', @year_token_oc) > 0
    BEGIN
        SET @from_year_oc = CAST(LEFT(@year_token_oc, CHARINDEX('-', @year_token_oc) - 1) AS INT);
        SET @to_year_oc   = CAST(SUBSTRING(@year_token_oc, CHARINDEX('-', @year_token_oc) + 1, LEN(@year_token_oc)) AS INT);
    END
    ELSE
    BEGIN
        SET @from_year_oc = CAST(@year_token_oc AS INT);
        SET @to_year_oc   = @from_year_oc + 1;
    END;

    CREATE TABLE #YearRangesOC (
        reporting_year VARCHAR(9),
        start_year     INT,
        end_year       INT
    );

    ;WITH Years AS (
        SELECT @from_year_oc AS y
        UNION ALL
        SELECT y + 1
        FROM Years
        WHERE y + 1 < @to_year_oc
    )
    INSERT INTO #YearRangesOC (reporting_year, start_year, end_year)
    SELECT
        CAST(y AS VARCHAR(4)) + '-' + CAST(y + 1 AS VARCHAR(4)) AS reporting_year,
        y,
        y + 1
    FROM Years
    OPTION (MAXRECURSION 32767);

    CREATE TABLE #RequestedMonths (month_name VARCHAR(20) PRIMARY KEY);

    INSERT INTO #RequestedMonths
    SELECT value AS month_name
    FROM STRING_SPLIT(
        REPLACE(
            REPLACE(
                SUBSTRING(@p_reporting_year_periods, CHARINDEX(':', @p_reporting_year_periods) + 1, LEN(@p_reporting_year_periods)),
                '''', ''
            ),
            ' ', ''
        ),
        ','
    );

    INSERT INTO #Results
    SELECT
        yr.reporting_year AS [Reporting Year],
        t.[month]   AS [Reporting Period],
        t.fuel_type AS [Fuel Type],
        t.user_vehicle AS [Type of Vehicle],
        ISNULL(TRY_CAST(t.amount         AS DECIMAL(18,2)),  0),
        ISNULL(TRY_CAST(t.total_quantity AS DECIMAL(18,4)),  0),
        ISNULL(TRY_CAST(t.unit_price     AS DECIMAL(18,2)),  0),
        ISNULL(TRY_CAST(t.total_emission AS DECIMAL(18,4)) / 1000.0, 0),
        ISNULL(TRY_CAST(t.well_to_tank_emission AS DECIMAL(18,4)), 0),
        ISNULL(TRY_CAST(t.non_renewable_fuel_energy AS DECIMAL(18,4)), 0),
        CONVERT(VARCHAR(36), t.target_transportaion_id) AS sort_row_id
    FROM target_owned_car t
    INNER JOIN #RequestedMonths rm ON t.[month] = rm.month_name
    INNER JOIN #YearRangesOC yr
        ON (
               t.[month] IN ('April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December')
               AND t.[year] = CAST(yr.start_year AS VARCHAR(4))
           )
        OR (
               t.[month] IN ('January', 'February', 'March')
               AND t.[year] = CAST(yr.end_year AS VARCHAR(4))
           )
    WHERE t.deleted = 0;

    ;WITH Ordered AS (
        SELECT *,
               ROW_NUMBER() OVER (
                   ORDER BY
                       [Reporting Year],
                       CASE [Reporting Period]
                           WHEN 'April' THEN 1
                           WHEN 'May' THEN 2
                           WHEN 'June' THEN 3
                           WHEN 'July' THEN 4
                           WHEN 'August' THEN 5
                           WHEN 'September' THEN 6
                           WHEN 'October' THEN 7
                           WHEN 'November' THEN 8
                           WHEN 'December' THEN 9
                           WHEN 'January' THEN 10
                           WHEN 'February' THEN 11
                           WHEN 'March' THEN 12
                       END,
                       [Fuel Type],
                       [Type of Vehicle],
                       sort_row_id
               ) AS rn
        FROM #Results
    )
    SELECT
        [Reporting Year],
        [Reporting Period],
        [Fuel Type],
        [Type of Vehicle],
        [Total Amount],
        [Total Quantity],
        [Unit Price],
        [Scope 1 Emissions (mtCO2e)],
        [Well to Tank Emission (mtCO2e)],
        [Non Renewable Fuel Energy (GJ)]
    FROM Ordered
    WHERE (@p_page = 1 AND @p_limit = 1)
       OR (@p_page IS NULL OR @p_limit IS NULL OR @p_page <= 0 OR @p_limit <= 0)
       OR rn BETWEEN ((@p_page - 1) * @p_limit) + 1
                  AND (@p_page * @p_limit)
    ORDER BY rn;

    DROP TABLE #Results;
    DROP TABLE #RequestedMonths;
    DROP TABLE #YearRangesOC;
END;
GO


CREATE OR ALTER PROCEDURE [dbo].[PurchaseRegistryEmissionReport]
    @p_organization_id        VARCHAR(255),
    @p_reporting_year_periods VARCHAR(MAX),
    @p_page                    INT = NULL,
    @p_limit                   INT = NULL
AS
BEGIN
    SET NOCOUNT ON;

    -- Create temp table to hold raw results
    CREATE TABLE #Results (
        reporting_year                VARCHAR(255),
        reporting_period              VARCHAR(255),
        [glaccount code]              VARCHAR(255),
        [supplier gstin]              VARCHAR(255),
        [pan]                         VARCHAR(50),
        [supplier name]               VARCHAR(255),
        [hsn sac]                     VARCHAR(255),
        [item description]            VARCHAR(500),
        [unit of measurement]         VARCHAR(255),
        [purchase voucher number]     VARCHAR(255),
        [quantity]                    DECIMAL(18,4),
        [taxable value]               DECIMAL(18,4),
        [total amount]                DECIMAL(18,4),
        [Currency conversion factor]  DECIMAL(18,8),
        [Total Amount (In EF Currency)] DECIMAL(18,8),
        [emission factor]             DECIMAL(18,8),
        [Scope 3 Emissions (in MtCO2e)] DECIMAL(18,8),
        sort_row_id                     VARCHAR(36) NULL
    );

    CREATE TABLE #MonthsToProcess (month_name VARCHAR(20), month_num INT);
    INSERT INTO #MonthsToProcess (month_name, month_num) VALUES
        ('January', 1), ('February', 2), ('March', 3), ('April', 4), ('May', 5), ('June', 6),
        ('July', 7), ('August', 8), ('September', 9), ('October', 10), ('November', 11), ('December', 12);

    -- Multi-year logic
    DECLARE @year_token_pr NVARCHAR(50) = LEFT(@p_reporting_year_periods, CHARINDEX(':', @p_reporting_year_periods) - 1);
    DECLARE @from_year_pr INT;
    DECLARE @to_year_pr   INT;

    IF CHARINDEX('-', @year_token_pr) > 0
    BEGIN
        SET @from_year_pr = CAST(LEFT(@year_token_pr, CHARINDEX('-', @year_token_pr) - 1) AS INT);
        SET @to_year_pr   = CAST(SUBSTRING(@year_token_pr, CHARINDEX('-', @year_token_pr) + 1, LEN(@year_token_pr)) AS INT);
    END
    ELSE
    BEGIN
        SET @from_year_pr = CAST(@year_token_pr AS INT);
        SET @to_year_pr   = @from_year_pr + 1;
    END;

    CREATE TABLE #YearRangesPR (reporting_year VARCHAR(9), start_year INT, end_year INT);
    ;WITH Years AS (
        SELECT @from_year_pr AS y
        UNION ALL
        SELECT y + 1 FROM Years WHERE y + 1 < @to_year_pr
    )
    INSERT INTO #YearRangesPR (reporting_year, start_year, end_year)
    SELECT CAST(y AS VARCHAR(4)) + '-' + CAST(y + 1 AS VARCHAR(4)), y, y + 1 FROM Years;

    -- Parse months
    DECLARE @months_part VARCHAR(MAX) = SUBSTRING(@p_reporting_year_periods, CHARINDEX(':', @p_reporting_year_periods) + 1, LEN(@p_reporting_year_periods));
    CREATE TABLE #RequestedMonths (month_name VARCHAR(20));
    ;WITH SplitMonths AS (
        SELECT value AS month_name FROM STRING_SPLIT(REPLACE(REPLACE(@months_part, '''', ''), ' ', ''), ',')
    )
    INSERT INTO #RequestedMonths (month_name) SELECT month_name FROM SplitMonths;

    -- Insert data into results table (No NULL row insertion here)
    INSERT INTO #Results
    SELECT
        yr.reporting_year,
        m.month_name,
        t.glaccount_code,
        t.supplier_gstin,
        t.pan,
        t.supplier_name,
        t.hsn_sac,
        t.item_description,
        t.unit_of_measurement,
        t.purchase_voucher_number,
        CAST(TRY_CAST(t.quantity AS DECIMAL(28,10)) AS DECIMAL(18,4)),
        CAST(TRY_CAST(t.taxable_value AS DECIMAL(28,10)) AS DECIMAL(18,4)),
        CAST(TRY_CAST(t.total_amount AS DECIMAL(28,10)) AS DECIMAL(18,4)),
        CAST(TRY_CAST(t.conversion_factor AS DECIMAL(28,10)) AS DECIMAL(18,8)),
        -- Handling potential divide by zero
        CASE WHEN CAST(TRY_CAST(t.conversion_factor AS DECIMAL(28,10)) AS DECIMAL(18,8)) = 0 THEN 0
             ELSE CAST(TRY_CAST(t.total_amount AS DECIMAL(28,10)) AS DECIMAL(18,4)) 
                  / CAST(TRY_CAST(t.conversion_factor AS DECIMAL(28,10)) AS DECIMAL(18,8)) END,
        CAST(TRY_CAST(t.emission_factor AS DECIMAL(28,10)) AS DECIMAL(18,8)),
        CAST(TRY_CAST(t.total_emission AS DECIMAL(28,10)) AS DECIMAL(18,4)),
        CONVERT(VARCHAR(36), t.target_purchase_registry_calculated_data_id) AS sort_row_id
    FROM target_purchase_registry_calculated_data t
    INNER JOIN #MonthsToProcess m ON t.[month] = m.month_num
    INNER JOIN #RequestedMonths rm ON m.month_name = rm.month_name
    INNER JOIN #YearRangesPR yr ON (m.month_num >= 4 AND t.[year] = yr.start_year) OR (m.month_num <= 3 AND t.[year] = yr.end_year);

    -- Final ordered selection with pagination (hiding the rn column)
    ;WITH OrderedResults AS (
        SELECT *,
               ROW_NUMBER() OVER (
                   ORDER BY 
                       reporting_year,
                       CASE reporting_period
                           WHEN 'April' THEN 1 WHEN 'May' THEN 2 WHEN 'June' THEN 3
                           WHEN 'July' THEN 4 WHEN 'August' THEN 5 WHEN 'September' THEN 6
                           WHEN 'October' THEN 7 WHEN 'November' THEN 8 WHEN 'December' THEN 9
                           WHEN 'January' THEN 10 WHEN 'February' THEN 11 WHEN 'March' THEN 12
                       END,
                       [supplier name], [purchase voucher number],
                       sort_row_id
               ) AS rn
        FROM #Results
    )
    SELECT 
        reporting_year, reporting_period, [glaccount code], [supplier gstin], [pan], [supplier name], 
        [hsn sac], [item description], [unit of measurement], [purchase voucher number], 
        [quantity], [taxable value], [total amount], [Currency conversion factor], 
        [Total Amount (In EF Currency)], [emission factor], [Scope 3 Emissions (in MtCO2e)]
    FROM OrderedResults
    WHERE (@p_page = 1 AND @p_limit = 1)
       OR (@p_page IS NULL OR @p_limit IS NULL OR @p_page <= 0 OR @p_limit <= 0)
       OR rn BETWEEN ((@p_page - 1) * @p_limit) + 1 AND (@p_page * @p_limit)
    ORDER BY rn;

    DROP TABLE #Results;
    DROP TABLE #MonthsToProcess;
    DROP TABLE #RequestedMonths;
    DROP TABLE #YearRangesPR;
END;
GO


CREATE OR ALTER PROCEDURE [dbo].[PurchaseRegistryEmissionReport_Grouped]
    @p_organization_id        VARCHAR(255),
    @p_reporting_year_periods VARCHAR(MAX),
    @p_page                    INT = NULL,
    @p_limit                   INT = NULL
AS
BEGIN
    SET NOCOUNT ON;

    -- 1. Setup Month Helper Table
    IF OBJECT_ID('tempdb..#MonthsToProcess') IS NOT NULL DROP TABLE #MonthsToProcess;
    CREATE TABLE #MonthsToProcess (month_name VARCHAR(20), month_num INT);
    INSERT INTO #MonthsToProcess (month_name, month_num) VALUES
        ('January', 1), ('February', 2), ('March', 3), ('April', 4), ('May', 5), ('June', 6),
        ('July', 7), ('August', 8), ('September', 9), ('October', 10), ('November', 11), ('December', 12);

    -- 2. Multi-year Support Logic
    DECLARE @year_token_pr NVARCHAR(50) = LEFT(@p_reporting_year_periods, CHARINDEX(':', @p_reporting_year_periods) - 1);
    DECLARE @from_year_pr INT;
    DECLARE @to_year_pr   INT;

    IF CHARINDEX('-', @year_token_pr) > 0
    BEGIN
        SET @from_year_pr = CAST(LEFT(@year_token_pr, CHARINDEX('-', @year_token_pr) - 1) AS INT);
        SET @to_year_pr   = CAST(SUBSTRING(@year_token_pr, CHARINDEX('-', @year_token_pr) + 1, LEN(@year_token_pr)) AS INT);
    END
    ELSE
    BEGIN
        SET @from_year_pr = CAST(@year_token_pr AS INT);
        SET @to_year_pr   = @from_year_pr + 1;
    END;

    IF OBJECT_ID('tempdb..#YearRangesPR') IS NOT NULL DROP TABLE #YearRangesPR;
    CREATE TABLE #YearRangesPR (reporting_year VARCHAR(9), start_year INT, end_year INT);
    
    ;WITH Years AS (
        SELECT @from_year_pr AS y
        UNION ALL
        SELECT y + 1 FROM Years WHERE y + 1 < @to_year_pr
    )
    INSERT INTO #YearRangesPR (reporting_year, start_year, end_year)
    SELECT CAST(y AS VARCHAR(4)) + '-' + CAST(y + 1 AS VARCHAR(4)), y, y + 1 FROM Years;

    -- 3. Parse Requested Months
    DECLARE @months_part VARCHAR(MAX) = SUBSTRING(@p_reporting_year_periods, CHARINDEX(':', @p_reporting_year_periods) + 1, LEN(@p_reporting_year_periods));
    
    IF OBJECT_ID('tempdb..#RequestedMonths') IS NOT NULL DROP TABLE #RequestedMonths;
    CREATE TABLE #RequestedMonths (month_name VARCHAR(20));
    INSERT INTO #RequestedMonths (month_name)
    SELECT LTRIM(RTRIM(REPLACE(value, '''', ''))) FROM STRING_SPLIT(@months_part, ',');

    -- 4. Main Grouped Query using FOR XML for older SQL versions
    SELECT 
        yr.reporting_year,
        m.month_name AS reporting_period,
        t.hsn_sac,
        t.purchase_voucher_number,
        -- Comma separated strings using STUFF and FOR XML
        STUFF((SELECT DISTINCT ', ' + t2.glaccount_code 
               FROM target_purchase_registry_calculated_data t2 
               WHERE t2.purchase_voucher_number = t.purchase_voucher_number AND t2.hsn_sac = t.hsn_sac
               FOR XML PATH('')), 1, 2, '') AS [glaccount_codes],
        STUFF((SELECT DISTINCT ', ' + t2.supplier_gstin 
               FROM target_purchase_registry_calculated_data t2 
               WHERE t2.purchase_voucher_number = t.purchase_voucher_number AND t2.hsn_sac = t.hsn_sac
               FOR XML PATH('')), 1, 2, '') AS [supplier_gstins],
        STUFF((SELECT DISTINCT ', ' + t2.pan 
               FROM target_purchase_registry_calculated_data t2 
               WHERE t2.purchase_voucher_number = t.purchase_voucher_number AND t2.hsn_sac = t.hsn_sac
               FOR XML PATH('')), 1, 2, '') AS [pans],
        STUFF((SELECT DISTINCT ', ' + t2.supplier_name 
               FROM target_purchase_registry_calculated_data t2 
               WHERE t2.purchase_voucher_number = t.purchase_voucher_number AND t2.hsn_sac = t.hsn_sac
               FOR XML PATH('')), 1, 2, '') AS [supplier_names],
        -- Aggregations
        SUM(CAST(TRY_CAST(t.quantity AS DECIMAL(28,10)) AS DECIMAL(18,4))) AS [total_quantity],
        SUM(CAST(TRY_CAST(t.taxable_value AS DECIMAL(28,10)) AS DECIMAL(18,4))) AS [total_taxable_value],
        SUM(CAST(TRY_CAST(t.total_amount AS DECIMAL(28,10)) AS DECIMAL(18,4))) AS [total_amount],
        AVG(CAST(TRY_CAST(t.conversion_factor AS DECIMAL(28,10)) AS DECIMAL(18,8))) AS [avg_conversion_factor],
        AVG(CAST(TRY_CAST(t.emission_factor AS DECIMAL(28,10)) AS DECIMAL(18,8))) AS [avg_emission_factor],
        SUM(CAST(TRY_CAST(t.total_emission AS DECIMAL(28,10)) AS DECIMAL(18,4))) AS [total_emissions_mtco2e]
    FROM target_purchase_registry_calculated_data t
    INNER JOIN #MonthsToProcess m ON t.[month] = m.month_num
    INNER JOIN #RequestedMonths rm ON m.month_name = rm.month_name
    INNER JOIN #YearRangesPR yr ON (m.month_num >= 4 AND t.[year] = yr.start_year) OR (m.month_num <= 3 AND t.[year] = yr.end_year)
    GROUP BY 
        yr.reporting_year, 
        m.month_name, 
        m.month_num,
        t.hsn_sac, 
        t.purchase_voucher_number
    ORDER BY 
        yr.reporting_year,
        CASE m.month_name 
            WHEN 'April' THEN 1 WHEN 'May' THEN 2 WHEN 'June' THEN 3 WHEN 'July' THEN 4 
            WHEN 'August' THEN 5 WHEN 'September' THEN 6 WHEN 'October' THEN 7 
            WHEN 'November' THEN 8 WHEN 'December' THEN 9 WHEN 'January' THEN 10 
            WHEN 'February' THEN 11 WHEN 'March' THEN 12 
        END;

    -- Cleanup
    DROP TABLE #MonthsToProcess;
    DROP TABLE #RequestedMonths;
    DROP TABLE #YearRangesPR;
END;
GO


CREATE OR ALTER PROCEDURE [dbo].[RefrigerantEmissionReport]
    @p_organization_id        VARCHAR(255),
    @p_reporting_year_periods VARCHAR(MAX),
    @p_page                   INT = NULL,
    @p_limit                  INT = NULL
AS
BEGIN
    CREATE TABLE #Results (
        reporting_year              VARCHAR(255),
        reporting_period            VARCHAR(255),
        [Sol Id]                    VARCHAR(255),
        [Location Name]             VARCHAR(255),
        [State Name]                VARCHAR(255),
        [City Name]                 VARCHAR(255),
        [Vendor]                    VARCHAR(255),
        [I Maintain Ticket No]      VARCHAR(255),
        [r22 Quantity]              DECIMAL(18,4),
        [r32 Quantity]              DECIMAL(18,4),
        [r407 Quantity]             DECIMAL(18,4),
        [r410 Quantity]             DECIMAL(18,4),
        [r134a Quantity]            DECIMAL(18,4),
        [R22 Emissions (in MTCo2e)] DECIMAL(18,4),
        [R32 Emissions (in MTCo2e)] DECIMAL(18,4),
        [R407 Emissions (in MTCo2e)] DECIMAL(18,4),
        [R410 Emissions (in MTCo2e)] DECIMAL(18,4),
        [R134A Emissions (in MTCo2e)] DECIMAL(18,4),
        sort_row_id                   VARCHAR(36) NULL
    );

    CREATE TABLE #MonthsToProcess (
        month_name VARCHAR(20),
        month_num  INT
    );

    INSERT INTO #MonthsToProcess (month_name, month_num) VALUES
        ('January', 1), ('February', 2), ('March', 3),
        ('April', 4), ('May', 5), ('June', 6),
        ('July', 7), ('August', 8), ('September', 9),
        ('October', 10), ('November', 11), ('December', 12);

    -- Multi-year support
    DECLARE @year_token_ref NVARCHAR(50) = LEFT(@p_reporting_year_periods, CHARINDEX(':', @p_reporting_year_periods) - 1);
    DECLARE @from_year_ref INT;
    DECLARE @to_year_ref   INT;

    IF CHARINDEX('-', @year_token_ref) > 0
    BEGIN
        SET @from_year_ref = CAST(LEFT(@year_token_ref, CHARINDEX('-', @year_token_ref) - 1) AS INT);
        SET @to_year_ref   = CAST(SUBSTRING(@year_token_ref, CHARINDEX('-', @year_token_ref) + 1, LEN(@year_token_ref)) AS INT);
    END
    ELSE
    BEGIN
        SET @from_year_ref = CAST(@year_token_ref AS INT);
        SET @to_year_ref   = @from_year_ref + 1;
    END;

    CREATE TABLE #YearRangesRef (
        reporting_year VARCHAR(9),
        start_year     INT,
        end_year       INT
    );

    ;WITH Years AS (
        SELECT @from_year_ref AS y
        UNION ALL
        SELECT y + 1
        FROM Years
        WHERE y + 1 < @to_year_ref
    )
    INSERT INTO #YearRangesRef (reporting_year, start_year, end_year)
    SELECT
        CAST(y AS VARCHAR(4)) + '-' + CAST(y + 1 AS VARCHAR(4)) AS reporting_year,
        y,
        y + 1
    FROM Years
    OPTION (MAXRECURSION 32767);

    DECLARE @months_part  VARCHAR(MAX) =
        SUBSTRING(@p_reporting_year_periods, CHARINDEX(':', @p_reporting_year_periods) + 1, LEN(@p_reporting_year_periods));

    CREATE TABLE #RequestedMonths (month_name VARCHAR(20));

    ;WITH SplitMonths AS (
        SELECT value AS month_name
        FROM STRING_SPLIT(REPLACE(REPLACE(@months_part, '''', ''), ' ', ''), ',')
    )
    INSERT INTO #RequestedMonths
    SELECT month_name
    FROM SplitMonths;

    INSERT INTO #Results
    SELECT
        yr.reporting_year AS reporting_year,
        m.month_name AS reporting_period,
        t.sol_id     AS [Sol Id],
        COALESCE(loc.location_name, 'NA') AS [Location Name],
        COALESCE(loc.state, 'NA')        AS [State Name],
        COALESCE(loc.city, 'NA')         AS [City Name],
        t.vendor_name                   AS [Vendor],
        t.maintain_ticket_no            AS [I Maintain Ticket No],
        CAST(t.r22   AS DECIMAL(18,4))  AS [r22 Quantity],
        CAST(t.r32   AS DECIMAL(18,4))  AS [r32 Quantity],
        CAST(t.r407  AS DECIMAL(18,4))  AS [r407 Quantity],
        CAST(t.r410  AS DECIMAL(18,4))  AS [r410 Quantity],
        CAST(t.r134a AS DECIMAL(18,4))  AS [r134a Quantity],
        CAST(CAST(t.calculated_r22   AS DECIMAL(38,20)) / 1000 AS DECIMAL(18,4)) AS [R22 Emissions (in MTCo2e)],
        CAST(CAST(t.calculated_r32   AS DECIMAL(38,20)) / 1000 AS DECIMAL(18,4)) AS [R32 Emissions (in MTCo2e)],
        CAST(CAST(t.calculated_r407  AS DECIMAL(38,20)) / 1000 AS DECIMAL(18,4)) AS [R407 Emissions (in MTCo2e)],
        CAST(CAST(t.calculated_r410  AS DECIMAL(38,20)) / 1000 AS DECIMAL(18,4)) AS [R410 Emissions (in MTCo2e)],
        CAST(CAST(t.calculated_r134a AS DECIMAL(38,20)) / 1000 AS DECIMAL(18,4)) AS [R134A Emissions (in MTCo2e)],
        CONVERT(VARCHAR(36), t.target_refrigerant_emission_id) AS sort_row_id
    FROM target_refrigerant_emission t  -- <--- ADD YOUR ACTUAL TABLE NAME HERE
    INNER JOIN #MonthsToProcess m ON t.month = m.month_name -- <--- Ensure 't.month' exists
    INNER JOIN #RequestedMonths rm ON m.month_name = rm.month_name
    INNER JOIN #YearRangesRef yr
        ON  (m.month_num >= 4 AND t.year = yr.start_year)
         OR (m.month_num <= 3 AND t.year = yr.end_year)
    OUTER APPLY (
        SELECT TOP 1 l.location_name, sm.state, cm.city
        FROM location_details ld
        LEFT JOIN location l ON l.location_id = ld.location_id
        LEFT JOIN state_master sm ON sm.state_id = ld.state_id
        LEFT JOIN city_master cm ON cm.city_id = ld.city_id
        WHERE ld.primary_sol_id = t.sol_id
        ORDER BY ld.location_detail_id
    ) loc;

    ;WITH Ordered AS (
        SELECT *,
               ROW_NUMBER() OVER (
                   ORDER BY
                       CASE WHEN reporting_year IS NULL THEN 0 ELSE 1 END,
                       reporting_year,
                       CASE reporting_period
                           WHEN 'April' THEN 1
                           WHEN 'May' THEN 2
                           WHEN 'June' THEN 3
                           WHEN 'July' THEN 4
                           WHEN 'August' THEN 5
                           WHEN 'September' THEN 6
                           WHEN 'October' THEN 7
                           WHEN 'November' THEN 8
                           WHEN 'December' THEN 9
                           WHEN 'January' THEN 10
                           WHEN 'February' THEN 11
                           WHEN 'March' THEN 12
                       END,
                       [Sol Id],
                       [Location Name],
                       [State Name],
                       [City Name],
                       [Vendor],
                       sort_row_id
               ) AS rn
        FROM #Results
    )
    SELECT
        reporting_year,
        reporting_period,
        [Sol Id],
        [Location Name],
        [State Name],
        [City Name],
        [Vendor],
        [I Maintain Ticket No],
        [r22 Quantity],
        [r32 Quantity],
        [r407 Quantity],
        [r410 Quantity],
        [r134a Quantity],
        [R22 Emissions (in MTCo2e)],
        [R32 Emissions (in MTCo2e)],
        [R407 Emissions (in MTCo2e)],
        [R410 Emissions (in MTCo2e)],
        [R134A Emissions (in MTCo2e)]
    FROM Ordered
    WHERE (@p_page = 1 AND @p_limit = 1)
       OR (@p_page IS NULL OR @p_limit IS NULL OR @p_page <= 0 OR @p_limit <= 0)
       OR rn BETWEEN ((@p_page - 1) * @p_limit) + 1
                  AND (@p_page * @p_limit)
    ORDER BY rn;

    DROP TABLE #Results;
    DROP TABLE #MonthsToProcess;
    DROP TABLE #RequestedMonths;
    DROP TABLE #YearRangesRef;
END;
GO


CREATE OR ALTER PROCEDURE [dbo].[RefrigerantEmissionReportV2]
    @p_organization_id        VARCHAR(255),
    @p_reporting_year_periods VARCHAR(MAX),
    @p_page                   INT = NULL,
    @p_limit                  INT = NULL
AS
BEGIN
    SET NOCOUNT ON;

    CREATE TABLE #MonthsToProcess (
        month_name VARCHAR(20),
        month_num  INT
    );

    INSERT INTO #MonthsToProcess (month_name, month_num) VALUES
        ('January', 1), ('February', 2), ('March', 3),
        ('April', 4), ('May', 5), ('June', 6),
        ('July', 7), ('August', 8), ('September', 9),
        ('October', 10), ('November', 11), ('December', 12);

    DECLARE @year_token NVARCHAR(50) = LEFT(@p_reporting_year_periods, CHARINDEX(':', @p_reporting_year_periods) - 1);
    DECLARE @from_year INT;
    DECLARE @to_year   INT;

    IF CHARINDEX('-', @year_token) > 0
    BEGIN
        SET @from_year = CAST(LEFT(@year_token, CHARINDEX('-', @year_token) - 1) AS INT);
        SET @to_year   = CAST(SUBSTRING(@year_token, CHARINDEX('-', @year_token) + 1, LEN(@year_token)) AS INT);
    END
    ELSE
    BEGIN
        SET @from_year = CAST(@year_token AS INT);
        SET @to_year   = @from_year + 1;
    END;

    CREATE TABLE #YearRanges (
        reporting_year VARCHAR(9),
        start_year     INT,
        end_year       INT
    );

    ;WITH Years AS (
        SELECT @from_year AS y
        UNION ALL
        SELECT y + 1
        FROM Years
        WHERE y + 1 < @to_year
    )
    INSERT INTO #YearRanges (reporting_year, start_year, end_year)
    SELECT
        CAST(y AS VARCHAR(4)) + '-' + CAST(y + 1 AS VARCHAR(4)),
        y,
        y + 1
    FROM Years
    OPTION (MAXRECURSION 32767);

    DECLARE @months_part VARCHAR(MAX) =
        SUBSTRING(@p_reporting_year_periods, CHARINDEX(':', @p_reporting_year_periods) + 1, LEN(@p_reporting_year_periods));

    CREATE TABLE #RequestedMonths (
        month_name VARCHAR(20)
    );

    ;WITH SplitMonths AS (
        SELECT LTRIM(RTRIM(value)) AS month_name
        FROM STRING_SPLIT(REPLACE(@months_part, '''', ''), ',')
    )
    INSERT INTO #RequestedMonths (month_name)
    SELECT month_name
    FROM SplitMonths
    WHERE month_name <> '';

    CREATE TABLE #Base (
        target_refrigerant_emission_id VARCHAR(36)   NOT NULL,
        reporting_year                  VARCHAR(9)    NULL,
        reporting_period                VARCHAR(20)   NULL,
        sol_id                          NVARCHAR(255) NULL,
        location_name                   NVARCHAR(255) NULL,
        state_name                      NVARCHAR(255) NULL,
        city_name                       NVARCHAR(255) NULL,
        vendor_name                     NVARCHAR(255) NULL,
        maintain_ticket_no              NVARCHAR(255) NULL
    );

    INSERT INTO #Base (
        target_refrigerant_emission_id,
        reporting_year,
        reporting_period,
        sol_id,
        location_name,
        state_name,
        city_name,
        vendor_name,
        maintain_ticket_no
    )
    SELECT
        t.target_refrigerant_emission_id,
        yr.reporting_year,
        m.month_name,
        t.sol_id,
        COALESCE(loc.location_name, 'NA'),
        COALESCE(loc.state, 'NA'),
        COALESCE(loc.city, 'NA'),
        t.vendor_name,
        t.maintain_ticket_no
    FROM dbo.target_refrigerant_emission t
    INNER JOIN #MonthsToProcess m
        ON t.month = m.month_name
    INNER JOIN #RequestedMonths rm
        ON m.month_name = rm.month_name
    INNER JOIN #YearRanges yr
        ON  (m.month_num >= 4 AND TRY_CAST(t.year AS INT) = yr.start_year)
         OR (m.month_num <= 3 AND TRY_CAST(t.year AS INT) = yr.end_year)
    OUTER APPLY (
        SELECT TOP 1 l.location_name, sm.state, cm.city
        FROM dbo.location_details ld
        LEFT JOIN dbo.location l ON l.location_id = ld.location_id
        LEFT JOIN dbo.state_master sm ON sm.state_id = ld.state_id
        LEFT JOIN dbo.city_master cm ON cm.city_id = ld.city_id
        WHERE ld.primary_sol_id = t.sol_id
        ORDER BY ld.location_detail_id
    ) loc
    WHERE ISNULL(t.deleted, 0) = 0;

    CREATE TABLE #ColumnHeaders (
        sort_order    INT           NOT NULL,
        column_header NVARCHAR(255) NOT NULL
    );

    INSERT INTO #ColumnHeaders (sort_order, column_header)
    SELECT
        ROW_NUMBER() OVER (ORDER BY MIN(c.column_order), c.column_header),
        c.column_header
    FROM dbo.target_refrigerant_emission_column c
    INNER JOIN #Base b
        ON b.target_refrigerant_emission_id = c.target_refrigerant_emission_id
    WHERE ISNULL(c.deleted, 0) = 0
      AND c.column_header IS NOT NULL
      AND LTRIM(RTRIM(c.column_header)) <> N''
    GROUP BY c.column_header;

    DECLARE @q CHAR(1) = CHAR(39);
    DECLARE @parseQty NVARCHAR(500) =
        N'TRY_PARSE(REPLACE(LTRIM(RTRIM(c.quantity)), N' + @q + N',' + @q + N', N' + @q + N'.' + @q
        + N') AS DECIMAL(38,10) USING ' + @q + N'en-US' + @q + N')';
    DECLARE @parseEm NVARCHAR(500) =
        N'TRY_PARSE(REPLACE(LTRIM(RTRIM(c.calculated_emission)), N' + @q + N',' + @q + N', N' + @q + N'.' + @q
        + N') AS DECIMAL(38,20) USING ' + @q + N'en-US' + @q + N')';

    DECLARE @pivotQty NVARCHAR(MAX) = N'';
    DECLARE @pivotEm  NVARCHAR(MAX) = N'';
    DECLARE @selectQty NVARCHAR(MAX) = N'';
    DECLARE @selectEm  NVARCHAR(MAX) = N'';
    DECLARE @outerQty NVARCHAR(MAX) = N'';
    DECLARE @outerEm  NVARCHAR(MAX) = N'';
    DECLARE @typeQty NVARCHAR(MAX) = N'';
    DECLARE @typeEm  NVARCHAR(MAX) = N'';
    DECLARE @castQty NVARCHAR(MAX) = N'';
    DECLARE @castEm  NVARCHAR(MAX) = N'';

    DECLARE @sort INT = 1;
    DECLARE @maxSort INT = (SELECT ISNULL(MAX(sort_order), 0) FROM #ColumnHeaders);
    DECLARE @header NVARCHAR(255);
    DECLARE @display NVARCHAR(255);
    DECLARE @quotedHeader NVARCHAR(600);
    DECLARE @qtySuffix NVARCHAR(20) = N' Quantity';
    DECLARE @emSuffix NVARCHAR(40) = N' Emissions (in MTCo2e)';
    DECLARE @qtyName NVARCHAR(128);
    DECLARE @emName NVARCHAR(128);
    DECLARE @qtyAlias NVARCHAR(300);
    DECLARE @emAlias NVARCHAR(300);
    DECLARE @qtyKey NVARCHAR(20);
    DECLARE @emKey NVARCHAR(20);
    DECLARE @pos INT;
    DECLARE @i INT;
    DECLARE @j INT;
    DECLARE @k INT;
    DECLARE @intPart NVARCHAR(20);
    DECLARE @fracPart NVARCHAR(20);
    DECLARE @grams INT;
    DECLARE @replacement NVARCHAR(50);

    WHILE @sort <= @maxSort
    BEGIN
        SELECT @header = column_header
        FROM #ColumnHeaders
        WHERE sort_order = @sort;

        -- 4.5 KG -> 4kg 500g. The fraction of a kilogram is converted to grams.
        SET @display = @header;
        WHILE CHARINDEX(N'.', @display) > 0
        BEGIN
            SET @pos = CHARINDEX(N'.', @display);
            SET @i = @pos - 1;
            WHILE @i > 0 AND SUBSTRING(@display, @i, 1) LIKE N'[0-9]'
                SET @i -= 1;

            SET @j = @pos + 1;
            WHILE @j <= LEN(@display) AND SUBSTRING(@display, @j, 1) LIKE N'[0-9]'
                SET @j += 1;

            IF @i = @pos - 1 OR @j = @pos + 1
            BEGIN
                SET @display = STUFF(@display, @pos, 1, NCHAR(1));
                CONTINUE;
            END

            SET @intPart = SUBSTRING(@display, @i + 1, @pos - @i - 1);
            SET @fracPart = SUBSTRING(@display, @pos + 1, @j - @pos - 1);
            SET @grams = CAST(ROUND(
                (CAST(@fracPart AS DECIMAL(18,6)) / POWER(CAST(10 AS DECIMAL(18,6)), LEN(@fracPart))) * 1000,
                0) AS INT);

            SET @k = @j;
            WHILE @k <= LEN(@display) AND SUBSTRING(@display, @k, 1) = N' '
                SET @k += 1;
            IF UPPER(SUBSTRING(@display, @k, 2)) = N'KG'
                SET @k += 2;

            SET @replacement = @intPart + N'kg ' + CAST(@grams AS NVARCHAR(10)) + N'g';
            SET @display = STUFF(@display, @i + 1, @k - (@i + 1), @replacement);
        END
        SET @display = REPLACE(@display, NCHAR(1), N'.');

        SET @quotedHeader = N'N' + @q + REPLACE(@header, @q, @q + @q) + @q;
        SET @qtyName = LEFT(@display, 128 - LEN(@qtySuffix)) + @qtySuffix;
        SET @emName  = LEFT(@display, 128 - LEN(@emSuffix)) + @emSuffix;
        SET @qtyAlias = N'[' + REPLACE(@qtyName, N']', N']]') + N']';
        SET @emAlias  = N'[' + REPLACE(@emName, N']', N']]') + N']';
        SET @qtyKey = N'qty_' + RIGHT(N'000' + CAST(@sort AS NVARCHAR(10)), 3);
        SET @emKey  = N'em_' + RIGHT(N'000' + CAST(@sort AS NVARCHAR(10)), 3);

        SET @pivotQty = @pivotQty + N',
            CAST(ISNULL(SUM(CASE WHEN c.column_header = ' + @quotedHeader + N' THEN ' + @parseQty + N' END), 0) AS DECIMAL(18,4)) AS ' + @qtyKey;

        SET @pivotEm = @pivotEm + N',
            CAST(ISNULL(SUM(CASE WHEN c.column_header = ' + @quotedHeader + N' THEN ' + @parseEm + N' END), 0) / 1000.0 AS DECIMAL(18,4)) AS ' + @emKey;

        SET @selectQty = @selectQty + N',
            ISNULL(piv.' + @qtyKey + N', 0) AS ' + @qtyAlias;

        SET @selectEm = @selectEm + N',
            ISNULL(piv.' + @emKey + N', 0) AS ' + @emAlias;

        SET @outerQty = @outerQty + N', ' + @qtyAlias;
        SET @outerEm  = @outerEm  + N', ' + @emAlias;
        SET @typeQty = @typeQty + N', CAST(N''NUMBER'' AS SQL_VARIANT) AS ' + @qtyAlias;
        SET @typeEm  = @typeEm  + N', CAST(N''NUMBER'' AS SQL_VARIANT) AS ' + @emAlias;
        SET @castQty = @castQty + N', CAST(' + @qtyAlias + N' AS SQL_VARIANT)';
        SET @castEm  = @castEm  + N', CAST(' + @emAlias + N' AS SQL_VARIANT)';

        SET @sort += 1;
    END;

    DECLARE @pivotJoin NVARCHAR(MAX) = N'';
    IF @maxSort > 0
    BEGIN
        SET @pivotJoin = N'
        LEFT JOIN (
            SELECT
                c.target_refrigerant_emission_id' + @pivotQty + @pivotEm + N'
            FROM dbo.target_refrigerant_emission_column c
            WHERE ISNULL(c.deleted, 0) = 0
              AND c.target_refrigerant_emission_id IN (SELECT target_refrigerant_emission_id FROM #Base)
            GROUP BY c.target_refrigerant_emission_id
        ) piv
            ON piv.target_refrigerant_emission_id = b.target_refrigerant_emission_id';
    END;

    DECLARE @sql NVARCHAR(MAX) = N'
    ;WITH Ordered AS (
        SELECT
            b.reporting_year,
            b.reporting_period,
            b.sol_id AS [Sol Id],
            b.location_name AS [Location Name],
            b.state_name AS [State Name],
            b.city_name AS [City Name],
            b.vendor_name AS [Vendor],
            b.maintain_ticket_no AS [I Maintain Ticket No]' + @selectQty + @selectEm + N',
            ROW_NUMBER() OVER (
                ORDER BY
                    b.reporting_year,
                    CASE b.reporting_period
                        WHEN ''April'' THEN 1
                        WHEN ''May'' THEN 2
                        WHEN ''June'' THEN 3
                        WHEN ''July'' THEN 4
                        WHEN ''August'' THEN 5
                        WHEN ''September'' THEN 6
                        WHEN ''October'' THEN 7
                        WHEN ''November'' THEN 8
                        WHEN ''December'' THEN 9
                        WHEN ''January'' THEN 10
                        WHEN ''February'' THEN 11
                        WHEN ''March'' THEN 12
                        ELSE 99
                    END,
                    b.sol_id,
                    b.location_name,
                    b.state_name,
                    b.city_name,
                    b.vendor_name,
                    b.maintain_ticket_no,
                    b.target_refrigerant_emission_id
            ) AS rn
        FROM #Base b' + @pivotJoin + N'
    ),
    Paged AS (
        SELECT
            rn,
            reporting_year,
            reporting_period,
            [Sol Id],
            [Location Name],
            [State Name],
            [City Name],
            [Vendor],
            [I Maintain Ticket No]' + @outerQty + @outerEm + N'
        FROM Ordered
        WHERE (@p_page = 1 AND @p_limit = 1)
           OR (@p_page IS NULL OR @p_limit IS NULL OR @p_page <= 0 OR @p_limit <= 0)
           OR rn BETWEEN ((@p_page - 1) * @p_limit) + 1 AND (@p_page * @p_limit)
    )
    SELECT
        reporting_year,
        reporting_period,
        [Sol Id],
        [Location Name],
        [State Name],
        [City Name],
        [Vendor],
        [I Maintain Ticket No]' + @outerQty + @outerEm + N'
    FROM (
        SELECT
            0 AS sort_key,
            0 AS rn,
            CAST(NULL AS SQL_VARIANT) AS reporting_year,
            CAST(N''TEXT'' AS SQL_VARIANT) AS reporting_period,
            CAST(N''TEXT'' AS SQL_VARIANT) AS [Sol Id],
            CAST(N''TEXT'' AS SQL_VARIANT) AS [Location Name],
            CAST(N''TEXT'' AS SQL_VARIANT) AS [State Name],
            CAST(N''TEXT'' AS SQL_VARIANT) AS [City Name],
            CAST(N''TEXT'' AS SQL_VARIANT) AS [Vendor],
            CAST(N''TEXT'' AS SQL_VARIANT) AS [I Maintain Ticket No]' + @typeQty + @typeEm + N'
        UNION ALL
        SELECT
            1,
            rn,
            CAST(reporting_year AS SQL_VARIANT),
            CAST(reporting_period AS SQL_VARIANT),
            CAST([Sol Id] AS SQL_VARIANT),
            CAST([Location Name] AS SQL_VARIANT),
            CAST([State Name] AS SQL_VARIANT),
            CAST([City Name] AS SQL_VARIANT),
            CAST([Vendor] AS SQL_VARIANT),
            CAST([I Maintain Ticket No] AS SQL_VARIANT)' + @castQty + @castEm + N'
        FROM Paged
    ) typed
    ORDER BY sort_key, rn;';

    EXEC sp_executesql
        @sql,
        N'@p_page INT, @p_limit INT',
        @p_page = @p_page,
        @p_limit = @p_limit;

    DROP TABLE #Base;
    DROP TABLE #ColumnHeaders;
    DROP TABLE #RequestedMonths;
    DROP TABLE #YearRanges;
    DROP TABLE #MonthsToProcess;
END;
GO


CREATE OR ALTER PROCEDURE [dbo].[TrainBusEmissionReport]
    @p_organization_id        VARCHAR(255),
    @p_reporting_year_periods VARCHAR(MAX),
    @p_page                   INT = NULL,
    @p_limit                  INT = NULL
AS
BEGIN
    SET NOCOUNT ON;

    CREATE TABLE #Results (
        reporting_year              VARCHAR(255),
        reporting_period            VARCHAR(255),
        [Mode of Travel]            VARCHAR(50),
        [From Location]             VARCHAR(255),
        [To Location]               VARCHAR(255),
        [Agent Name]                VARCHAR(255),
        [Total Trips]               INT,
        [Total Distance (in mile)]  DECIMAL(18,4),
        [Total Distance (in km)]    DECIMAL(18,4),
        [Total Net Amount]          DECIMAL(18,2),
        [Total Emissions (mt CO2e)] DECIMAL(18,4),
        sort_row_id                 VARCHAR(36) NULL
    );

    CREATE TABLE #MonthsToProcess (
        month_name VARCHAR(20),
        month_num  INT,
        PRIMARY KEY (month_name)
    );

    INSERT INTO #MonthsToProcess (month_name, month_num) VALUES
        ('January', 1), ('February', 2), ('March', 3),
        ('April', 4), ('May', 5), ('June', 6),
        ('July', 7), ('August', 8), ('September', 9),
        ('October', 10), ('November', 11), ('December', 12);

    -- Multi-year support
    DECLARE @year_token_tb NVARCHAR(50) = LEFT(@p_reporting_year_periods, CHARINDEX(':', @p_reporting_year_periods) - 1);
    DECLARE @from_year_tb INT;
    DECLARE @to_year_tb   INT;

    IF CHARINDEX('-', @year_token_tb) > 0
    BEGIN
        SET @from_year_tb = CAST(LEFT(@year_token_tb, CHARINDEX('-', @year_token_tb) - 1) AS INT);
        SET @to_year_tb   = CAST(SUBSTRING(@year_token_tb, CHARINDEX('-', @year_token_tb) + 1, LEN(@year_token_tb)) AS INT);
    END
    ELSE
    BEGIN
        SET @from_year_tb = CAST(@year_token_tb AS INT);
        SET @to_year_tb   = @from_year_tb + 1;
    END;

    CREATE TABLE #YearRangesTB (
        reporting_year VARCHAR(9),
        start_year     INT,
        end_year       INT
    );

    ;WITH Years AS (
        SELECT @from_year_tb AS y
        UNION ALL
        SELECT y + 1
        FROM Years
        WHERE y + 1 < @to_year_tb
    )
    INSERT INTO #YearRangesTB (reporting_year, start_year, end_year)
    SELECT
        CAST(y AS VARCHAR(4)) + '-' + CAST(y + 1 AS VARCHAR(4)) AS reporting_year,
        y,
        y + 1
    FROM Years
    OPTION (MAXRECURSION 32767);

    CREATE TABLE #RequestedMonths ( month_name VARCHAR(20) PRIMARY KEY );

    INSERT INTO #RequestedMonths
    SELECT value AS month_name
    FROM STRING_SPLIT(
        REPLACE(
            REPLACE(
                SUBSTRING(@p_reporting_year_periods, CHARINDEX(':', @p_reporting_year_periods) + 1, LEN(@p_reporting_year_periods)),
                '''', ''
            ),
            ' ', ''
        ),
        ','
    );

    INSERT INTO #Results
    SELECT
        yr.reporting_year AS reporting_year,
        DATENAME(MONTH, t.travel_date) AS reporting_period,
        t.mode_of_travel                AS [Mode of Travel],
        t.etrv_from_place               AS [From Location],
        t.etrv_to_place                 AS [To Location],
        t.name_of_agent_who_booked      AS [Agent Name],
        1                               AS [Total Trips],
        CAST(CAST(t.trip_distance AS DECIMAL(38,20)) AS DECIMAL(18,4))            AS [Total Distance (in mile)],
        CAST(CAST(t.trip_distance AS DECIMAL(38,20)) * 1.60934 AS DECIMAL(18,4))  AS [Total Distance (in km)],
        CAST(CAST(t.net_total     AS DECIMAL(38,20)) AS DECIMAL(18,2))            AS [Total Net Amount],
        CAST(CAST(t.total_emission AS DECIMAL(38,20)) / 1000.0 AS DECIMAL(18,4))  AS [Total Emissions (mt CO2e)],
        CONVERT(VARCHAR(36), t.target_train_bus_id) AS sort_row_id
    FROM target_train_bus t
    INNER JOIN #MonthsToProcess m
        ON DATENAME(MONTH, t.travel_date) = m.month_name
    INNER JOIN #RequestedMonths rm
        ON m.month_name = rm.month_name
    CROSS APPLY (
        SELECT CASE
                   WHEN MONTH(t.travel_date) >= 4 THEN
                       CAST(YEAR(t.travel_date) AS VARCHAR(4)) + '-' + CAST(YEAR(t.travel_date) + 1 AS VARCHAR(4))
                   ELSE
                       CAST(YEAR(t.travel_date) - 1 AS VARCHAR(4)) + '-' + CAST(YEAR(t.travel_date) AS VARCHAR(4))
               END AS reporting_year
    ) ry
    INNER JOIN #YearRangesTB yr
        ON ry.reporting_year = yr.reporting_year
    WHERE t.deleted = 0;

    ;WITH Ordered AS (
        SELECT *,
               ROW_NUMBER() OVER (
                   ORDER BY
                       CASE WHEN reporting_year IS NULL THEN 0 ELSE 1 END,
                       reporting_year,
                       CASE reporting_period
                           WHEN 'April' THEN 1
                           WHEN 'May' THEN 2
                           WHEN 'June' THEN 3
                           WHEN 'July' THEN 4
                           WHEN 'August' THEN 5
                           WHEN 'September' THEN 6
                           WHEN 'October' THEN 7
                           WHEN 'November' THEN 8
                           WHEN 'December' THEN 9
                           WHEN 'January' THEN 10
                           WHEN 'February' THEN 11
                           WHEN 'March' THEN 12
                       END,
                       [Mode of Travel],
                       [From Location],
                       [To Location],
                       [Agent Name],
                       sort_row_id
               ) AS rn
        FROM #Results
    )
    SELECT
        reporting_year,
        reporting_period,
        [Mode of Travel],
        [From Location],
        [To Location],
        [Agent Name],
        [Total Trips],
        [Total Distance (in mile)],
        [Total Distance (in km)],
        [Total Net Amount],
        [Total Emissions (mt CO2e)]
    FROM Ordered
    WHERE (@p_page = 1 AND @p_limit = 1)
       OR (@p_page IS NULL OR @p_limit IS NULL OR @p_page <= 0 OR @p_limit <= 0)
       OR rn BETWEEN ((@p_page - 1) * @p_limit) + 1
                  AND (@p_page * @p_limit)
    ORDER BY rn;

    DROP TABLE #Results;
    DROP TABLE #MonthsToProcess;
    DROP TABLE #RequestedMonths;
    DROP TABLE #YearRangesTB;
END;
GO


CREATE OR ALTER PROCEDURE [dbo].[TransportationEmissionReport]
    @p_organization_id        VARCHAR(255),
    @p_reporting_year_periods VARCHAR(MAX),
    @p_page                   INT = NULL,
    @p_limit                  INT = NULL
AS
BEGIN
    SET NOCOUNT ON;

    CREATE TABLE #Results (
        reporting_year              VARCHAR(255),
        reporting_period            VARCHAR(255),
        [Cost Center]               VARCHAR(255),
        [Tagging]                   VARCHAR(255),
        [Total Amount]              DECIMAL(18,2),
        [Total Emissions (mt CO2e)] DECIMAL(18,4),
        sort_row_id                 VARCHAR(36) NULL
    );

    CREATE TABLE #MonthsToProcess (
        month_name VARCHAR(20),
        month_num  INT
    );

    INSERT INTO #MonthsToProcess (month_name, month_num) VALUES
        ('January', 1), ('February', 2), ('March', 3),
        ('April', 4), ('May', 5), ('June', 6),
        ('July', 7), ('August', 8), ('September', 9),
        ('October', 10), ('November', 11), ('December', 12);

    -- Multi-year support
    DECLARE @year_token NVARCHAR(50) = LEFT(@p_reporting_year_periods, CHARINDEX(':', @p_reporting_year_periods) - 1);
    DECLARE @from_year INT;
    DECLARE @to_year   INT;

    IF CHARINDEX('-', @year_token) > 0
    BEGIN
        SET @from_year = CAST(LEFT(@year_token, CHARINDEX('-', @year_token) - 1) AS INT);
        SET @to_year   = CAST(SUBSTRING(@year_token, CHARINDEX('-', @year_token) + 1, LEN(@year_token)) AS INT);
    END
    ELSE
    BEGIN
        SET @from_year = CAST(@year_token AS INT);
        SET @to_year   = @from_year + 1;
    END;

    CREATE TABLE #YearRanges (
        reporting_year VARCHAR(9),
        start_year     INT,
        end_year       INT
    );

    ;WITH Years AS (
        SELECT @from_year AS y
        UNION ALL
        SELECT y + 1
        FROM Years
        WHERE y + 1 < @to_year
    )
    INSERT INTO #YearRanges (reporting_year, start_year, end_year)
    SELECT
        CAST(y AS VARCHAR(4)) + '-' + CAST(y + 1 AS VARCHAR(4)) AS reporting_year,
        y,
        y + 1
    FROM Years
    OPTION (MAXRECURSION 32767);

    DECLARE @months_part VARCHAR(MAX) =
        SUBSTRING(@p_reporting_year_periods, CHARINDEX(':', @p_reporting_year_periods) + 1, LEN(@p_reporting_year_periods));

    CREATE TABLE #RequestedMonths (month_name VARCHAR(20));

    ;WITH SplitMonths AS (
        SELECT value AS month_name
        FROM STRING_SPLIT(REPLACE(REPLACE(@months_part, '''', ''), ' ', ''), ',')
    )
    INSERT INTO #RequestedMonths
    SELECT month_name
    FROM SplitMonths;

    INSERT INTO #Results
    SELECT
        ic.reporting_year                                      AS reporting_year,
        DATENAME(MONTH, ic.execute_date)                       AS reporting_period,
        t.cost_center                                          AS [Cost Center],
        t.tagging                                              AS [Tagging],
        CAST(CAST(t.amount         AS DECIMAL(38,20)) AS DECIMAL(18,2))  AS [Total Amount],
        CAST(CAST(t.total_emission AS DECIMAL(38,20)) / 1000.0 AS DECIMAL(18,4)) AS [Total Emissions (mt CO2e)],
        CONVERT(VARCHAR(36), t.target_transportaion_id) AS sort_row_id
    FROM target_transportaion t
    INNER JOIN ingestion_calendar ic
        ON ic.ingestion_calendar_id = t.ingestion_calendar_id
    INNER JOIN #MonthsToProcess m
        ON DATENAME(MONTH, ic.execute_date) = m.month_name
    INNER JOIN #RequestedMonths rm
        ON m.month_name = rm.month_name
    INNER JOIN #YearRanges yr
        ON ic.reporting_year = yr.reporting_year
    WHERE t.deleted = 0;

    ;WITH Ordered AS (
        SELECT *,
               ROW_NUMBER() OVER (
                   ORDER BY
                       CASE WHEN reporting_year IS NULL THEN 0 ELSE 1 END,
                       reporting_year,
                       CASE reporting_period
                           WHEN 'April' THEN 1
                           WHEN 'May' THEN 2
                           WHEN 'June' THEN 3
                           WHEN 'July' THEN 4
                           WHEN 'August' THEN 5
                           WHEN 'September' THEN 6
                           WHEN 'October' THEN 7
                           WHEN 'November' THEN 8
                           WHEN 'December' THEN 9
                           WHEN 'January' THEN 10
                           WHEN 'February' THEN 11
                           WHEN 'March' THEN 12
                       END,
                       [Cost Center],
                       [Tagging],
                       sort_row_id
               ) AS rn
        FROM #Results
    )
    SELECT 
    reporting_year,
        reporting_period,
        [Cost Center],
        [Tagging],
        [Total Amount],
        [Total Emissions (mt CO2e)]
    FROM Ordered
    WHERE (@p_page = 1 AND @p_limit = 1)
       OR (@p_page IS NULL OR @p_limit IS NULL OR @p_page <= 0 OR @p_limit <= 0)
       OR rn BETWEEN ((@p_page - 1) * @p_limit) + 1
                  AND (@p_page * @p_limit)
    ORDER BY rn;

    DROP TABLE #Results;
    DROP TABLE #MonthsToProcess;
    DROP TABLE #RequestedMonths;
    DROP TABLE #YearRanges;
END;
GO


CREATE OR ALTER PROCEDURE [dbo].[wasteManagementMarginalReport] @p_organization_id VARCHAR(255), @p_reporting_year_periods NVARCHAR(MAX), @p_page INT = NULL, @p_limit INT = NULL AS BEGIN DECLARE @dynamic_where NVARCHAR(MAX) DECLARE @sql NVARCHAR(MAX) CREATE TABLE #SplitRaw ( year_token VARCHAR(50), periods VARCHAR(MAX) ) INSERT INTO #SplitRaw (year_token, periods) SELECT LEFT(value, CHARINDEX(':', value) - 1), SUBSTRING(value, CHARINDEX(':', value) + 1, LEN(value)) FROM STRING_SPLIT(@p_reporting_year_periods, ';') WHERE value <> '' AND CHARINDEX(':', value) > 0 CREATE TABLE #SplitData ( year VARCHAR(10), periods VARCHAR(MAX) ) ;WITH Params AS ( SELECT r.year_token, r.periods, CASE WHEN CHARINDEX('-', r.year_token) > 0 THEN CAST(LEFT(r.year_token, CHARINDEX('-', r.year_token) - 1) AS INT) ELSE CAST(r.year_token AS INT) END AS from_y, CASE WHEN CHARINDEX('-', r.year_token) > 0 THEN CAST(SUBSTRING(r.year_token, CHARINDEX('-', r.year_token) + 1, LEN(r.year_token)) AS INT) ELSE CAST(r.year_token AS INT) + 1 END AS to_y FROM #SplitRaw r ), Years AS ( SELECT p.year_token, p.periods, p.from_y AS y, p.to_y FROM Params p UNION ALL SELECT y.year_token, y.periods, y.y + 1, y.to_y FROM Years y WHERE y.y + 1 < y.to_y ) INSERT INTO #SplitData (year, periods) SELECT CAST(y.y AS VARCHAR(4)) + '-' + CAST(y.y + 1 AS VARCHAR(4)), y.periods FROM Years y OPTION (MAXRECURSION 32767) DROP TABLE #SplitRaw SET @dynamic_where = STUFF(( SELECT ' OR ' + '(pde.reporting_year IN (''' + year + ''', ''' + CAST((CAST(SUBSTRING(year, 1, 4) AS INT) - 1) AS VARCHAR) + '-' + CAST((CAST(SUBSTRING(year, 6, 4) AS INT) - 1) AS VARCHAR) + ''') AND dc.reporting_period IN (' + periods + '))' FROM #SplitData FOR XML PATH(''), TYPE ).value('.', 'NVARCHAR(MAX)'), 1, 4, '') SET @sql = N' WITH MetricsData AS ( SELECT pde.reporting_year, dc.reporting_period, vo.value as waste_type, MAX(CASE WHEN dpf2.name = ''Re-Used'' THEN COALESCE(dpev2.number_value, 0) END) as reused, MAX(CASE WHEN dpf2.name = ''Recycled'' THEN COALESCE(dpev2.number_value, 0) END) as recycled, MAX(CASE WHEN dpf2.name = ''Safely Disposed'' THEN COALESCE(dpev2.number_value, 0) END) as safely_disposed FROM data_collections dc JOIN primary_data_entries pde ON dc.collection_id = pde.collection_id JOIN template_entries te ON pde.template_entry_id = te.template_entry_id JOIN template_entry_fields tef ON te.template_entry_id = tef.template_entry_id JOIN data_point_fields dpf ON tef.field_id = dpf.field_id JOIN primary_data_points pdp ON dc.primary_data_point_id = pdp.primary_data_point_id JOIN data_point_entry_values dpev ON pde.entry_id = dpev.entry_id AND dpev.field_id = dpf.field_id JOIN value_options vo ON dpev.value_option_id = vo.value_option_id LEFT JOIN data_point_fields dpf2 ON dpf2.name IN (''Re-Used'', ''Recycled'', ''Safely Disposed'') LEFT JOIN data_point_entry_values dpev2 ON pde.entry_id = dpev2.entry_id AND dpev2.field_id = dpf2.field_id WHERE pdp.referance_key = ''P2QL4DPRL4'' AND dc.organization_id = @p_organization_id AND dpf.name = ''Waste Type'' AND (' + @dynamic_where + ') GROUP BY pde.reporting_year, dc.reporting_period, vo.value ), DiffData AS ( SELECT curr.reporting_year, curr.reporting_period, curr.waste_type, CAST(curr.reused - COALESCE(prev.reused, 0) AS VARCHAR) as [Re-Used], CAST(curr.recycled - COALESCE(prev.recycled, 0) AS VARCHAR) as [Recycled], CAST(curr.safely_disposed - COALESCE(prev.safely_disposed, 0) AS VARCHAR) as [Safely Disposed] FROM MetricsData curr LEFT JOIN MetricsData prev ON curr.waste_type = prev.waste_type AND CAST(SUBSTRING(curr.reporting_year, 1, 4) AS INT) = CAST(SUBSTRING(prev.reporting_year, 1, 4) AS INT) + 1 AND curr.reporting_period = prev.reporting_period WHERE curr.reporting_year IN (SELECT year FROM #SplitData) ) SELECT * FROM ( SELECT NULL as reporting_year, NULL as reporting_period, ''STRING'' as [Waste Type], ''NUMBER'' as [Re-Used], ''NUMBER'' as [Recycled], ''NUMBER'' as [Safely Disposed] UNION ALL SELECT reporting_year, reporting_period, waste_type, [Re-Used], [Recycled], [Safely Disposed] FROM DiffData ) result_set ORDER BY CASE WHEN reporting_year IS NULL THEN 0 ELSE 1 END, reporting_year, reporting_period, [Waste Type]' IF @p_page >= 1 AND @p_limit >= 2 SET @sql = @sql + N' OFFSET ' + CAST((@p_page - 1) * @p_limit AS NVARCHAR(20)) + N' ROWS FETCH NEXT ' + CAST(@p_limit AS NVARCHAR(20)) + N' ROWS ONLY' EXEC sp_executesql @sql, N'@p_organization_id VARCHAR(255)', @p_organization_id DROP TABLE #SplitData END
GO


CREATE OR ALTER PROCEDURE [dbo].[WasteManagementReport]
    @p_organization_id        CHAR(36),
    @p_reporting_year_periods VARCHAR(MAX),
    @p_page                   INT = NULL,
    @p_limit                  INT = NULL
AS
BEGIN
    CREATE TABLE #Results (
        reporting_year              VARCHAR(255),
        reporting_period            VARCHAR(255),
        request_identifier          VARCHAR(255),
        plastic_waste               DECIMAL(18,3),
        e_waste                     DECIMAL(18,3),
        bio_medical_waste           DECIMAL(18,3),
        construction_demolition_waste DECIMAL(18,3),
        battery_waste               DECIMAL(18,3),
        radio_active_waste          DECIMAL(18,3),
        other_hazardous_waste       DECIMAL(18,3),
        other_non_hazardous_waste   DECIMAL(18,3),
        iron                        DECIMAL(18,3),
        copper                      DECIMAL(18,3),
        aluminium                   DECIMAL(18,3),
        plastic_packing             DECIMAL(18,3),
        corrugated_box              DECIMAL(18,3),
        total_waste_generated       DECIMAL(18,3),
        recycled_waste              DECIMAL(18,3),
        reused_waste                DECIMAL(18,3),
        other_recovery_operation    DECIMAL(18,3),
        total_waste_recovered       DECIMAL(18,3),
        incineration                DECIMAL(18,3),
        landfilling                 DECIMAL(18,3),
        other_disposal_operation    DECIMAL(18,3),
        total_waste_disposed        DECIMAL(18,3),
        sort_row_id                 VARCHAR(36) NULL
    );

    CREATE TABLE #MonthsToProcess (
        month_name VARCHAR(20),
        month_num  INT
    );

    INSERT INTO #MonthsToProcess (month_name, month_num) VALUES
        ('January', 1), ('February', 2), ('March', 3),
        ('April', 4), ('May', 5), ('June', 6),
        ('July', 7), ('August', 8), ('September', 9),
        ('October', 10), ('November', 11), ('December', 12);

    -- Multi-year support
    DECLARE @year_token NVARCHAR(50) = LEFT(@p_reporting_year_periods, CHARINDEX(':', @p_reporting_year_periods) - 1);
    DECLARE @from_year INT;
    DECLARE @to_year   INT;

    IF CHARINDEX('-', @year_token) > 0
    BEGIN
        SET @from_year = CAST(LEFT(@year_token, CHARINDEX('-', @year_token) - 1) AS INT);
        SET @to_year   = CAST(SUBSTRING(@year_token, CHARINDEX('-', @year_token) + 1, LEN(@year_token)) AS INT);
    END
    ELSE
    BEGIN
        SET @from_year = CAST(@year_token AS INT);
        SET @to_year   = @from_year + 1;
    END;

    CREATE TABLE #YearRanges (
        reporting_year VARCHAR(9),
        start_year     INT,
        end_year       INT
    );

    ;WITH Years AS (
        SELECT @from_year AS y
        UNION ALL
        SELECT y + 1
        FROM Years
        WHERE y + 1 < @to_year
    )
    INSERT INTO #YearRanges (reporting_year, start_year, end_year)
    SELECT
        CAST(y AS VARCHAR(4)) + '-' + CAST(y + 1 AS VARCHAR(4)) AS reporting_year,
        y,
        y + 1
    FROM Years
    OPTION (MAXRECURSION 32767);

    DECLARE @months_part VARCHAR(MAX) =
        SUBSTRING(@p_reporting_year_periods, CHARINDEX(':', @p_reporting_year_periods) + 1, LEN(@p_reporting_year_periods));

    CREATE TABLE #RequestedMonths (month_name VARCHAR(20));

    ;WITH SplitMonths AS (
        SELECT value AS month_name
        FROM STRING_SPLIT(REPLACE(REPLACE(@months_part, '''', ''), ' ', ''), ',')
    )
    INSERT INTO #RequestedMonths
    SELECT month_name
    FROM SplitMonths;

    INSERT INTO #Results
    SELECT
        ic.reporting_year                         AS reporting_year,
        DATENAME(MONTH, ic.execute_date)          AS reporting_period,
        t.request_identifier,
        ISNULL(t.plastic_waste, 0.000),
        ISNULL(t.e_waste, 0.000),
        ISNULL(t.bio_medical_waste, 0.000),
        ISNULL(t.construction_demolition_waste, 0.000),
        ISNULL(t.battery_waste, 0.000),
        ISNULL(t.radio_active_waste, 0.000),
        ISNULL(t.other_hazardous_waste, 0.000),
        ISNULL(t.other_non_hazardous_waste, 0.000),
        ISNULL(t.iron, 0.000),
        ISNULL(t.copper, 0.000),
        ISNULL(t.aluminium, 0.000),
        ISNULL(t.plastic_packing, 0.000),
        ISNULL(t.corrugated_box, 0.000),
        ISNULL(t.total_waste_generated, 0.000),
        ISNULL(t.recycled_waste, 0.000),
        ISNULL(t.reused_waste, 0.000),
        ISNULL(t.other_recovery_operation, 0.000),
        ISNULL(t.total_waste_recovered, 0.000),
        ISNULL(t.incineration, 0.000),
        ISNULL(t.landfilling, 0.000),
        ISNULL(t.other_disposal_operation, 0.000),
        ISNULL(t.total_waste_disposed, 0.000),
        CONVERT(VARCHAR(36), t.target_waste_management_id) AS sort_row_id
    FROM target_waste_management t
    INNER JOIN ingestion_calendar ic
        ON ic.ingestion_calendar_id = t.ingestion_calendar_id
    INNER JOIN #MonthsToProcess m
        ON DATENAME(MONTH, ic.execute_date) = m.month_name
    INNER JOIN #RequestedMonths rm
        ON m.month_name = rm.month_name
    INNER JOIN #YearRanges yr
        ON ic.reporting_year = yr.reporting_year
    WHERE t.deleted = 0;

    ;WITH Ordered AS (
        SELECT
            reporting_year        AS reporting_year,
            reporting_period      AS reporting_period,
            request_identifier    AS [Request Identifier],
            plastic_waste         AS [Plastic Waste (in MT)],
            e_waste               AS [E-Waste (in MT)],
            bio_medical_waste     AS [Bio Medical Waste (in MT)],
            construction_demolition_waste AS [Construction & Demolition Waste (in MT)],
            battery_waste         AS [Battery Waste (in MT)],
            radio_active_waste    AS [Radio Active Waste (in MT)],
            other_hazardous_waste AS [Other Hazardous Waste (in MT)],
            other_non_hazardous_waste AS [Other Non-Hazardous Waste (in MT)],
            iron                  AS [Iron (in MT)],
            copper                AS [Copper (in MT)],
            aluminium             AS [Aluminium (in MT)],
            plastic_packing       AS [Plastic Packing (in MT)],
            corrugated_box        AS [Corrugated Box (in MT)],
            total_waste_generated AS [Total Waste Generated (in MT)],
            recycled_waste        AS [Recycled Waste (in MT)],
            reused_waste          AS [Reused Waste (in MT)],
            other_recovery_operation AS [Other Recovery Operation (in MT)],
            total_waste_recovered AS [Total Waste Recovered (in MT)],
            incineration          AS [Incineration (in MT)],
            landfilling           AS [Landfilling (in MT)],
            other_disposal_operation AS [Other Disposal Operation (in MT)],
            total_waste_disposed  AS [Total Waste Disposed (in MT)],
            ROW_NUMBER() OVER (
                ORDER BY
                    CASE WHEN reporting_year IS NULL THEN 0 ELSE 1 END,
                    reporting_year,
                    CASE reporting_period
                        WHEN 'April' THEN 1
                        WHEN 'May' THEN 2
                        WHEN 'June' THEN 3
                        WHEN 'July' THEN 4
                        WHEN 'August' THEN 5
                        WHEN 'September' THEN 6
                        WHEN 'October' THEN 7
                        WHEN 'November' THEN 8
                        WHEN 'December' THEN 9
                        WHEN 'January' THEN 10
                        WHEN 'February' THEN 11
                        WHEN 'March' THEN 12
                    END,
                    request_identifier,
                    sort_row_id
            ) AS rn
        FROM #Results
    )
    SELECT
        reporting_year,
        reporting_period,
        [Request Identifier],
        [Plastic Waste (in MT)],
        [E-Waste (in MT)],
        [Bio Medical Waste (in MT)],
        [Construction & Demolition Waste (in MT)],
        [Battery Waste (in MT)],
        [Radio Active Waste (in MT)],
        [Other Hazardous Waste (in MT)],
        [Other Non-Hazardous Waste (in MT)],
        [Iron (in MT)],
        [Copper (in MT)],
        [Aluminium (in MT)],
        [Plastic Packing (in MT)],
        [Corrugated Box (in MT)],
        [Total Waste Generated (in MT)],
        [Recycled Waste (in MT)],
        [Reused Waste (in MT)],
        [Other Recovery Operation (in MT)],
        [Total Waste Recovered (in MT)],
        [Incineration (in MT)],
        [Landfilling (in MT)],
        [Other Disposal Operation (in MT)],
        [Total Waste Disposed (in MT)]
    FROM Ordered
    WHERE (@p_page = 1 AND @p_limit = 1)
       OR (@p_page IS NULL OR @p_limit IS NULL OR @p_page <= 0 OR @p_limit <= 0)
       OR rn BETWEEN ((@p_page - 1) * @p_limit) + 1
                  AND (@p_page * @p_limit)
    ORDER BY rn;

    DROP TABLE #Results;
    DROP TABLE #MonthsToProcess;
    DROP TABLE #RequestedMonths;
    DROP TABLE #YearRanges;
END;
GO


UPDATE operators SET logic_script = 'if(spResult.length> 0 && spResult[0].metric_result !== '''') return spResult[0].metric_result + '' %''; else return '''';' WHERE operator_id = 'f811657b-fe6d-42c8-af5b-8de6091d078e';
GO