"use strict";

var a2728_0xd645a8 = _interopRequireWildcard(require("./initQueries.js"));
var cache;
function _interopRequireWildcard(e, t) { if (!t && e && e.__esModule) return e; var r, c, a = Object.defineProperty, n = { __proto__: null, default: e }; if (Object(e) !== e) return n; if (cache || "function" != typeof WeakMap || (cache = new WeakMap()), cache) { if (cache.has(e)) return cache.get(e); cache.set(e, n); } for (c in e) "default" !== c && {}.hasOwnProperty.call(e, c) && ((r = a && Object.getOwnPropertyDescriptor(e, c)) && (r.get || r.set) ? a(n, c, r) : n[c] = e[c]); return n; }
const a2728_0xe36559 = a2728_0x2036;
(function (_0x18f519, _0x1062f6) {
  const _0xa0ca88 = a2728_0x2036,
    _0x2b4b86 = _0x18f519();
  while (!![]) {
    try {
      const _0x5f3de7 = parseInt(_0xa0ca88(0xcd)) / 0x1 + parseInt(_0xa0ca88(0xd0)) / 0x2 * (parseInt(_0xa0ca88(0xc0)) / 0x3) + -parseInt(_0xa0ca88(0xc4)) / 0x4 * (-parseInt(_0xa0ca88(0xc1)) / 0x5) + -parseInt(_0xa0ca88(0xd3)) / 0x6 * (parseInt(_0xa0ca88(0xc9)) / 0x7) + -parseInt(_0xa0ca88(0xda)) / 0x8 * (parseInt(_0xa0ca88(0xd8)) / 0x9) + parseInt(_0xa0ca88(0xc7)) / 0xa + parseInt(_0xa0ca88(0xe0)) / 0xb * (parseInt(_0xa0ca88(0xd6)) / 0xc);
      if (_0x5f3de7 === _0x1062f6) break;else _0x2b4b86['push'](_0x2b4b86['shift']());
    } catch (_0x301875) {
      _0x2b4b86['push'](_0x2b4b86['shift']());
    }
  }
})(a2728_0x1459, 0xbdb44);
function a2728_0x1459() {
  const _0x3c4321 = ['psoCa', '11482832BJSDpK', 'DB_HOST', 'DB_PORT', 'tedious', 'env', 'config', '22bMIsdq', 'mssql', '3SWxqIh', '44540aEUFxo', 'Database\x20connection\x20timeout', 'database', '600BAxWdb', 'dotenv', 'qbPWP', '3437180lkaBAo', 'rUFWJ', '7bgdsuO', 'password', 'getConnectedSequelize', 'DB_PASSWORD', '327790XNbvZx', 'exports', 'race', '1906978lCxbdn', '+05:30', 'DB_USERNAME', '7128894NibZVf', 'username', 'authenticate', '2636004aqRJvI', 'sequelize', '9jwGIYy'];
  a2728_0x1459 = function () {
    return _0x3c4321;
  };
  return a2728_0x1459();
}
const {
  Sequelize
} = require(a2728_0xe36559(0xd7));
require(a2728_0xe36559(0xc5))[a2728_0xe36559(0xdf)]();
const tedious = require(a2728_0xe36559(0xdd)),
  config = {
    'username': process[a2728_0xe36559(0xde)][a2728_0xe36559(0xd2)],
    'password': process[a2728_0xe36559(0xde)][a2728_0xe36559(0xcc)],
    'host': process[a2728_0xe36559(0xde)][a2728_0xe36559(0xdb)],
    'database': process[a2728_0xe36559(0xde)]['DB_DATABASE'],
    'port': parseInt(process['env'][a2728_0xe36559(0xdc)]),
    'dialect': a2728_0xe36559(0xbf),
    'logging': ![],
    'dialectModule': tedious,
    'options': {
      'encrypt': ![],
      'trustServerCertificate': !![]
    },
    'timezone': a2728_0xe36559(0xd1),
    'pool': {
      'max': 0xa,
      'min': 0x0,
      'idle': 0x7530,
      'acquire': 0xea60
    },
    'dialectOptions': {
      'requestTimeout': 0x1d4c0,
      'connectTimeout': 0x1d4c0,
      'packetSize': 0x2000,
      'options': {
        'encrypt': ![],
        'trustServerCertificate': !![],
        'enableArithAbort': !![],
        'requestTimeout': 0x1d4c0,
        'connectionTimeout': 0x1d4c0
      }
    }
  },
  sequelize = new Sequelize(config[a2728_0xe36559(0xc3)], config[a2728_0xe36559(0xd4)], config[a2728_0xe36559(0xca)], config),
  connectToDatabase = async () => {
    const _0x3fcf42 = a2728_0xe36559,
      _0x108313 = {
        'qbPWP': function (_0x462738, _0x5169eb, _0x32eb6b) {
          return _0x462738(_0x5169eb, _0x32eb6b);
        }
      };
    try {
      const _0x3a6c7d = new Promise((_0x36a622, _0x51f288) => {
        const _0x9716af = a2728_0x2036;
        _0x108313[_0x9716af(0xc6)](setTimeout, () => _0x51f288(new Error(_0x9716af(0xc2))), 0x7530);
      });
      return await Promise[_0x3fcf42(0xcf)]([sequelize[_0x3fcf42(0xd5)](), _0x3a6c7d]), sequelize;
    } catch (_0xea4ed1) {
      throw _0xea4ed1;
    }
  };
function a2728_0x2036(_0xcdc887, _0x1afa55) {
  const _0x1459ff = a2728_0x1459();
  return a2728_0x2036 = function (_0x2036b9, _0x51e475) {
    _0x2036b9 = _0x2036b9 - 0xbf;
    let _0x202409 = _0x1459ff[_0x2036b9];
    return _0x202409;
  }, a2728_0x2036(_0xcdc887, _0x1afa55);
}
let connectedSequelize = null,
  connectionPromise = null;
(async () => {
  const _0x1fc3a0 = a2728_0xe36559,
    _0x4e1cbf = {
      'rUFWJ': function (_0xd8e3e7) {
        return _0xd8e3e7();
      },
      'psoCa': 'Database\x20connection\x20failed\x20at\x20startup.\x20Will\x20retry\x20on\x20first\x20use.'
    };
  try {
    connectionPromise = _0x4e1cbf[_0x1fc3a0(0xc8)](connectToDatabase), connectedSequelize = await connectionPromise;
  } catch (_0x2a1de7) {
    console['warn'](_0x4e1cbf[_0x1fc3a0(0xd9)]);
  }
})(), module[a2728_0xe36559(0xce)] = sequelize, module[a2728_0xe36559(0xce)][a2728_0xe36559(0xcb)] = async function () {
  const _0x296c80 = {
    'Xayoh': function (_0x1127d3) {
      return _0x1127d3();
    }
  };
  if (!connectedSequelize) {
    if (connectionPromise) try {
      connectedSequelize = await connectionPromise;
    } catch (_0x1efdee) {
      connectionPromise = connectToDatabase(), connectedSequelize = await connectionPromise;
    } else connectionPromise = _0x296c80['Xayoh'](connectToDatabase), connectedSequelize = await connectionPromise;
  }
  return connectedSequelize;
};