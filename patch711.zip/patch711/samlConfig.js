'use strict';

const a2747_0x54dd56 = a2747_0x3dee;
function a2747_0x3dee(_0x1a429f, _0x241e49) {
  const _0x40ecf3 = a2747_0x40ec();
  return a2747_0x3dee = function (_0x3deebc, _0x4cc263) {
    _0x3deebc = _0x3deebc - 0x1e8;
    let _0x1120d1 = _0x40ecf3[_0x3deebc];
    return _0x1120d1;
  }, a2747_0x3dee(_0x1a429f, _0x241e49);
}
(function (_0x213905, _0x2596aa) {
  const _0x104938 = a2747_0x3dee,
    _0x55a818 = _0x213905();
  while (!![]) {
    try {
      const _0x57e367 = parseInt(_0x104938(0x224)) / 0x1 + -parseInt(_0x104938(0x203)) / 0x2 * (-parseInt(_0x104938(0x263)) / 0x3) + parseInt(_0x104938(0x23f)) / 0x4 * (parseInt(_0x104938(0x222)) / 0x5) + -parseInt(_0x104938(0x1ec)) / 0x6 + -parseInt(_0x104938(0x223)) / 0x7 * (-parseInt(_0x104938(0x210)) / 0x8) + parseInt(_0x104938(0x218)) / 0x9 * (parseInt(_0x104938(0x1ee)) / 0xa) + -parseInt(_0x104938(0x1f6)) / 0xb * (parseInt(_0x104938(0x231)) / 0xc);
      if (_0x57e367 === _0x2596aa) break;else _0x55a818['push'](_0x55a818['shift']());
    } catch (_0x273296) {
      _0x55a818['push'](_0x55a818['shift']());
    }
  }
})(a2747_0x40ec, 0x271f2);
const passport = require(a2747_0x54dd56(0x268)),
  fs = require('fs'),
  path = require(a2747_0x54dd56(0x25f)),
  jwt = require(a2747_0x54dd56(0x264)),
  userCrud = require(a2747_0x54dd56(0x22c))['default'],
  getDocumentPermissions = require('./app/common/getDocumentPermissions')[a2747_0x54dd56(0x212)],
  getUserAccess = require(a2747_0x54dd56(0x1ea))[a2747_0x54dd56(0x212)],
  {
    sanitizeInput
  } = require('./app/common/sanitizeInpute'),
  sessionCrud = require(a2747_0x54dd56(0x25d))['default'],
  LoginAttempt = require('./app/models/loginAttempt/index')[a2747_0x54dd56(0x212)],
  roleCrud = require(a2747_0x54dd56(0x20d))[a2747_0x54dd56(0x212)],
  {
    encrypt
  } = require(a2747_0x54dd56(0x214)),
  rateLimit = require(a2747_0x54dd56(0x248)),
  {
    performLoginValidations
  } = require('./app/services/authentication'),
  {
    checkLicenseExpiry
  } = require(a2747_0x54dd56(0x24a));
require('dotenv')['config']();
function isSAMLConfigured() {
  const _0x115200 = a2747_0x54dd56,
    _0x563faf = {
      'XlHdF': _0x115200(0x20b),
      'bhpyV': 'SAML_ENTRY_POINT',
      'FxuyT': _0x115200(0x20c),
      'nmvFe': 'SAML_CALLBACK_URL',
      'mIdWf': function (_0x123c63, _0x4de9f8) {
        return _0x123c63 > _0x4de9f8;
      },
      'vkebW': _0x115200(0x1f3)
    },
    _0x38fa4b = [_0x563faf['XlHdF'], _0x563faf[_0x115200(0x221)], _0x563faf['FxuyT'], _0x563faf[_0x115200(0x23c)]],
    _0x2aadd9 = _0x38fa4b[_0x115200(0x21f)](_0x31fedd => !process[_0x115200(0x1ed)][_0x31fedd]);
  if (_0x563faf[_0x115200(0x208)](_0x2aadd9['length'], 0x0)) return {
    'configured': ![],
    'missing': _0x2aadd9,
    'message': _0x115200(0x238) + _0x2aadd9['join'](',\x20')
  };
  if (!fs['existsSync'](process[_0x115200(0x1ed)][_0x115200(0x20b)])) return {
    'configured': ![],
    'missing': [_0x563faf['vkebW']],
    'message': _0x115200(0x258) + process[_0x115200(0x1ed)][_0x115200(0x20b)]
  };
  return {
    'configured': !![]
  };
}
let samlEnabled = ![],
  samlConfigStatus = null;
try {
  samlConfigStatus = isSAMLConfigured(), samlEnabled = samlConfigStatus[a2747_0x54dd56(0x245)];
  if (samlEnabled) {
    const ADFS_IDP_ENTRYPOINT = process['env'][a2747_0x54dd56(0x262)],
      ADFS_IDP_CERT = fs[a2747_0x54dd56(0x1fe)](process[a2747_0x54dd56(0x1ed)][a2747_0x54dd56(0x20b)], a2747_0x54dd56(0x20e)),
      SP_ENTITY_ID = process[a2747_0x54dd56(0x1ed)]['SP_ENTITY_ID'],
      SamlStrategy = require(a2747_0x54dd56(0x233))[a2747_0x54dd56(0x24d)];
    passport[a2747_0x54dd56(0x21a)](new SamlStrategy({
      'path': a2747_0x54dd56(0x244),
      'callbackUrl': process['env'][a2747_0x54dd56(0x1e8)],
      'entryPoint': ADFS_IDP_ENTRYPOINT,
      'issuer': SP_ENTITY_ID,
      'cert': ADFS_IDP_CERT,
      'idpCert': ADFS_IDP_CERT,
      'identifierFormat': null
    }, (_0x505fe4, _0x165dac) => {
      const _0x1d8bcc = a2747_0x54dd56,
        _0x488c3e = {
          'AAQXR': function (_0xa16fb8, _0x1390ee, _0x5edba2) {
            return _0xa16fb8(_0x1390ee, _0x5edba2);
          }
        },
        _0x4d44e2 = {
          'id': _0x505fe4['nameID']
        };
      return _0x488c3e[_0x1d8bcc(0x234)](_0x165dac, null, _0x4d44e2);
    }));
  } else {}
} catch (a2747_0x211d27) {
  samlEnabled = ![], samlConfigStatus = {
    'configured': ![],
    'message': a2747_0x54dd56(0x1f2) + a2747_0x211d27[a2747_0x54dd56(0x230)]
  };
}
passport[a2747_0x54dd56(0x211)]((_0xee6571, _0x1192e2) => {
  const _0x201b6a = {
    'lWhyP': function (_0x1d53bb, _0x562388, _0x74963f) {
      return _0x1d53bb(_0x562388, _0x74963f);
    }
  };
  _0x201b6a['lWhyP'](_0x1192e2, null, _0xee6571);
}), passport[a2747_0x54dd56(0x247)]((_0x311d79, _0x5e30ad) => {
  _0x5e30ad(null, _0x311d79);
});
function ensureAuthenticated(_0x457536, _0x2231b8, _0x4c2439) {
  const _0x190818 = a2747_0x54dd56,
    _0x17c369 = {
      'rOLAu': function (_0x5610e9) {
        return _0x5610e9();
      },
      'IeFNR': _0x190818(0x217)
    };
  if (_0x457536[_0x190818(0x22f)]()) return _0x17c369['rOLAu'](_0x4c2439);
  _0x2231b8['redirect'](_0x17c369[_0x190818(0x22e)]);
}
function samlRoutes(_0xfbf546) {
  const _0x3d50ab = a2747_0x54dd56,
    _0x3658b4 = {
      'oTrEF': function (_0x38fa3e, _0x181349) {
        return _0x38fa3e(_0x181349);
      },
      'XhbBm': _0x3d50ab(0x233),
      'SThZs': _0x3d50ab(0x244),
      'ihbIB': _0x3d50ab(0x200),
      'OUAoQ': 'SAML\x20authentication\x20is\x20not\x20configured',
      'TqEzc': _0x3d50ab(0x204),
      'LgqqK': function (_0x11fc96) {
        return _0x11fc96();
      },
      'iTuCe': 'Invalid\x20token',
      'CmOIT': function (_0x3ba5d3, _0x1e8860) {
        return _0x3ba5d3(_0x1e8860);
      },
      'IOPPy': _0x3d50ab(0x1fc),
      'UJnhS': _0x3d50ab(0x1f1),
      'ehdHZ': _0x3d50ab(0x23e),
      'xjwCS': _0x3d50ab(0x265),
      'pQbGb': function (_0x37af65, _0x47c528) {
        return _0x37af65 !== _0x47c528;
      },
      'lIILg': _0x3d50ab(0x249),
      'kpffY': function (_0x360444) {
        return _0x360444();
      },
      'xmtvd': _0x3d50ab(0x24f),
      'UXuOR': _0x3d50ab(0x206),
      'DftPw': function (_0x363115, _0x1a2363) {
        return _0x363115(_0x1a2363);
      },
      'TexJQ': _0x3d50ab(0x1f7),
      'irovd': _0x3d50ab(0x217),
      'yZHTu': _0x3d50ab(0x229),
      'qaxwJ': _0x3d50ab(0x213),
      'GPvmm': _0x3d50ab(0x1e9)
    },
    _0x3dcb2d = (_0x20e0f7, _0x3252cd, _0x4e9f2b) => {
      const _0x363c8e = _0x3d50ab,
        _0x15fc25 = {
          'pRvhW': function (_0x19ca20, _0x176660, _0x52d6f1) {
            return _0x19ca20(_0x176660, _0x52d6f1);
          }
        };
      if (!samlEnabled) {
        if (_0x3658b4[_0x363c8e(0x241)] === _0x363c8e(0x202)) {
          const _0x44880b = _0xa8917d[_0x363c8e(0x1ed)]['SAML_ENTRY_POINT'],
            _0x1dbae1 = _0x1a1ce0[_0x363c8e(0x1fe)](_0x39242f[_0x363c8e(0x1ed)][_0x363c8e(0x20b)], _0x363c8e(0x20e)),
            _0x3929fe = _0x38acc7[_0x363c8e(0x1ed)][_0x363c8e(0x20c)],
            _0x2669ee = _0x3658b4['oTrEF'](_0xcc114f, _0x3658b4['XhbBm'])[_0x363c8e(0x24d)];
          _0x3625f7[_0x363c8e(0x21a)](new _0x2669ee({
            'path': _0x3658b4[_0x363c8e(0x232)],
            'callbackUrl': _0x78aec3[_0x363c8e(0x1ed)][_0x363c8e(0x1e8)],
            'entryPoint': _0x44880b,
            'issuer': _0x3929fe,
            'cert': _0x1dbae1,
            'idpCert': _0x1dbae1,
            'identifierFormat': null
          }, (_0x937428, _0x27b41c) => {
            const _0x2c8918 = _0x363c8e,
              _0xb5fc8d = {
                'id': _0x937428[_0x2c8918(0x24b)]
              };
            return _0x15fc25['pRvhW'](_0x27b41c, null, _0xb5fc8d);
          }));
        } else return _0x3252cd[_0x363c8e(0x242)](0x1f7)[_0x363c8e(0x243)]({
          'error': _0x3658b4['OUAoQ'],
          'message': samlConfigStatus?.[_0x363c8e(0x230)] || _0x3658b4[_0x363c8e(0x1f4)],
          'details': samlConfigStatus?.[_0x363c8e(0x259)] || []
        });
      }
      _0x3658b4[_0x363c8e(0x1ff)](_0x4e9f2b);
    };
  _0xfbf546['get'](_0x3658b4[_0x3d50ab(0x236)], _0x3dcb2d, passport[_0x3d50ab(0x267)](_0x3658b4[_0x3d50ab(0x1f0)], {
    'failureRedirect': _0x3658b4[_0x3d50ab(0x253)]
  }), async (_0x8e4c42, _0x4bcc0c) => {
    const _0x41e57c = _0x3d50ab,
      _0x2779b5 = _0x8e4c42?.[_0x41e57c(0x260)];
    let _0x12978b = await userCrud['getById']({
      'ad_user_id': _0x3658b4['CmOIT'](sanitizeInput, _0x2779b5?.['id'])
    }, [_0x3658b4[_0x41e57c(0x24e)], _0x3658b4[_0x41e57c(0x255)], 'role_Id', _0x3658b4[_0x41e57c(0x220)], _0x3658b4[_0x41e57c(0x22d)], _0x41e57c(0x1f5)]);
    const _0x1e6518 = await performLoginValidations(_0x12978b);
    if (_0x1e6518?.[_0x41e57c(0x1fd)]) {
      if (_0x3658b4['pQbGb'](_0x3658b4[_0x41e57c(0x25e)], _0x3658b4[_0x41e57c(0x25e)])) _0x3945fa['status'](0x191)['send'](_0x3658b4[_0x41e57c(0x256)]);else return _0x4bcc0c[_0x41e57c(0x242)](0x193)[_0x41e57c(0x22b)]({
        'message': _0x1e6518[_0x41e57c(0x1fd)]
      });
    }
    _0x4bcc0c[_0x41e57c(0x219)]('/');
  });
  const _0x25c4e4 = process[_0x3d50ab(0x1ed)]['SAML_REDIRECT'] || '';
  _0xfbf546[_0x3d50ab(0x23b)](_0x3658b4['SThZs'], _0x3dcb2d, (_0x4daa4d, _0x3b9292, _0xf1f766) => {
    const _0x211b95 = _0x3d50ab;
    _0x3658b4[_0x211b95(0x23d)](_0xf1f766);
  }, passport[_0x3d50ab(0x267)](_0x3658b4[_0x3d50ab(0x1f0)], {
    'failureRedirect': _0x3658b4[_0x3d50ab(0x253)]
  }), (_0x35ddec, _0x3cbe4f) => {
    const _0x34690d = _0x3d50ab,
      _0x446250 = jwt['sign']({
        'userId': _0x35ddec[_0x34690d(0x260)]['id']
      }, process[_0x34690d(0x1ed)]['JWT_SECRET_KEY'], {
        'expiresIn': _0x3658b4[_0x34690d(0x1fb)]
      });
    _0x3cbe4f[_0x34690d(0x219)](_0x25c4e4 + _0x34690d(0x1eb) + _0x446250);
  });
  const _0x46e3c7 = new Set();
  _0xfbf546[_0x3d50ab(0x235)](_0x3658b4[_0x3d50ab(0x23a)], async (_0x534a3c, _0x21d2f2) => {
    const _0x9e6197 = _0x3d50ab;
    try {
      const _0x584b8a = _0x534a3c[_0x9e6197(0x1f9)][_0x9e6197(0x1f8)];
      if (!_0x584b8a) return _0x21d2f2['status'](0x191)['send'](_0x3658b4[_0x9e6197(0x254)]);
      if (_0x46e3c7[_0x9e6197(0x25c)](_0x584b8a)) return _0x21d2f2['status'](0x191)[_0x9e6197(0x22b)](_0x9e6197(0x21b));
      const _0x502003 = jwt[_0x9e6197(0x24c)](_0x584b8a, process[_0x9e6197(0x1ed)]['JWT_SECRET_KEY']);
      _0x46e3c7['add'](_0x584b8a), setTimeout(() => {
        const _0x4c65ac = _0x9e6197;
        _0x46e3c7[_0x4c65ac(0x21c)](_0x584b8a);
      }, 0xea60);
      const _0x174a42 = {
          'id': _0x502003[_0x9e6197(0x239)]
        },
        _0x1a7b0b = await _0x3658b4[_0x9e6197(0x252)](checkAndCreateSession, _0x174a42);
      _0x21d2f2['status'](0xc8)[_0x9e6197(0x22b)](_0x1a7b0b);
    } catch (_0x44fb9f) {
      _0x21d2f2[_0x9e6197(0x242)](0x191)[_0x9e6197(0x22b)](_0x3658b4['iTuCe']);
    }
  }), _0xfbf546[_0x3d50ab(0x235)](_0x3658b4[_0x3d50ab(0x253)], (_0x170311, _0x47380e) => {
    const _0x25e5b7 = _0x3d50ab;
    _0x47380e['status'](0x191)['send'](_0x3658b4[_0x25e5b7(0x266)]);
  });
}
module['exports'] = {
  'samlRoutes': samlRoutes,
  'ensureAuthenticated': ensureAuthenticated,
  'isSAMLEnabled': () => samlEnabled,
  'getSAMLConfigStatus': () => samlConfigStatus
};
function a2747_0x40ec() {
  const _0x485f2b = ['stringify', 'GJOaM', 'last_active_date', 'saml', 'role_Id', 'send', './app/models/userMaster/index', 'xjwCS', 'IeFNR', 'isAuthenticated', 'message', '1932azrJQa', 'SThZs', '@node-saml/passport-saml', 'AAQXR', 'get', 'irovd', 'is_enabled', 'SAML\x20is\x20not\x20configured.\x20Missing\x20environment\x20variables:\x20', 'userId', 'GPvmm', 'post', 'nmvFe', 'kpffY', 'display_name', '12rILQvS', 'TxjtE', 'ihbIB', 'status', 'json', '/saml/SSO', 'configured', 'Login\x20Failed\x20|\x20Error\x20checking\x20and\x20creating\x20session!', 'deserializeUser', 'express-rate-limit', 'YgOUz', './app/common/checkLicense', 'nameID', 'verify', 'Strategy', 'IOPPy', '10s', 'getById', 'SESSION_EXPIRY_TIME_MINUTES', 'DftPw', 'qaxwJ', 'UXuOR', 'UJnhS', 'iTuCe', 'pdp_message', 'SAML\x20certificate\x20file\x20not\x20found\x20at\x20path:\x20', 'missing', 'Login\x20Failed\x20|\x20User\x20not\x20Exists!', 'Login\x20Failed\x20|\x20Session\x20creation\x20failed!', 'has', './app/models/userSession/index', 'lIILg', 'path', 'user', 'LliQS', 'SAML_ENTRY_POINT', '82659bIjRqq', 'jsonwebtoken', 'full_name', 'TexJQ', 'authenticate', 'passport', 'SAML_CALLBACK_URL', '/protected', './app/common/userAccess', '?token=', '39060XguQTE', 'env', '892330JuZpNK', 'kPaup', 'yZHTu', 'user_name', 'SAML\x20configuration\x20error:\x20', 'SAML_CERT_PATH\x20(file\x20not\x20found)', 'TqEzc', 'organization_id', '45727bqloeo', 'Login\x20failed', 'token', 'query', 'Login\x20successful', 'xmtvd', 'user_id', 'error', 'readFileSync', 'LgqqK', 'rYZZR', 'NdaqE', 'YRxfA', '22VSNWVo', 'SAML\x20is\x20disabled.\x20Please\x20configure\x20SAML\x20environment\x20variables\x20to\x20enable\x20this\x20feature.', 'updatedAt', 'No\x20token\x20provided', 'sign', 'mIdWf', 'JWT_SECRET_KEY', 'gyFKS', 'SAML_CERT_PATH', 'SP_ENTITY_ID', './app/models/roleMaster/index', 'utf8', 'XMwWd', '2360OFbUff', 'serializeUser', 'default', '/login/fail', './app/common/encrypt', 'jZroy', 'EbJSl', '/login', '9NHashd', 'redirect', 'use', 'Token\x20has\x20already\x20been\x20used', 'delete', 'pnZOF', 'fVuQj', 'filter', 'ehdHZ', 'bhpyV', '357615tcOWFm', '2884xdYNuW', '107604pyDZGY', 'HkGan'];
  a2747_0x40ec = function () {
    return _0x485f2b;
  };
  return a2747_0x40ec();
}
async function checkAndCreateSession(_0x1ecbb0) {
  const _0x4bda02 = a2747_0x54dd56,
    _0x1b45f8 = {
      'EbJSl': function (_0x44d1d3, _0x12250c, _0x3e5f8d) {
        return _0x44d1d3(_0x12250c, _0x3e5f8d);
      },
      'fVuQj': 'Invalid\x20user\x20object',
      'jZroy': function (_0x218bc8, _0x18dca3) {
        return _0x218bc8(_0x18dca3);
      },
      'gYAHs': _0x4bda02(0x1fc),
      'GJOaM': 'user_name',
      'kdSTT': _0x4bda02(0x22a),
      'XMwWd': 'display_name',
      'ginZc': _0x4bda02(0x237),
      'NdaqE': _0x4bda02(0x228),
      'LliQS': _0x4bda02(0x205),
      'HkGan': function (_0x37124c, _0x2dfb77) {
        return _0x37124c === _0x2dfb77;
      },
      'YdSEc': 'KlXIS',
      'IHcXm': function (_0xdb49a7, _0x10fe2b) {
        return _0xdb49a7 + _0x10fe2b;
      },
      'pnZOF': function (_0x15f732, _0x4c84a6) {
        return _0x15f732 * _0x4c84a6;
      },
      'kPaup': _0x4bda02(0x1fa),
      'TxjtE': function (_0x238204, _0x41b26f) {
        return _0x238204(_0x41b26f);
      },
      'sotWn': function (_0x483a5e, _0x494359) {
        return _0x483a5e(_0x494359);
      },
      'gyFKS': function (_0x344522, _0x56ee8e) {
        return _0x344522(_0x56ee8e);
      },
      'RGAZd': _0x4bda02(0x246)
    };
  try {
    if (!_0x1ecbb0 || !_0x1ecbb0['id']) throw new Error(_0x1b45f8[_0x4bda02(0x21e)]);
    const _0x367748 = 0x1;
    let _0xc9e1a7 = await userCrud[_0x4bda02(0x250)]({
      'ad_user_id': _0x1b45f8['jZroy'](sanitizeInput, _0x1ecbb0['id'])
    }, [_0x1b45f8['gYAHs'], _0x1b45f8[_0x4bda02(0x227)], _0x1b45f8['kdSTT'], _0x1b45f8[_0x4bda02(0x20f)], _0x4bda02(0x265), 'organization_id', _0x1b45f8['ginZc'], _0x1b45f8[_0x4bda02(0x201)], _0x1b45f8[_0x4bda02(0x261)]]);
    _0xc9e1a7 = JSON['parse'](JSON[_0x4bda02(0x226)](_0xc9e1a7));
    if (!_0xc9e1a7) return {
      'message': _0x4bda02(0x25a)
    };
    const _0x48bbd5 = await _0x1b45f8[_0x4bda02(0x215)](performLoginValidations, _0xc9e1a7);
    if (_0x48bbd5?.[_0x4bda02(0x1fd)]) {
      if (_0x1b45f8[_0x4bda02(0x225)]('KlXIS', _0x1b45f8['YdSEc'])) return {
        'message': _0x48bbd5[_0x4bda02(0x1fd)]
      };else _0x1b45f8[_0x4bda02(0x216)](_0x1c0571, null, _0x3a1e76);
    }
    const _0x560511 = await roleCrud[_0x4bda02(0x250)]({
        'role_Id': _0xc9e1a7[_0x4bda02(0x22a)]
      }),
      _0x116260 = _0x560511[_0x4bda02(0x257)] || '',
      _0x4f5cae = _0x560511['role_name'] || '',
      _0x5daeb1 = jwt[_0x4bda02(0x207)]({
        'user_id': _0xc9e1a7['user_id'],
        'role_Id': _0xc9e1a7[_0x4bda02(0x22a)],
        'organization_id': _0xc9e1a7[_0x4bda02(0x1f5)]
      }, process['env'][_0x4bda02(0x209)], {
        'expiresIn': '1d',
        'algorithm': 'HS256'
      }),
      _0x38e167 = process[_0x4bda02(0x1ed)][_0x4bda02(0x251)] || 0x3c,
      _0x32bb5f = new Date(_0x1b45f8['IHcXm'](Date['now'](), _0x1b45f8[_0x4bda02(0x21d)](_0x38e167 * 0x3c, 0x3e8))),
      _0xc778e9 = {
        'is_expired': ![],
        'valid_till': _0x32bb5f,
        'organization_id': _0xc9e1a7[_0x4bda02(0x1f5)],
        'user_id': _0xc9e1a7[_0x4bda02(0x1fc)],
        'session_token': _0x5daeb1
      };
    let _0x46eee2 = await sessionCrud['create'](_0xc778e9);
    _0x46eee2 = JSON['parse'](JSON[_0x4bda02(0x226)](_0x46eee2));
    if (!_0x46eee2['session_id']) return {
      'message': _0x4bda02(0x25b)
    };
    await LoginAttempt['create']({
      'user_name': _0xc9e1a7[_0x4bda02(0x1f1)],
      'is_successful': !![],
      'created_at': new Date()
    });
    const _0x7e2c1b = {
      'status': 0xc8,
      'message': _0x1b45f8[_0x4bda02(0x1ef)],
      'token': _0x5daeb1,
      'session_id': _0x46eee2['session_id'],
      'userData': {
        ..._0xc9e1a7,
        'role_Id': _0xc9e1a7?.[_0x4bda02(0x22a)],
        'pdp_message': {
          'pdp_message': _0x116260,
          'role_name': _0x4f5cae
        }
      },
      'documentPermissionTypes': {
        'READ_PERMISSSION': 0x0,
        'CREATE_PERMISSSION': 0x1,
        'UPDATE_PERMISSSION': 0x2,
        'DELETE_PERMISSSION': 0x3,
        'APPROVE_PERMISSSION': 0x4,
        'VERIFY_PERMISSSION': 0x5,
        'FILTER_PERMISSSION': 0x6
      },
      'documentPermissions': await _0x1b45f8[_0x4bda02(0x240)](getDocumentPermissions, sanitizeInput(String(_0xc9e1a7['role_Id']))),
      'userAccess': await _0x1b45f8['EbJSl'](getUserAccess, _0x1b45f8['sotWn'](sanitizeInput, String(_0xc9e1a7[_0x4bda02(0x22a)])), sanitizeInput(_0x1b45f8[_0x4bda02(0x20a)](String, _0xc9e1a7['organization_id'])))
    };
    return _0x7e2c1b;
  } catch (_0x188476) {
    return {
      'message': _0x1b45f8['RGAZd']
    };
  }
}