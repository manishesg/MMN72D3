#!/bin/bash

_0x4e616d65="patch_internal"
_0x50617468="5c6e2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d5c6e"
_0x4c6f676963() {
    local _0xhex=$1
    echo -e $(echo $_0xhex | sed 's/../\\x&/g')
}

# Encoded Core Logic
_0x72756e="436f6e7461696e6572205061746368696e672026204261636b7570205574696c697479"
echo "$(_0x4c6f676963 $_0x50617468)"
echo "$(_0x4c6f676963 $_0x72756e)"
echo "$(_0x4c6f676963 $_0x50617468)"

# Paths relative to C_PRE (includes backup-from-container.list + prior patch targets)
FILES=(
    "config/database.js"
    "samlConfig.js"
    "app/script/alt44.sql"
)
C_PRE="/app/dist"

read -p "$(_0x4c6f676963 "456e74657220636f6e7461696e6572206e616d653a20")" C_NM
if ! podman ps -a --format "{{.Names}}" | grep -q "^$C_NM$"; then
    echo "$(_0x4c6f676963 "4572726f723a20436f6e7461696e6572206e6f7420666f756e642e")"
    exit 1
fi

read -p "$(_0x4c6f676963 "446f20796f752077616e7420746f206261636b75703f2028592f6e293a20")" BK_Q
BK_Q=${BK_Q:-Y}
if [[ "$BK_Q" =~ ^[Yy]$ ]]; then
    read -p "$(_0x4c6f676963 "456e746572206261636b757020666f6c6465723a20")" BK_D
    mkdir -p "$BK_D"
    for f in "${FILES[@]}"; do
        # Directory: copy contents into dest (plain cp would nest e.g. worker/worker/).
        if podman exec "$C_NM" test -d "$C_PRE/$f" 2>/dev/null || [[ "$f" == "app/worker" ]]; then
            mkdir -p "$BK_D/$f"
            podman cp "$C_NM:$C_PRE/$f/." "$BK_D/$f/" && echo "BK: $f" || echo "SKIP: $f"
        else
            mkdir -p "$(dirname "$BK_D/$f")"
            podman cp "$C_NM:$C_PRE/$f" "$BK_D/$f" && echo "BK: $f" || echo "SKIP: $f"
        fi
    done
fi

read -p "$(_0x4c6f676963 "456e74657220706174636820666f6c6465723a20")" PT_D
if [ ! -d "$PT_D" ]; then exit 1; fi

for f in "${FILES[@]}"; do
    if [ -f "$PT_D/$f" ]; then
        podman cp "$PT_D/$f" "$C_NM:$C_PRE/$f"
        echo "$(_0x4c6f676963 "557064617465643a20")$f"
    elif [ -d "$PT_D/$f" ]; then
        # Merge into existing dir; without "/." podman nests src basename under dest.
        podman exec "$C_NM" mkdir -p "$C_PRE/$f" 2>/dev/null || true
        podman cp "$PT_D/$f/." "$C_NM:$C_PRE/$f/"
        echo "$(_0x4c6f676963 "557064617465643a20")$f"
    else
        echo "SKIP (not on host): $f"
    fi
done

echo "$(_0x4c6f676963 "566572696679696e672e2e2e")"
for f in "${FILES[@]}"; do
    echo -n "$f: "
    podman exec "$C_NM" env TZ="Asia/Kolkata" ls -l "$C_PRE/$f"
done

read -p "$(_0x4c6f676963 "526573746172743f2028592f6e293a20")" RS_Q
RS_Q=${RS_Q:-Y}
[[ "$RS_Q" =~ ^[Yy]$ ]] && podman restart "$C_NM" && echo "$(_0x4c6f676963 "5265737461727465642e")"